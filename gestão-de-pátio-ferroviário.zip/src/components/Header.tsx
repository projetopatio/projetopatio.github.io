import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, NotificationAlert } from '../types';
import { PWAInstallButton } from './PWAInstallButton';
import { 
  Train, 
  Bell, 
  Shield, 
  Layers, 
  FileText, 
  Share2, 
  KeyRound,
  Users,
  Settings
} from 'lucide-react';

interface HeaderProps {
  currentTab: 'yard' | 'movements' | 'reports' | 'api' | 'audit' | 'notifications';
  onSelectTab: (tab: 'yard' | 'movements' | 'reports' | 'api' | 'audit' | 'notifications') => void;
  currentUser?: UserProfile | null;
  onOpenUserSwitcher: () => void;
  onOpenUserManagement?: () => void;
  notifications: NotificationAlert[];
  onOpenNotifications: () => void;
  overallOccupancyPct?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onOpenUserSwitcher,
  onOpenUserManagement,
  notifications,
  onOpenNotifications,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsMenuOpen(false);
      }
    };
    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isMenuOpen]);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-slate-100">
      {/* Top Primary Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          
          {/* Logo & System Brand */}
          <button
            type="button"
            onClick={() => onSelectTab('yard')}
            className="flex items-center gap-3 text-left cursor-pointer group focus:outline-none"
            title="Ir para o Sinóptico CCO (Mapa do Pátio)"
          >
            <div className="h-10 px-2.5 py-1.5 rounded-xl bg-white border border-slate-700/50 flex items-center justify-center shadow-md shadow-indigo-950/20 shrink-0 group-hover:scale-105 transition-transform">
              <img 
                src="/motiva-logo.svg" 
                alt="Logo Motiva" 
                className="h-6 w-auto aspect-[3/2] object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-base sm:text-lg tracking-tight text-white leading-none group-hover:text-amber-300 transition-colors">
                  Motiva Pátio VLT CARIOCA
                </h1>
              </div>
              <p className="hidden md:block text-[11px] text-slate-400 mt-0.5">
                Controle Operacional de Manobras
              </p>
            </div>
          </button>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* PWA Install Button */}
            <PWAInstallButton />

            {/* Notifications Bell */}
            <button
              id="btn-notifications-drawer"
              onClick={onOpenNotifications}
              title="Notificações Automáticas CCO"
              className="relative p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Active User Switcher / Identification */}
            {currentUser ? (
              <button
                id="btn-user-switcher"
                onClick={onOpenUserSwitcher}
                className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-left transition cursor-pointer"
                title="Trocar usuário ou cadastrar novo operador (3 perfis disponíveis)"
              >
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                  alt={currentUser.name || 'Operador'}
                  className="w-7 h-7 rounded-full object-cover border border-slate-600"
                />
                <div className="hidden md:block">
                  <div className="text-xs font-semibold text-white leading-tight flex items-center gap-1">
                    <span>{currentUser.name}</span>
                    <span className="text-[10px] text-amber-400 font-mono font-bold">({currentUser.badgeNumber})</span>
                  </div>
                  <div className="text-[10px] text-slate-400 leading-tight">
                    {currentUser.role === 'tecnico_mro' && 'Técnico MRO'}
                    {currentUser.role === 'controlador_cco' && 'Controlador CCO'}
                    {currentUser.role === 'supervisor_cco' && 'Supervisor CCO'}
                    {currentUser.role === 'admin' && 'Supervisor CCO / Admin'}
                    {currentUser.role === 'cco_dispatcher' && 'Controlador CCO'}
                    {currentUser.role === 'maintenance_tech' && 'Técnico MRO'}
                    {currentUser.role === 'yard_operator' && 'Operador de Pátio'}
                    {!['tecnico_mro','controlador_cco','supervisor_cco','admin','cco_dispatcher','maintenance_tech','yard_operator'].includes(currentUser.role) && (currentUser.roleLabel || currentUser.role)}
                  </div>
                </div>
              </button>
            ) : (
              <button
                id="btn-user-login"
                onClick={onOpenUserSwitcher}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition shadow cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Identificar Operador</span>
              </button>
            )}

            {/* Menu da Engrenagem (Movimentações, Relatórios Diários, Integração API, Auditoria, Regras e Gestão dos Perfis) */}
            <div className="relative" ref={menuRef}>
              <button
                id="btn-settings-menu"
                type="button"
                onClick={() => setIsMenuOpen((prev) => !prev)}
                className={`p-2 rounded-lg border transition cursor-pointer flex items-center justify-center ${
                  isMenuOpen
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/50 ring-2 ring-amber-500/30'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border-slate-700'
                }`}
                title="Menu CCO: Movimentações, Relatórios, Integração API, Auditoria, Regras e Gestão de Perfis"
                aria-label="Abrir Menu de Configurações e Módulos CCO"
                aria-expanded={isMenuOpen}
              >
                <Settings className={`w-4 h-4 transition-transform duration-300 ${isMenuOpen ? 'rotate-90 text-amber-400' : ''}`} />
              </button>

              {isMenuOpen && (
                <div 
                  className="absolute right-0 mt-2 w-72 sm:w-80 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl shadow-black/80 py-2 z-50 animate-in fade-in zoom-in-95 duration-150 backdrop-blur-xl"
                  role="menu"
                >
                  {/* Menu Header */}
                  <div className="px-3.5 py-2 border-b border-slate-800">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Settings className="w-3.5 h-3.5 text-amber-400" />
                      <span>Menu CCO & Módulos Operacionais</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Acesso rápido aos relatórios, manobras e cadastros
                    </p>
                  </div>

                  {/* Menu Options */}
                  <div className="p-1.5 space-y-1 text-xs">
                    {/* Sinóptico CCO (Mapa do Pátio) */}
                    <button
                      type="button"
                      onClick={() => {
                        onSelectTab('yard');
                        setIsMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition text-left cursor-pointer ${
                        currentTab === 'yard'
                          ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-md ${currentTab === 'yard' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
                          <Layers className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight">Sinóptico CCO (Mapa do Pátio)</div>
                          <div className="text-[10px] text-slate-400">Monitoramento em tempo real das vias e vagas</div>
                        </div>
                      </div>
                      {currentTab === 'yard' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>}
                    </button>

                    {/* Movimentações e Históricos */}
                    <button
                      type="button"
                      onClick={() => {
                        onSelectTab('movements');
                        setIsMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition text-left cursor-pointer ${
                        currentTab === 'movements'
                          ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-md ${currentTab === 'movements' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
                          <Train className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight">Movimentações & Histórico</div>
                          <div className="text-[10px] text-slate-400">Registro e ciclo de vida de manobras</div>
                        </div>
                      </div>
                      {currentTab === 'movements' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>}
                    </button>

                    {/* Relatórios Diários */}
                    <button
                      type="button"
                      onClick={() => {
                        onSelectTab('reports');
                        setIsMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition text-left cursor-pointer ${
                        currentTab === 'reports'
                          ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-md ${currentTab === 'reports' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
                          <FileText className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight">Relatórios Diários (RDO)</div>
                          <div className="text-[10px] text-slate-400">Consolidado operacional e exportação PDF</div>
                        </div>
                      </div>
                      {currentTab === 'reports' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>}
                    </button>

                    {/* Integração API */}
                    <button
                      type="button"
                      onClick={() => {
                        onSelectTab('api');
                        setIsMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition text-left cursor-pointer ${
                        currentTab === 'api'
                          ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-md ${currentTab === 'api' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
                          <Share2 className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight">Integração API & Preventiva</div>
                          <div className="text-[10px] text-slate-400">Sincronização com SAP PM e Maximo</div>
                        </div>
                      </div>
                      {currentTab === 'api' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>}
                    </button>

                    {/* Auditoria CCO */}
                    <button
                      type="button"
                      onClick={() => {
                        onSelectTab('audit');
                        setIsMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition text-left cursor-pointer ${
                        currentTab === 'audit'
                          ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-md ${currentTab === 'audit' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
                          <Shield className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight">Auditoria CCO</div>
                          <div className="text-[10px] text-slate-400">Rastreabilidade completa de ações e manobras</div>
                        </div>
                      </div>
                      {currentTab === 'audit' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>}
                    </button>

                    {/* Regras e Alertas */}
                    <button
                      type="button"
                      onClick={() => {
                        onSelectTab('notifications');
                        setIsMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition text-left cursor-pointer ${
                        currentTab === 'notifications'
                          ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-md ${currentTab === 'notifications' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
                          <Bell className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight">Regras & Alertas CCO</div>
                          <div className="text-[10px] text-slate-400">Automação de regras e disparos de avisos</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {unreadCount > 0 && (
                          <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-[10px] font-bold text-white">
                            {unreadCount}
                          </span>
                        )}
                        {currentTab === 'notifications' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>}
                      </div>
                    </button>
                  </div>

                  {/* Divisor */}
                  <div className="border-t border-slate-800 my-1.5"></div>

                  {/* Gestão dos Perfis */}
                  <div className="p-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setIsMenuOpen(false);
                        if (onOpenUserManagement) {
                          onOpenUserManagement();
                        } else {
                          onOpenUserSwitcher();
                        }
                      }}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-200 transition text-left cursor-pointer group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="p-1.5 rounded-md bg-purple-500/20 text-purple-400 group-hover:bg-purple-500/30">
                          <Users className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight text-white flex items-center gap-1.5">
                            <span>Gestão dos Perfis</span>
                            <span className="px-1 py-0.2 rounded text-[9px] bg-purple-500/30 text-purple-300 font-mono">CCO</span>
                          </div>
                          <div className="text-[10px] text-purple-300/80">Cadastro, edição e controle de operadores</div>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
};
