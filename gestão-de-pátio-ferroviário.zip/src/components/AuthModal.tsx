import React, { useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { 
  PROFILE_CONFIG, 
  validateBadgeNumber, 
  formatBadgeNumber, 
  matchUserBadge,
  saveUser, 
  getStoredUsers, 
  setStoredUsers,
  setStoredSession,
  getClientDeviceName
} from '../utils/rbac';
import { apiService } from '../services/apiService';
import { 
  ShieldCheck, 
  User, 
  CheckCircle2, 
  X, 
  Lock, 
  Award, 
  Radio, 
  Wrench, 
  UserPlus, 
  LogIn, 
  AlertCircle,
  KeyRound,
  Monitor,
  Smartphone,
  AlertTriangle,
  Users,
  Laptop,
  RefreshCw
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  currentUser: UserProfile | null;
  onClose?: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  forceFirstAccess?: boolean;
  initialTab?: 'register' | 'login';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  currentUser,
  onClose,
  onLoginSuccess,
  forceFirstAccess = false,
  initialTab = 'login',
}) => {
  const [activeTab, setActiveTab] = useState<'register' | 'login'>(
    forceFirstAccess ? 'register' : initialTab
  );
  
  // Registration form state
  const [fullName, setFullName] = useState('');
  const [badgeNumber, setBadgeNumber] = useState('38-');
  const [selectedRole, setSelectedRole] = useState<'tecnico_mro' | 'controlador_cco' | 'supervisor_cco'>('controlador_cco');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Login form state
  const [loginBadge, setLoginBadge] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Unified Database state
  const [usersList, setUsersList] = useState<UserProfile[]>(() => getStoredUsers());
  const [loadingUsers, setLoadingUsers] = useState(false);

  // Synchronize initial tab
  useEffect(() => {
    if (isOpen) {
      if (forceFirstAccess) {
        setActiveTab('register');
      } else if (initialTab) {
        setActiveTab(initialTab);
      }
    }
  }, [isOpen, initialTab, forceFirstAccess]);

  // Fetch users from unified backend database when modal opens
  const fetchUnifiedUsers = async () => {
    try {
      setLoadingUsers(true);
      const res = await apiService.getUsers();
      if (res && Array.isArray(res.users) && res.users.length > 0) {
        setUsersList(res.users);
        setStoredUsers(res.users);
      }
    } catch (e) {
      console.warn('[Unified DB] Carregando usuários do cache local:', e);
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchUnifiedUsers();
    }
  }, [isOpen]);

  // Subscribe to real-time 'users_updated' SSE events (Windows & Mobile sync)
  useEffect(() => {
    const unsubscribe = apiService.subscribe('users_updated', (data: any) => {
      if (data && Array.isArray(data.users)) {
        setUsersList(data.users);
        setStoredUsers(data.users);
      }
    });
    return () => unsubscribe();
  }, []);

  // Close with Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && onClose) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  const handleBadgeChange = (val: string) => {
    const formatted = formatBadgeNumber(val);
    setBadgeNumber(formatted);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const trimmedName = fullName.trim();
    if (!trimmedName || trimmedName.length < 2) {
      setErrorMsg('Informe o nome do operador (ao menos 2 caracteres).');
      return;
    }

    const cleanBadge = formatBadgeNumber(badgeNumber);
    if (!validateBadgeNumber(cleanBadge)) {
      setErrorMsg('A matrícula deve conter ao menos 3 dígitos (ex: 38-12345 ou 12345).');
      return;
    }

    if (!password || password.length < 3) {
      setErrorMsg('A senha deve conter no mínimo 3 caracteres.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('A confirmação de senha não confere com a senha digitada.');
      return;
    }

    // Check if badge is already registered in unified database
    const existing = usersList.find(u => matchUserBadge(cleanBadge, u.badgeNumber));
    if (existing) {
      setErrorMsg(`A matrícula ${cleanBadge} já está cadastrada para o operador ${existing.name}. Acesse na aba "Entrar / Alternar".`);
      return;
    }

    const config = PROFILE_CONFIG[selectedRole];
    const clientDevice = getClientDeviceName();
    const newUser: UserProfile = {
      id: `usr-${Date.now().toString().slice(-6)}`,
      name: trimmedName,
      badgeNumber: cleanBadge,
      role: selectedRole as UserRole,
      roleLabel: config.label,
      department: config.department,
      password: password,
      createdDevice: clientDevice,
      createdAt: new Date().toISOString(),
      avatar: selectedRole === 'tecnico_mro'
        ? 'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=150&auto=format&fit=crop&q=80'
        : selectedRole === 'controlador_cco'
        ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    };

    setIsSubmitting(true);
    try {
      // Save directly to the unified server database and continuous storage
      const res = await apiService.registerUser(newUser, clientDevice);
      const saved = res.user || newUser;
      
      if (res.users && Array.isArray(res.users)) {
        setUsersList(res.users);
        setStoredUsers(res.users);
      } else {
        const updated = saveUser(saved);
        setUsersList(updated);
      }

      setStoredSession(saved);
      setSuccessMsg(`Perfil gravado com sucesso no banco de dados! Bem-vindo(a), ${saved.name}. Sincronizado para Windows e Mobile.`);

      setTimeout(() => {
        onLoginSuccess(saved);
        if (onClose) onClose();
      }, 700);
    } catch (err: any) {
      console.error('[Register Error]', err);
      // Fallback local persistence if server is briefly unavailable
      const updated = saveUser(newUser);
      setUsersList(updated);
      setStoredSession(newUser);
      setSuccessMsg(`Perfil salvo localmente e sincronizado. Bem-vindo(a), ${newUser.name}!`);
      setTimeout(() => {
        onLoginSuccess(newUser);
        if (onClose) onClose();
      }, 700);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const inputVal = loginBadge.trim();
    if (!inputVal) {
      setErrorMsg('Informe a matrícula ou identificação do operador.');
      return;
    }

    setIsSubmitting(true);
    try {
      const clientDevice = getClientDeviceName();
      let authenticatedUser: UserProfile | null = null;

      // 1. Authenticate with unified backend database first
      try {
        const res = await apiService.loginUser(inputVal, loginPassword, clientDevice);
        if (res && res.user) {
          authenticatedUser = res.user;
          if (res.users && Array.isArray(res.users)) {
            setUsersList(res.users);
            setStoredUsers(res.users);
          }
        }
      } catch (srvErr: any) {
        if (srvErr.message && srvErr.message.includes('Senha incorreta')) {
          throw srvErr;
        }
        // Fallback: continue to local check
      }

      // 2. Fallback check local users list with flexible matching
      if (!authenticatedUser) {
        const found = usersList.find(u => matchUserBadge(inputVal, u.badgeNumber, u.name));
        if (found) {
          if (found.password && loginPassword && found.password !== loginPassword.trim()) {
            setErrorMsg('Senha incorreta para a matrícula informada.');
            return;
          }
          authenticatedUser = found;
        }
      }

      if (!authenticatedUser) {
        setErrorMsg(`Nenhum operador localizado com "${inputVal}" no banco de dados. Verifique a digitação ou cadastre na aba "Primeiro Acesso".`);
        return;
      }

      // Save session and update stored state
      saveUser(authenticatedUser);
      setStoredSession(authenticatedUser);
      setSuccessMsg(`Login efetuado com sucesso! Bem-vindo(a), ${authenticatedUser.name}.`);

      setTimeout(() => {
        onLoginSuccess(authenticatedUser!);
        if (onClose) onClose();
      }, 500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro ao efetuar login.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickSelect = async (user: UserProfile) => {
    try {
      const clientDevice = getClientDeviceName();
      apiService.loginUser(user.badgeNumber, user.password || '123', clientDevice).catch(() => {});
    } catch (e) {
      // ignore
    }
    saveUser(user);
    setStoredSession(user);
    onLoginSuccess(user);
    if (onClose) onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-2 sm:p-4 overflow-hidden animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget && onClose) {
          onClose();
        }
      }}
    >
      <div 
        className="w-full max-w-lg sm:max-w-2xl max-h-[92vh] sm:max-h-[88vh] rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl flex flex-col text-slate-100 overflow-hidden my-auto animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-title"
      >
        
        {/* Header - Fixed/Pinned at Top */}
        <div className="shrink-0 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 px-3.5 sm:px-5 py-2.5 sm:py-3.5 border-b border-slate-800 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 sm:p-2 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 shrink-0">
              <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 id="auth-modal-title" className="text-xs sm:text-sm font-bold text-white tracking-wide truncate">
                  Banco Unificado de Logins & Perfis
                </h2>
                <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Windows & Mobile Sync
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 truncate">
                CCO Ferroviário VLT • Gestão Centralizada de Perfis e Acessos
              </p>
            </div>
          </div>
          {onClose && (
            <button
              id="btn-close-auth-modal"
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition active:scale-90 shrink-0 flex items-center justify-center min-w-[36px] min-h-[36px] cursor-pointer"
              title="Fechar janela (Esc)"
              aria-label="Fechar janela"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          )}
        </div>

        {/* Tab Navigation - Fixed/Pinned */}
        <div className="shrink-0 flex border-b border-slate-800 bg-slate-950/60">
          <button
            type="button"
            onClick={() => {
              setActiveTab('login');
              setErrorMsg(null);
            }}
            className={`flex-1 py-2 sm:py-2.5 px-2 sm:px-3 text-[11px] sm:text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === 'login'
                ? 'border-amber-500 text-amber-400 bg-amber-500/5 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <LogIn className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Entrar / Alternar</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('register');
              setErrorMsg(null);
            }}
            className={`flex-1 py-2 sm:py-2.5 px-2 sm:px-3 text-[11px] sm:text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === 'register'
                ? 'border-amber-500 text-amber-400 bg-amber-500/5 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Primeiro Acesso</span>
          </button>
        </div>

        {/* Scrollable Content Container */}
        <div className="flex-1 overflow-y-auto overscroll-contain">
          {/* Error / Success Feedback */}
          {errorMsg && (
            <div className="mx-3.5 sm:mx-5 mt-3 p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between gap-2 animate-in fade-in">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
              <button 
                type="button" 
                onClick={() => setErrorMsg(null)}
                className="text-rose-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          {successMsg && (
            <div className="mx-3.5 sm:mx-5 mt-3 p-2.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between gap-2 animate-in fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{successMsg}</span>
              </div>
              <button 
                type="button" 
                onClick={() => setSuccessMsg(null)}
                className="text-emerald-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* TAB 1: ENTRAR / ALTERNAR */}
          {activeTab === 'login' && (
            <div className="p-3.5 sm:p-5 space-y-3.5 sm:space-y-4">
              {/* Quick Operator Selector */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <span>Perfis Salvos no Banco Unificado</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-slate-800 text-slate-300 font-mono">
                      {usersList.length}
                    </span>
                  </h3>
                  <button
                    type="button"
                    onClick={fetchUnifiedUsers}
                    className="text-[10px] text-amber-400/90 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                    title="Atualizar lista com o banco de dados unificado"
                  >
                    <RefreshCw className={`w-3 h-3 ${loadingUsers ? 'animate-spin' : ''}`} />
                    <span>Sincronizar</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-[30vh] sm:max-h-[34vh] overflow-y-auto pr-1">
                  {usersList.map((user) => {
                    const isCurrent = currentUser?.id === user.id;
                    const isMro = user.role === 'tecnico_mro' || user.role === 'maintenance_tech';
                    const isCco = user.role === 'controlador_cco' || user.role === 'cco_dispatcher';
                    const isWin = user.deviceType === 'windows' || (user.createdDevice && /windows/i.test(user.createdDevice));
                    const isMob = user.deviceType === 'mobile' || (user.createdDevice && /mobile|android|iphone|ipad|celular/i.test(user.createdDevice));

                    return (
                      <div
                        key={user.id}
                        onClick={() => handleQuickSelect(user)}
                        className={`flex items-center justify-between p-2 sm:p-2.5 rounded-xl border transition-all cursor-pointer ${
                          isCurrent
                            ? 'bg-amber-500/10 border-amber-500/50 shadow-sm ring-1 ring-amber-500/30'
                            : 'bg-slate-800/60 border-slate-700/80 hover:bg-slate-800 hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img
                            src={user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                            alt={user?.name || 'Operador'}
                            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full object-cover border border-slate-700 shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h4 className="font-semibold text-xs sm:text-sm text-white truncate max-w-[140px] sm:max-w-[200px]">
                                {user.name}
                              </h4>
                              <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold shrink-0 ${
                                isMro ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                                isCco ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                                'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                              }`}>
                                {user.roleLabel}
                              </span>
                              {isWin && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] bg-blue-950/70 text-blue-300 border border-blue-500/30 flex items-center gap-1">
                                  <Laptop className="w-2.5 h-2.5" />
                                  <span className="hidden sm:inline">Windows</span>
                                </span>
                              )}
                              {isMob && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] bg-emerald-950/70 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                                  <Smartphone className="w-2.5 h-2.5" />
                                  <span className="hidden sm:inline">Mobile</span>
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                              <span className="font-mono font-bold text-amber-400/90">{user.badgeNumber}</span>
                              <span>•</span>
                              <span className="truncate max-w-[120px] sm:max-w-[180px]">{user.department}</span>
                            </div>
                          </div>
                        </div>

                        <div className="shrink-0 ml-2">
                          {isCurrent ? (
                            <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-bold text-[11px]">
                              <CheckCircle2 className="w-3 h-3" />
                              Ativo
                            </span>
                          ) : (
                            <button
                              type="button"
                              className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-[11px] font-semibold text-slate-200 transition"
                            >
                              Entrar
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Direct Login by Matrícula & Password */}
              <div className="border-t border-slate-800 pt-3">
                <h4 className="text-[11px] font-bold text-slate-300 mb-2">
                  Ou acesse com Matrícula e Senha:
                </h4>
                <form onSubmit={handleLoginSubmit} className="grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-2.5 items-end">
                  <div className="sm:col-span-5">
                    <label className="block text-[10px] text-slate-400 mb-1">Matrícula (ex: 38-12345 ou 12345)</label>
                    <input
                      type="text"
                      required
                      placeholder="38-XXXXX ou matrícula"
                      value={loginBadge}
                      onChange={(e) => setLoginBadge(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div className="sm:col-span-4">
                    <label className="block text-[10px] text-slate-400 mb-1">Senha</label>
                    <input
                      type="password"
                      required
                      placeholder="••••••"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div className="sm:col-span-3">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-600 text-amber-400 hover:text-amber-300 font-bold text-xs transition flex items-center justify-center gap-1.5 h-[34px] cursor-pointer disabled:opacity-50"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>{isSubmitting ? 'Acessando...' : 'Entrar'}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Bottom Actions */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                  <span>A gestão de perfis é exclusiva para Supervisores CCO logados na plataforma.</span>
                </span>

                {onClose && (
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-1.5 px-3.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Fechar</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: PRIMEIRO ACESSO / CADASTRO */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegister} className="p-3.5 sm:p-5 space-y-3 sm:space-y-3.5">
              <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/25 flex items-center gap-2 text-xs text-blue-300">
                <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
                <span>
                  O cadastro será salvo no <strong>banco de dados unificado</strong> e estará imediatamente disponível tanto no Windows quanto em celulares (Mobile).
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                {/* Full Name */}
                <div>
                  <label className="block text-[11px] sm:text-xs font-semibold text-slate-300 mb-1">
                    Nome e Sobrenome <span className="text-amber-400">*</span>
                  </label>
                  <div className="relative">
                    <User className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-500" />
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Ex: Carlos Silva"
                      className="w-full pl-8 pr-2.5 py-1.5 sm:py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                {/* Badge Number */}
                <div>
                  <label className="block text-[11px] sm:text-xs font-semibold text-slate-300 mb-1">
                    Matrícula <span className="text-amber-400">* (38-00000)</span>
                  </label>
                  <div className="relative">
                    <Award className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-500" />
                    <input
                      type="text"
                      required
                      maxLength={12}
                      value={badgeNumber}
                      onChange={(e) => handleBadgeChange(e.target.value)}
                      placeholder="38-12345"
                      className="w-full pl-8 pr-2.5 py-1.5 sm:py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Profile Selection */}
              <div>
                <label className="block text-[11px] sm:text-xs font-semibold text-slate-300 mb-1.5">
                  Selecione o Perfil Ferroviário <span className="text-amber-400">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {/* 1. Técnico MRO */}
                  <div
                    onClick={() => setSelectedRole('tecnico_mro')}
                    className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                      selectedRole === 'tecnico_mro'
                        ? 'bg-emerald-500/10 border-emerald-500 shadow-sm ring-1 ring-emerald-500/40'
                        : 'bg-slate-800/60 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1 text-xs font-bold text-emerald-400">
                        <Wrench className="w-3.5 h-3.5" />
                        TÉCNICO MRO
                      </span>
                      {selectedRole === 'tecnico_mro' && (
                        <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      Oficina & Manutenção
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1.5 pt-1.5 border-t border-slate-700/50">
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 text-[9px] font-semibold">
                        Operacional
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-700/60 text-slate-300 text-[9px]">
                        Manobrador
                      </span>
                    </div>
                  </div>

                  {/* 2. Controlador CCO */}
                  <div
                    onClick={() => setSelectedRole('controlador_cco')}
                    className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                      selectedRole === 'controlador_cco'
                        ? 'bg-amber-500/10 border-amber-500 shadow-sm ring-1 ring-amber-500/40'
                        : 'bg-slate-800/60 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1 text-xs font-bold text-amber-400">
                        <Radio className="w-3.5 h-3.5" />
                        CONTROLADOR CCO
                      </span>
                      {selectedRole === 'controlador_cco' && (
                        <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      Controle Operacional
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1.5 pt-1.5 border-t border-slate-700/50">
                      <span className="px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 text-[9px] font-semibold">
                        Manutenção
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-700/60 text-slate-300 text-[9px]">
                        Manobras
                      </span>
                    </div>
                  </div>

                  {/* 3. Supervisor de CCO */}
                  <div
                    onClick={() => setSelectedRole('supervisor_cco')}
                    className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                      selectedRole === 'supervisor_cco'
                        ? 'bg-purple-500/10 border-purple-500 shadow-sm ring-1 ring-purple-500/40'
                        : 'bg-slate-800/60 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1 text-xs font-bold text-purple-300">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        SUPERVISOR CCO
                      </span>
                      {selectedRole === 'supervisor_cco' && (
                        <span className="w-2 h-2 rounded-full bg-purple-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      Supervisão & Gestão
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1.5 pt-1.5 border-t border-slate-700/50">
                      <span className="px-1.5 py-0.5 rounded bg-purple-500/15 text-purple-300 text-[9px] font-semibold">
                        Gestão Perfis
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-700/60 text-slate-300 text-[9px]">
                        Exclusão
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Password & Confirm */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                <div>
                  <label className="block text-[11px] sm:text-xs font-semibold text-slate-300 mb-1">
                    Senha de Acesso <span className="text-amber-400">*</span>
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-500" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Mínimo 4 caracteres"
                      className="w-full pl-8 pr-2.5 py-1.5 sm:py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] sm:text-xs font-semibold text-slate-300 mb-1">
                    Confirmar Senha <span className="text-amber-400">*</span>
                  </label>
                  <div className="relative">
                    <KeyRound className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-500" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repita a senha"
                      className="w-full pl-8 pr-2.5 py-1.5 sm:py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Submit & Close Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row gap-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-2 sm:py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-amber-500/20 transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-[0.99] disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSubmitting ? 'Salvando no Banco Unificado...' : 'Concluir Cadastro no Banco Unificado'}</span>
                </button>

                {onClose && (
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-2 sm:py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-medium text-xs sm:text-sm border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Fechar</span>
                  </button>
                )}
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
