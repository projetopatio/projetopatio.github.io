import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Monitor, Smartphone, X, CheckCircle2, Info } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showInstructionsModal, setShowInstructionsModal] = useState(false);

  // If already running as an installed PWA on Windows or Android
  if (isInstalled) {
    return (
      <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-medium">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
        <span>App Instalado</span>
      </div>
    );
  }

  return (
    <>
      <button
        id="btn-install-pwa"
        onClick={() => {
          if (isInstallable) {
            install();
          } else {
            setShowInstructionsModal(true);
          }
        }}
        title="Instalar App no Windows ou Android"
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold shadow-sm transition-colors cursor-pointer"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Instalar App (Windows & Android)</span>
        <span className="sm:hidden">Instalar</span>
      </button>

      {showInstructionsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-amber-400" />
                <h3 className="font-semibold text-base text-white">Instalar Motiva Pátio VLT CARIOCA</h3>
              </div>
              <button
                onClick={() => setShowInstructionsModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-sm text-slate-300">
              <div className="p-3 rounded-lg bg-slate-800/80 border border-slate-700/70">
                <div className="flex items-center gap-2 font-semibold text-amber-400 mb-1.5">
                  <Monitor className="w-4 h-4" />
                  <span>No Windows / Computador</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  1. No navegador (Chrome ou Edge), clique no ícone de <strong>Instalar</strong> no canto direito da barra de endereços (ou abra o menu <strong className="text-white">...</strong> e selecione <strong>Apps &rarr; Instalar este site como aplicativo</strong>).<br />
                  2. O sistema abrirá em uma janela nativa com suporte a atalhos e teclado de CCO.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-800/80 border border-slate-700/70">
                <div className="flex items-center gap-2 font-semibold text-sky-400 mb-1.5">
                  <Smartphone className="w-4 h-4" />
                  <span>No Android / Tablet ou Celular</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  1. No Chrome do Android, toque no menu <strong className="text-white">&vellip;</strong> no canto superior direito.<br />
                  2. Selecione <strong className="text-white">Adicionar à tela inicial</strong> ou <strong className="text-white">Instalar aplicativo</strong>.<br />
                  3. O ícone oficial será adicionado para acesso rápido em campo mesmo offline.
                </p>
              </div>

              {isIOS && (
                <div className="p-3 rounded-lg bg-slate-800/80 border border-slate-700/70">
                  <div className="flex items-center gap-2 font-semibold text-emerald-400 mb-1.5">
                    <Info className="w-4 h-4" />
                    <span>No iOS (iPhone / iPad)</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Toque no botão <strong>Compartilhar</strong> no Safari e depois em <strong>Adicionar à Tela de Início</strong>.
                  </p>
                </div>
              )}
            </div>

            <button
              onClick={() => setShowInstructionsModal(false)}
              className="mt-5 w-full py-2 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
            >
              Entendido / Fechar
            </button>
          </div>
        </div>
      )}
    </>
  );
};
