import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { YardTrack, TrainVehicle, UserProfile, TrackStatus, YardSpot, MovementType, ActiveManobradorState } from '../types';
import { getTrainTheme } from '../utils/trainStatus';
import { getVehicleIconUri } from '../utils/trainIcon';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Sparkles,
  Smartphone,
  Tablet,
  Monitor,
  Maximize2,
  Minimize2,
  HelpCircle,
  Check,
  CheckCircle2,
  Compass,
  Layers,
  KeyRound,
  Lock,
  Unlock
} from 'lucide-react';

// Bounding boxes dos setores reais do pátio para enquadramento perfeito sem zoom
const YARD_SECTORS = {
  all: {
    id: 'all',
    label: 'Pátio Completo',
    shortLabel: 'Geral',
    minX: 375,
    minY: 30,
    width: 680,
    height: 530,
  },
  parking: {
    id: 'parking',
    label: 'Estacionamento (E1 a E6)',
    shortLabel: 'E1–E6',
    minX: 575,
    minY: 30,
    width: 480,
    height: 390,
  },
  maintenance: {
    id: 'maintenance',
    label: 'Oficinas & MNT (P1–TR)',
    shortLabel: 'Oficinas',
    minX: 375,
    minY: 30,
    width: 195,
    height: 330,
  },
  departure: {
    id: 'departure',
    label: 'Linhas 7 & 8 (L1, L2, BP, LP, ES, TF)',
    shortLabel: 'L1–L2 / TF',
    minX: 375,
    minY: 430,
    width: 680,
    height: 130,
  },
};

type SectorKey = keyof typeof YARD_SECTORS;

interface YardSynopticMapProps {
  tracks: YardTrack[];
  vehicles: TrainVehicle[];
  currentUser?: UserProfile;
  activeManobrador?: ActiveManobradorState | null;
  onToggleManobrador?: () => void;
  onSelectTrack: (track: YardTrack, spot?: YardSpot) => void;
  onSelectVehicle: (vehicle: TrainVehicle) => void;
  onNewMovementWithTrack?: (trackId: string, spotId?: string, forcedType?: MovementType, entryOnly?: boolean) => void;
}

export const YardSynopticMap: React.FC<YardSynopticMapProps> = ({
  tracks,
  vehicles,
  currentUser,
  activeManobrador,
  onToggleManobrador,
  onSelectTrack,
  onSelectVehicle,
  onNewMovementWithTrack,
}) => {
  // Zoom state (inicia no enquadramento ótimo calculado)
  const [zoom, setZoom] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Responsive device container sizing
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [containerDimensions, setContainerDimensions] = useState<{ width: number; height: number }>({
    width: 1200,
    height: 620,
  });
  const [deviceCategory, setDeviceCategory] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [selectedSector, setSelectedSector] = useState<SectorKey>('all');
  const [showHelpOverlay, setShowHelpOverlay] = useState<boolean>(false);

  // Auto-calibração no carregamento e ao redimensionar
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen]);

  // ResizeObserver para calibração matemática contínua e exata do dispositivo utilizado
  useEffect(() => {
    if (!containerRef.current) return;
    const updateDimensions = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const w = Math.round(rect.width) || (window.innerWidth < 640 ? 360 : 1200);
      const h = Math.round(rect.height) || (window.innerWidth < 640 ? 440 : 620);
      setContainerDimensions({ width: w, height: h });

      if (w < 640 || window.innerWidth < 640) {
        setDeviceCategory('mobile');
      } else if (w < 1024 || window.innerWidth < 1024) {
        setDeviceCategory('tablet');
      } else {
        setDeviceCategory('desktop');
      }
    };

    updateDimensions();
    const observer = new ResizeObserver(updateDimensions);
    observer.observe(containerRef.current);
    window.addEventListener('resize', updateDimensions);

    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updateDimensions);
    };
  }, []);

  // Cálculo Dinâmico do ViewBox que Elimina Espaços Vazios e Fixa o Melhor Tamanho por Dispositivo
  const dynamicViewBox = useMemo(() => {
    const sector = YARD_SECTORS[selectedSector] || YARD_SECTORS.all;
    const contW = Math.max(100, containerDimensions.width);
    const contH = Math.max(100, containerDimensions.height);
    const targetAspect = contW / contH;
    const contentAspect = sector.width / sector.height;

    // Se o contêiner for mais largo que o conteúdo, expande horizontalmente mantendo o mapa centralizado
    if (targetAspect > contentAspect) {
      const newWidth = sector.height * targetAspect;
      const extraWidth = newWidth - sector.width;
      const newX = sector.minX - extraWidth / 2;
      return `${newX.toFixed(1)} ${sector.minY.toFixed(1)} ${newWidth.toFixed(1)} ${sector.height.toFixed(1)}`;
    } else {
      // Se for mais alto (como em smartphones verticais), expande verticalmente mantendo centralizado
      const newHeight = sector.width / targetAspect;
      const extraHeight = newHeight - sector.height;
      const newY = sector.minY - extraHeight / 2;
      return `${sector.minX.toFixed(1)} ${newY.toFixed(1)} ${sector.width.toFixed(1)} ${newHeight.toFixed(1)}`;
    }
  }, [containerDimensions, selectedSector]);

  // Função para enquadrar o setor no dispositivo sempre centralizado
  const handleResetDeviceView = useCallback((sector: SectorKey = selectedSector) => {
    setSelectedSector(sector);
    // No smartphone, o fator 1.15 oferece nitidez imediata sem obrigar o operador a dar zoom manual
    const isMobile = window.innerWidth < 640 || containerDimensions.width < 640;
    const optimalZoom = isMobile && sector === 'all' ? 1.15 : 1;
    setZoom(optimalZoom);
    playRelayClick(520);
  }, [selectedSector, containerDimensions.width]);

  // Clean any stale custom positions
  useEffect(() => {
    try {
      localStorage.removeItem('yard_synoptic_custom_positions_v1');
    } catch (e) {}
  }, []);

  // Active route alignment
  const [activeRoutePath, setActiveRoutePath] = useState<string | null>('ROTA_PRINCIPAL');
  const [consoleMessage, setConsoleMessage] = useState<string>(
    'CMD: Sistema de Controle de Pátio Operacional. Pronto para alinhamento de rotas.'
  );

  const svgRef = useRef<SVGSVGElement | null>(null);

  // Sound effect generator for interlocking relay click
  const playRelayClick = (freq = 440) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch (e) {}
  };

  // Route Request handler
  const handleTrackRouteClick = (trackCode: string, trackObj?: YardTrack) => {
    // REGRA DE IMPEDIMENTO: Verifica se a via de destino está ocupada (sem vagas)
    const isOccupied = trackObj ? (
      trackObj.spots && trackObj.spots.length > 0
        ? trackObj.spots.every(s => s.status !== 'free')
        : (trackObj.assignedVehicles.length >= (trackObj.capacityWagons || 1) || trackObj.status === 'critical')
    ) : false;

    if (isOccupied) {
      playRelayClick(220); // tom grave de alerta de bloqueio
      setConsoleMessage(
        `⛔ BLOQUEIO DE INTERTRAVAMENTO: Manobra impedida para Via ${trackCode}! A via está totalmente ocupada sem vagas disponíveis.`
      );
      if (trackObj) {
        onSelectTrack(trackObj);
      }
      return;
    }

    // REGRA OPERACIONAL VIA TF: Via de Transferência
    if (trackCode === 'TF' && trackObj) {
      const isFree = trackObj.spots && trackObj.spots.length > 0
        ? trackObj.spots.every(s => s.status === 'free')
        : trackObj.assignedVehicles.length === 0;

      if (isFree) {
        playRelayClick(780);
        setConsoleMessage(
          `Via TF (Transferência) selecionada. Disponível para Entrada Comercial ou Manobras do interior do pátio.`
        );
        onSelectTrack(trackObj);
        onNewMovementWithTrack?.(trackObj.id, trackObj.spots?.[0]?.id, undefined, false);
        return;
      }
    }

    playRelayClick(660);
    setActiveRoutePath(`ROTA_${trackCode}`);
    setConsoleMessage(
      `CMD: Rota alinhada para Via ${trackCode}. Intertravamento operacional seguro.`
    );
    if (trackObj) {
      onSelectTrack(trackObj);
    }
  };

  // Tracks lookup
  const getTrackByCode = (code: string) => tracks.find(t => t.code === code);
  const trackP2 = getTrackByCode('P2');
  const trackP1 = getTrackByCode('P1');
  const trackCR = getTrackByCode('CR');
  const trackMC = getTrackByCode('MC');
  const trackL1 = getTrackByCode('L1');
  const trackL2 = getTrackByCode('L2');
  const trackES = getTrackByCode('ES');
  const trackTR = getTrackByCode('TR');
  const trackTF = getTrackByCode('TF');
  const trackE1 = getTrackByCode('E1');
  const trackE2 = getTrackByCode('E2');
  const trackE3 = getTrackByCode('E3');
  const trackE4 = getTrackByCode('E4');
  const trackE5 = getTrackByCode('E5');
  const trackE6 = getTrackByCode('E6');
  const trackLP = getTrackByCode('LP');
  const trackBP = getTrackByCode('BP');

  // Helper to get spot by letter position (A, B, C)
  const getSpotByLetter = (track: YardTrack | undefined, letter: 'A' | 'B' | 'C') => {
    if (!track?.spots) return undefined;
    return track.spots.find(s => s.positionLetter === letter) || 
           (letter === 'A' ? track.spots[0] : letter === 'B' ? track.spots[1] : track.spots[2]);
  };

  // Render a specific occupancy point on a track
  const renderTrackSpot = (
    spot: YardSpot | undefined,
    track: YardTrack | undefined,
    x: number,
    y: number,
    width: number = 96,
    height: number = 28
  ) => {
    if (!spot || !track) return null;

    const vehicle = spot.vehicleId ? vehicles.find(v => v.id === spot.vehicleId) : null;
    const isOccupied = spot.status === 'occupied' && !!vehicle;
    const isMaintenance = spot.status === 'maintenance' && !!vehicle;

    const isPriorityRule = track.parkingRule?.type === 'end_of_track_first' || 
      ['E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'LP'].includes(track.code);

    const freeSpotsOnTrack = isPriorityRule 
      ? (track.spots || []).filter(s => s.status === 'free').sort((a, b) => (a.priority || 99) - (b.priority || 99))
      : [];
    const isHighestPriorityFree = freeSpotsOnTrack.length > 0 && freeSpotsOnTrack[0].id === spot.id;

    if (isOccupied || isMaintenance) {
      const compNum = vehicle?.compositionNumber || (vehicle?.id ? parseInt(vehicle.id.replace(/\D/g, '')) : 101);
      const imgSrc = getVehicleIconUri(vehicle);
      const trainTheme = getTrainTheme(vehicle);

      // Proportional sizing for composition and spot
      const compWidth = Math.round(width * 1.32);
      const compHeight = Math.round(height * 1.32);
      const drawX = Math.round(x - (compWidth - width) / 2);
      const drawY = Math.round(y - (compHeight - height) / 2);

      return (
        <g 
          key={spot.id}
          className="cursor-pointer group select-none"
          onClick={(e) => {
            e.stopPropagation();
            onSelectTrack(track, spot);
            if (vehicle) onSelectVehicle(vehicle);
            setConsoleMessage(`Via ${track.code} • ${spot.positionName || `Vaga ${spot.spotNumber}`}: Ocupada por ${vehicle?.name || 'TUE'} [Status: ${trainTheme.label}]`);
          }}
        >
          <title>{`${vehicle?.name || 'VLT'} • STATUS: ${trainTheme.label.toUpperCase()} • ${spot.positionName || `Vaga ${spot.spotNumber}`} • ${track.name}`}</title>
          
          {/* Boundary around occupied spot */}
          <rect
            x={drawX - 2}
            y={drawY - 2}
            width={compWidth + 4}
            height={compHeight + 4}
            rx={4}
            fill="#091420"
            stroke={trainTheme.strokeHex}
            strokeWidth="1.8"
            filter={trainTheme.id === 'em_manutencao' ? 'url(#redGlow)' : trainTheme.id === 'preparado_comercial' ? 'url(#greenGlow)' : 'url(#cyanGlow)'}
            className="group-hover:stroke-white transition"
          />

          {/* Train Composition Image */}
          <image
            href={imgSrc}
            x={drawX}
            y={drawY}
            width={compWidth}
            height={compHeight}
            preserveAspectRatio="xMidYMid meet"
          />

          {/* Composition Badge */}
          <rect
            x={drawX + compWidth - 38}
            y={drawY - 7}
            width={36}
            height={12}
            rx={2.5}
            fill={trainTheme.fillHex}
            stroke={trainTheme.strokeHex}
            strokeWidth="0.9"
          />
          <text
            x={drawX + compWidth - 20}
            y={drawY + 2.5}
            fill="#ffffff"
            fontSize="8.5"
            fontWeight="bold"
            fontFamily="monospace"
            textAnchor="middle"
          >
            {compNum}
          </text>

          {/* Status Chip beneath */}
          <rect
            x={drawX + compWidth - 38}
            y={drawY + compHeight - 4}
            width={36}
            height={10}
            rx={2}
            fill="#091420"
            stroke={trainTheme.strokeHex}
            strokeWidth="0.8"
          />
          <text
            x={drawX + compWidth - 20}
            y={drawY + compHeight + 3.5}
            fill={trainTheme.strokeHex}
            fontSize="6.5"
            fontWeight="bold"
            fontFamily="monospace"
            textAnchor="middle"
          >
            {trainTheme.shortLabel}
          </text>

          {/* Position Letter Badge */}
          {spot.positionLetter && (
            <g>
              <rect
                x={drawX - 2}
                y={drawY - 7}
                width={19}
                height={12}
                rx={2.5}
                fill="#0f172a"
                stroke="#38bdf8"
                strokeWidth="0.9"
              />
              <text
                x={drawX + 7.5}
                y={drawY + 2.5}
                fill="#38bdf8"
                fontSize="8"
                fontWeight="bold"
                fontFamily="sans-serif"
                textAnchor="middle"
              >
                {spot.positionLetter}
              </text>
            </g>
          )}

          {/* Indicação Celular Operacional na parte inferior esquerda: "Cel" */}
          {vehicle?.hasOperationalPhone && (
            <g className="select-none pointer-events-none">
              <rect
                x={drawX - 2}
                y={drawY + compHeight - 5}
                width={26}
                height={11}
                rx={2.5}
                fill="#059669"
                stroke="#34d399"
                strokeWidth="0.9"
              />
              <text
                x={drawX + 11}
                y={drawY + compHeight + 3.5}
                fill="#ffffff"
                fontSize="7.5"
                fontWeight="900"
                fontFamily="monospace"
                textAnchor="middle"
              >
                Cel
              </text>
            </g>
          )}
        </g>
      );
    }

    // Free space
    const isTfFreeSpot = track.code === 'TF';
    const spotWidth = Math.round(width * 1.15);
    const spotHeight = Math.round(height * 1.15);
    const drawSpotX = Math.round(x - (spotWidth - width) / 2);
    const drawSpotY = Math.round(y - (spotHeight - height) / 2);

    return (
      <g
        key={spot.id}
        className="cursor-pointer group select-none"
        onClick={(e) => {
          e.stopPropagation();
          if (isTfFreeSpot) {
            playRelayClick(780);
            setConsoleMessage(`Via TF (Transferência) selecionada. Disponível para Entrada Comercial ou Manobras.`);
            onSelectTrack(track, spot);
            onNewMovementWithTrack?.(track.id, spot.id, undefined, false);
            return;
          }

          onSelectTrack(track, spot);
          if (spot.positionLetter) {
            setConsoleMessage(`Regra Operacional: Via ${track.code} • ${spot.positionName || `Posição ${spot.positionLetter}`} selecionada.`);
          }
        }}
      >
        <title>{isTfFreeSpot ? 'Via TF Livre • Entrada de Trem (Via Comercial) ou Manobras do Interior do Pátio' : `${spot.positionName || 'Espaço Livre'} • ${track.name} ${isHighestPriorityFree ? '(Próxima Vaga Recomendada)' : ''}`}</title>
        <rect
          x={drawSpotX}
          y={drawSpotY}
          width={spotWidth}
          height={spotHeight}
          rx={4}
          fill={isTfFreeSpot ? '#082f49' : isHighestPriorityFree ? '#062e26' : '#0c1824'}
          fillOpacity={isTfFreeSpot ? '0.95' : isHighestPriorityFree ? '0.95' : '0.85'}
          stroke={isTfFreeSpot ? '#38bdf8' : isHighestPriorityFree ? '#10b981' : '#334155'}
          strokeWidth={isTfFreeSpot || isHighestPriorityFree ? '1.6' : '1.2'}
          strokeDasharray={isTfFreeSpot ? 'none' : isHighestPriorityFree ? 'none' : '3,3'}
          className={isTfFreeSpot ? 'group-hover:stroke-cyan-300 group-hover:fill-[#0c4a6e] transition' : 'group-hover:stroke-sky-400 group-hover:fill-[#102334] transition'}
        />
        <line
          x1={drawSpotX + 4}
          y1={drawSpotY + spotHeight / 2}
          x2={drawSpotX + spotWidth - 4}
          y2={drawSpotY + spotHeight / 2}
          stroke={isTfFreeSpot ? '#0284c7' : isHighestPriorityFree ? '#059669' : '#1e293b'}
          strokeWidth="1.5"
          strokeDasharray={isTfFreeSpot || isHighestPriorityFree ? 'none' : '4,2'}
        />

        {isTfFreeSpot ? (
          <text
            x={drawSpotX + spotWidth / 2}
            y={drawSpotY + spotHeight / 2 + 3}
            fill="#38bdf8"
            fontSize="8"
            fontFamily="sans-serif"
            fontWeight="bold"
            textAnchor="middle"
            className="group-hover:fill-white transition tracking-tight"
          >
            + ENTRAR / MANOBRAR
          </text>
        ) : spot.positionLetter ? (
          <text
            x={drawSpotX + spotWidth / 2}
            y={drawSpotY + spotHeight / 2 + 3}
            fill={isHighestPriorityFree ? '#34d399' : '#94a3b8'}
            fontSize="8.5"
            fontFamily="sans-serif"
            fontWeight="bold"
            textAnchor="middle"
            className="group-hover:fill-sky-300 transition"
          >
            {`POS. ${spot.positionLetter} ${isHighestPriorityFree ? '★' : ''}`}
          </text>
        ) : (
          <text
            x={drawSpotX + spotWidth / 2}
            y={drawSpotY + spotHeight / 2 + 3}
            fill="#64748b"
            fontSize="8.5"
            fontFamily="sans-serif"
            fontWeight="bold"
            textAnchor="middle"
            className="group-hover:fill-sky-300 transition"
          >
            LIVRE
          </text>
        )}
      </g>
    );
  };

  return (
    <div className={
      isFullscreen
        ? "fixed inset-0 z-50 flex flex-col bg-[#14222d] p-2 sm:p-3 text-slate-100 font-mono select-none overflow-hidden shadow-2xl"
        : "flex flex-col bg-[#14222d] border border-slate-700/80 rounded-xl overflow-hidden shadow-2xl text-slate-100 font-mono select-none"
    }>
      
      {/* CCO Sinóptico Header Bar com Calibração Fixa por Dispositivo */}
      <div className="bg-[#0e171f] px-3 sm:px-4 py-2 border-b border-slate-700 flex flex-wrap items-center justify-between gap-2.5 text-xs shrink-0">
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="font-bold text-slate-200 tracking-wider uppercase text-[11px]">
              Sinóptico CCO &bull; Pátio VLT
            </span>
          </div>

          {/* Badge de Dispositivo Ativo */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-800/90 text-amber-300 font-mono text-[10px] border border-amber-500/30">
            {deviceCategory === 'mobile' ? (
              <>
                <Smartphone className="w-3 h-3 text-amber-400 shrink-0" />
                <span>mobile</span>
              </>
            ) : (
              <>
                <Monitor className="w-3 h-3 text-amber-400 shrink-0" />
                <span>desktop cco</span>
              </>
            )}
          </div>

          {/* Botão Assumir Manobrador no Cabeçalho do Sinóptico */}
          {onToggleManobrador && (
            <button
              type="button"
              onClick={onToggleManobrador}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition border cursor-pointer ${
                activeManobrador
                  ? activeManobrador.userId === currentUser?.id
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 hover:bg-emerald-500/30 shadow-sm animate-pulse'
                    : 'bg-rose-500/20 border-rose-500/60 text-rose-300 hover:bg-rose-500/30'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 border-amber-400 shadow-sm'
              }`}
              title={
                activeManobrador
                  ? activeManobrador.userId === currentUser?.id
                    ? 'Manobrador Ativo: Você. Clique para liberar exclusividade.'
                    : `Pátio trancado pelo Manobrador: ${activeManobrador.userName}.`
                  : 'Clique para assumir a função de Manobrador exclusivo.'
              }
            >
              {activeManobrador ? (
                activeManobrador.userId === currentUser?.id ? (
                  <>
                    <Unlock className="w-3 h-3 text-emerald-400 shrink-0" />
                    <span>MANOBRADOR (ATIVO)</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3 h-3 text-rose-400 shrink-0" />
                    <span className="truncate max-w-[120px] sm:max-w-none">
                      TRANCADO: {activeManobrador.userName.split(' ')[0]}
                    </span>
                  </>
                )
              ) : (
                <>
                  <KeyRound className="w-3 h-3 text-slate-950 shrink-0" />
                  <span>Assumir Manobrador</span>
                </>
              )}
            </button>
          )}

          {/* Status Color Legend (oculto em telas muito compactas para não poluir) */}
          <div className="hidden xl:flex items-center gap-2 px-2.5 py-0.5 rounded bg-slate-800/80 border border-slate-700 text-[10px]">
            <span className="text-slate-400 font-semibold">Trens:</span>
            <span className="flex items-center gap-1 font-bold text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              Manutenção
            </span>
            <span className="text-slate-600">&bull;</span>
            <span className="flex items-center gap-1 font-bold text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Prep. Comercial
            </span>
            <span className="text-slate-600">&bull;</span>
            <span className="flex items-center gap-1 font-bold text-sky-400">
              <span className="w-2 h-2 rounded-full bg-sky-400" />
              Operacional
            </span>
          </div>
        </div>

        {/* Setores de Enquadramento Imediato & Controles de Vista Fixa */}
        <div className="flex items-center flex-wrap gap-1.5 w-full sm:w-auto justify-between sm:justify-end">
          {/* Seletor Rápido de Setores (Evita qualquer necessidade de zoom no celular) */}
          <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-slate-700/80 text-[10px]">
            {(Object.keys(YARD_SECTORS) as SectorKey[]).map((key) => {
              const sec = YARD_SECTORS[key];
              const isSelected = selectedSector === key;
              return (
                <button
                  key={key}
                  onClick={() => handleResetDeviceView(key)}
                  className={`px-2 py-1 rounded transition whitespace-nowrap cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                  title={`Enquadrar ${sec.label} no melhor tamanho para o dispositivo`}
                >
                  <span className="sm:hidden">{sec.shortLabel}</span>
                  <span className="hidden sm:inline">{sec.shortLabel}</span>
                </button>
              );
            })}
          </div>

          {/* Botão de Tela Cheia / Maximizar */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className={`flex items-center gap-1 px-2 py-1 rounded border text-[11px] font-semibold transition cursor-pointer ${
              isFullscreen
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-sm'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
            }`}
            title={isFullscreen ? 'Sair da Tela Cheia (Esc)' : 'Expandir mapa na tela inteira do dispositivo'}
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-3 h-3 text-slate-950 shrink-0" />
                <span className="hidden md:inline">Restaurar</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3 h-3 text-amber-400 shrink-0" />
                <span className="hidden md:inline">Tela Cheia</span>
              </>
            )}
          </button>

          {/* Controles Secundários de Zoom */}
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setZoom(prev => Math.min(2.5, prev + 0.15))}
              className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
              title="Aumentar Zoom (+)"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
            <span className="text-[9px] font-mono px-1 text-slate-400 min-w-[34px] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => setZoom(prev => Math.max(0.6, prev - 0.15))}
              className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
              title="Diminuir Zoom (-)"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <button
              onClick={() => handleResetDeviceView(selectedSector)}
              className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
              title="Resetar para Enquadramento Ideal"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>

          {/* Botão de Ajuda Operacional */}
          <button
            onClick={() => setShowHelpOverlay(!showHelpOverlay)}
            className={`p-1 rounded border transition cursor-pointer ${
              showHelpOverlay 
                ? 'bg-amber-500 text-slate-950 border-amber-400' 
                : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border-slate-700'
            }`}
            title="Dicas de Operação & Interatividade"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SVG Interactive Canvas: Sempre Centralizado, sem drag-and-drop */}
      <div 
        ref={containerRef}
        className={`relative w-full ${
          isFullscreen 
            ? 'flex-1 min-h-[480px]' 
            : 'h-[440px] sm:h-[500px] md:h-[580px] lg:h-[660px] xl:h-[720px]'
        } overflow-hidden bg-[#16232c] flex items-center justify-center select-none`}
      >
        <svg
          ref={svgRef}
          viewBox={dynamicViewBox}
          preserveAspectRatio="xMidYMid meet"
          draggable={false}
          onDragStart={(e) => e.preventDefault()}
          className="w-full h-full transition-transform duration-100 ease-out select-none"
          style={{
            transform: `scale(${zoom})`,
            transformOrigin: 'center center',
            userSelect: 'none',
            WebkitUserSelect: 'none',
          }}
        >
          {/* Subtle Grid Background & Visual Filters */}
          <defs>
            <pattern id="synopticGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1d2e3b" strokeWidth="0.8" />
            </pattern>
            <filter id="cyanGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="2.5" floodColor="#00b4d8" floodOpacity="0.7"/>
            </filter>
            <filter id="redGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#ef4444" floodOpacity="0.8"/>
            </filter>
            <filter id="greenGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="2.5" floodColor="#22c55e" floodOpacity="0.8"/>
            </filter>
          </defs>

          {/* Grid Canvas Background (cobre qualquer proporção do dispositivo sem bordas pretas) */}
          <rect x="-1500" y="-1500" width="5000" height="4000" fill="#14212b" />
          <rect x="-1500" y="-1500" width="5000" height="4000" fill="url(#synopticGrid)" />

          {/* ========================================================================= */}
          {/* TRACKS, SPOTS AND OCCUPANCY RENDERING (CONFORME DESENHO DO PÁTIO)          */}
          {/* ========================================================================= */}

          {/* --- SETOR ESQUERDO: P2, P1, CR, MC, TR (LINHAS 1 A 5) COM NOMES À ESQUERDA --- */}
          {/* Espaçamento reduzido e aproximado do setor central (plaquetas x=390, vagas x=445) */}

          {/* Track P2 (Row 1) */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('P2', trackP2)}>
            <rect x="390" y="52" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="408" y="69" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">P2</text>
            {renderTrackSpot(trackP2?.spots[0], trackP2, 445, 50, 96, 28)}
          </g>

          {/* Track P1 (Row 2) */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('P1', trackP1)}>
            <rect x="390" y="117" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="408" y="134" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">P1</text>
            {renderTrackSpot(trackP1?.spots[0], trackP1, 445, 115, 96, 28)}
          </g>

          {/* Track CR (Row 3) */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('CR', trackCR)}>
            <rect x="390" y="182" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="408" y="199" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">CR</text>
            {renderTrackSpot(trackCR?.spots[0], trackCR, 445, 180, 96, 28)}
          </g>

          {/* Track MC (Row 4) */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('MC', trackMC)}>
            <rect x="390" y="247" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="408" y="264" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">MC</text>
            {renderTrackSpot(trackMC?.spots[0], trackMC, 445, 245, 96, 28)}
          </g>

          {/* Track TR (Row 5) */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('TR', trackTR)}>
            <rect x="390" y="312" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="408" y="329" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">TR</text>
            {renderTrackSpot(trackTR?.spots[0], trackTR, 445, 310, 96, 28)}
          </g>

          {/* (ESPAÇO VAZIO NA LINHA 6 À ESQUERDA, ENTRE TR E L2 CONFORME DESENHO) */}

          {/* Track L2 (Row 7): Alinhada horizontalmente com BP e LP */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('L2', trackL2)}>
            <rect x="390" y="452" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="408" y="469" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">L2</text>
            {renderTrackSpot(trackL2?.spots[0], trackL2, 445, 450, 96, 28)}
          </g>

          {/* Track L1 (Row 8): Alinhada horizontalmente com ES e TF */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('L1', trackL1)}>
            <rect x="390" y="522" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="408" y="539" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">L1</text>
            {renderTrackSpot(trackL1?.spots[0], trackL1, 445, 520, 96, 28)}
          </g>

          {/* --- SETOR DIREITO: ESTACIONAMENTO E1-E6 (LINHAS 1 A 6) --- */}

          {/* Track E1 (Row 1): 2 Vagas (B, A) conectadas */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('E1', trackE1)}>
            <line x1="851" y1="64" x2="890" y2="64" stroke="#334155" strokeWidth="2.5" />
            {renderTrackSpot(getSpotByLetter(trackE1, 'B'), trackE1, 755, 50, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE1, 'A'), trackE1, 890, 50, 96, 28)}
            <rect x="1005" y="52" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="69" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">E1</text>
          </g>

          {/* Track E2 (Row 2): 2 Vagas (B, A) conectadas */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('E2', trackE2)}>
            <line x1="851" y1="129" x2="890" y2="129" stroke="#334155" strokeWidth="2.5" />
            {renderTrackSpot(getSpotByLetter(trackE2, 'B'), trackE2, 755, 115, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE2, 'A'), trackE2, 890, 115, 96, 28)}
            <rect x="1005" y="117" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="134" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">E2</text>
          </g>

          {/* Track E3 (Row 3): 3 Vagas (C, B, A) conectadas */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('E3', trackE3)}>
            <line x1="686" y1="194" x2="755" y2="194" stroke="#334155" strokeWidth="2.5" />
            <line x1="851" y1="194" x2="890" y2="194" stroke="#334155" strokeWidth="2.5" />
            {renderTrackSpot(getSpotByLetter(trackE3, 'C'), trackE3, 590, 180, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE3, 'B'), trackE3, 755, 180, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE3, 'A'), trackE3, 890, 180, 96, 28)}
            <rect x="1005" y="182" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="199" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">E3</text>
          </g>

          {/* Track E4 (Row 4): 3 Vagas (C, B, A) conectadas */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('E4', trackE4)}>
            <line x1="686" y1="259" x2="755" y2="259" stroke="#334155" strokeWidth="2.5" />
            <line x1="851" y1="259" x2="890" y2="259" stroke="#334155" strokeWidth="2.5" />
            {renderTrackSpot(getSpotByLetter(trackE4, 'C'), trackE4, 590, 245, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE4, 'B'), trackE4, 755, 245, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE4, 'A'), trackE4, 890, 245, 96, 28)}
            <rect x="1005" y="247" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="264" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">E4</text>
          </g>

          {/* Track E5 (Row 5): 3 Vagas (C, B, A) conectadas */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('E5', trackE5)}>
            <line x1="686" y1="324" x2="755" y2="324" stroke="#334155" strokeWidth="2.5" />
            <line x1="851" y1="324" x2="890" y2="324" stroke="#334155" strokeWidth="2.5" />
            {renderTrackSpot(getSpotByLetter(trackE5, 'C'), trackE5, 590, 310, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE5, 'B'), trackE5, 755, 310, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE5, 'A'), trackE5, 890, 310, 96, 28)}
            <rect x="1005" y="312" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="329" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">E5</text>
          </g>

          {/* Track E6 (Row 6): 3 Vagas (C, B, A) conectadas */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('E6', trackE6)}>
            <line x1="686" y1="389" x2="755" y2="389" stroke="#334155" strokeWidth="2.5" />
            <line x1="851" y1="389" x2="890" y2="389" stroke="#334155" strokeWidth="2.5" />
            {renderTrackSpot(getSpotByLetter(trackE6, 'C'), trackE6, 590, 375, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE6, 'B'), trackE6, 755, 375, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackE6, 'A'), trackE6, 890, 375, 96, 28)}
            <rect x="1005" y="377" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="394" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">E6</text>
          </g>

          {/* --- SETOR INFERIOR: LINHA 7 (L2 - BP - LP) E LINHA 8 (L1 - ES - TF) --- */}

          {/* Track BP (Row 7): 1 Vaga na Coluna C com a plaqueta BP imediatamente à direita da vaga */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('BP', trackBP)}>
            {renderTrackSpot(trackBP?.spots[0], trackBP, 590, 450, 96, 28)}
            <rect x="698" y="452" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="716" y="469" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">BP</text>
          </g>

          {/* Track LP (Row 7): 2 Vagas (B, A) conectadas, alinhadas à direita com a plaqueta LP no final */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('LP', trackLP)}>
            <line x1="851" y1="464" x2="890" y2="464" stroke="#334155" strokeWidth="2.5" />
            {renderTrackSpot(getSpotByLetter(trackLP, 'B'), trackLP, 755, 450, 96, 28)}
            {renderTrackSpot(getSpotByLetter(trackLP, 'A'), trackLP, 890, 450, 96, 28)}
            <rect x="1005" y="452" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="469" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">LP</text>
          </g>

          {/* Track ES (Row 8): 1 Vaga na Coluna C (abaixo da BP) com a plaqueta ES imediatamente à direita da vaga */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('ES', trackES)}>
            {renderTrackSpot(trackES?.spots[0], trackES, 590, 520, 96, 28)}
            <rect x="698" y="522" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="716" y="539" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">ES</text>
          </g>

          {/* Track TF (Row 8): 1 Vaga na Coluna A (abaixo da LP-A) com a plaqueta TF à direita */}
          <g className="cursor-pointer group" onClick={() => handleTrackRouteClick('TF', trackTF)}>
            {renderTrackSpot(trackTF?.spots[0], trackTF, 890, 520, 96, 28)}
            <rect x="1005" y="522" width="36" height="24" rx="4" fill="#ffffff" stroke="#1e293b" />
            <text x="1023" y="539" fill="#0f172a" fontSize="13" fontWeight="bold" textAnchor="middle">TF</text>
          </g>

        </svg>

        {/* Floating Quick Action Overlay (expansível / recolhível para não obstruir vias no mobile) */}
        {showHelpOverlay && (
          <div className="absolute bottom-3 left-3 bg-slate-900/95 border border-amber-500/40 backdrop-blur-md rounded-lg p-3 text-[10px] space-y-1.5 shadow-2xl max-w-[280px] pointer-events-auto z-20 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between gap-1.5 font-bold text-amber-400 border-b border-slate-800 pb-1">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Operação & Interatividade CCO
              </span>
              <button 
                onClick={() => setShowHelpOverlay(false)} 
                className="text-slate-400 hover:text-white text-xs px-1 hover:bg-slate-800 rounded"
              >
                ✕
              </button>
            </div>
            <p className="text-slate-300 text-[10px] leading-relaxed">
              &bull; <strong>Clique nas Vias (CR, P1, P2, E1–E6, LP, BP, ES)</strong> para inspecionar posições e composições.<br />
              &bull; <strong>Clique na Via TF:</strong> Permite registrar Entrada de Composição (origem Via Comercial) ou Manobras a partir do interior do pátio.<br />
              &bull; <strong>Bloqueio de Intertravamento:</strong> Manobras impedidas se a via de destino estiver ocupada.<br />
              &bull; <strong>Enquadramento e Centralização:</strong> O mapa se auto-ajusta ao dispositivo mantendo sempre o centro visual da malha.
            </p>
          </div>
        )}
      </div>

      {/* CCO Operational Command Prompt Console Line (From Image Bottom: "CMD: Rota - Solicitar...") */}
      <div className="bg-[#0b1219] px-4 py-2 border-t border-slate-800 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none font-mono">
          <span className="text-emerald-400 font-bold tracking-tight">&gt;&gt;</span>
          <span className="text-slate-300 font-medium whitespace-nowrap">
            {consoleMessage}
          </span>
        </div>

        <div className="hidden md:flex items-center gap-4 text-[11px] text-slate-400 pl-3 shrink-0">
          <span>Intertravamento: <strong className="text-emerald-400">NORMAL</strong></span>
          <span>Rede: <strong className="text-emerald-400">ONLINE (SSE)</strong></span>
        </div>
      </div>

    </div>
  );
};
