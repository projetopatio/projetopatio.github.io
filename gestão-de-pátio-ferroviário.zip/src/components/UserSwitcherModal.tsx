import React from 'react';
import { UserProfile, UserRole } from '../types';
import { INITIAL_USERS } from '../data/initialData';
import { ShieldCheck, User, Check, X, Building, Award, Key } from 'lucide-react';

interface UserSwitcherModalProps {
  currentUser: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onSelectUser: (user: UserProfile) => void;
}

export const UserSwitcherModal: React.FC<UserSwitcherModalProps> = ({
  currentUser,
  isOpen,
  onClose,
  onSelectUser,
}) => {
  if (!isOpen) return null;

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">Administrador Geral</span>;
      case 'cco_dispatcher':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">Despachante CCO</span>;
      case 'yard_operator':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/30">Operador de Pátio</span>;
      case 'maintenance_tech':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">Engenharia Manutenção</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-6 text-slate-100 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Controle de Acesso & Perfis Concorrentes (RBAC)</h2>
              <p className="text-xs text-slate-400">Simule o acesso simultâneo de múltiplos operadores com credenciais e auditoria</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-3 max-h-[60vh] overflow-y-auto pr-1">
          {INITIAL_USERS.map((user) => {
            const isSelected = user.id === currentUser.id;
            return (
              <div
                key={user.id}
                onClick={() => {
                  onSelectUser(user);
                  onClose();
                }}
                className={`flex items-start justify-between p-3.5 rounded-lg border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500/50 shadow-md shadow-amber-500/5'
                    : 'bg-slate-800/60 border-slate-750 hover:bg-slate-800 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                      alt={user?.name || 'Operador'}
                      className="w-12 h-12 rounded-full object-cover border-2 border-slate-700"
                    />
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-900" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold text-sm text-white">{user.name}</h4>
                      {getRoleBadge(user.role)}
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-slate-500" />
                        {user.badgeNumber}
                      </span>
                      <span className="flex items-center gap-1">
                        <Building className="w-3.5 h-3.5 text-slate-500" />
                        {user.department}
                      </span>
                    </div>
                    <div className="mt-1 text-[11px] text-slate-300">
                      {user.role === 'admin' && 'Permissões: Total, auditoria irrestrita, configuração e API.'}
                      {user.role === 'cco_dispatcher' && 'Permissões: Autorização de despacho, tráfego e alertas CCO.'}
                      {user.role === 'yard_operator' && 'Permissões: Registro de campo, conferência de calços e manobras.'}
                      {user.role === 'maintenance_tech' && 'Permissões: Gestão preventiva SAP PM, inspeções e oficinas.'}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end">
                  {isSelected ? (
                    <span className="flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold text-xs">
                      <Check className="w-3.5 h-3.5" />
                      Ativo
                    </span>
                  ) : (
                    <button
                      className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-xs text-slate-200 transition"
                    >
                      Alternar
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <Key className="w-4 h-4 text-amber-400" />
            <span>Sessão segura com auditoria ativada para todas as movimentações</span>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
