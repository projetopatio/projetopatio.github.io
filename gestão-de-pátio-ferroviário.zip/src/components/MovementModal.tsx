import React, { useState, useEffect, useMemo } from 'react';
import { YardTrack, TrainVehicle, MovementType, MovementReason, UserProfile, VehicleType, ActiveManobradorState } from '../types';
import { isMaintenanceReason } from '../utils/trainStatus';
import { 
  Train, 
  X, 
  ArrowRight, 
  CheckSquare, 
  AlertTriangle, 
  ShieldCheck, 
  UserCheck, 
  FileText, 
  Plus, 
  CornerDownRight,
  Info,
  Lock,
  Unlock,
  KeyRound,
  LogOut,
  Wrench,
  CheckCircle2
} from 'lucide-react';

interface MovementModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracks: YardTrack[];
  vehicles: TrainVehicle[];
  currentUser: UserProfile;
  activeManobrador?: ActiveManobradorState | null;
  onActivateManobrador?: () => void;
  preselectedTrackId?: string | null;
  preselectedSpotId?: string | null;
  initialMovementType?: MovementType;
  initialVehicleId?: string | null;
  forceEntryOnly?: boolean;
  onSubmitMovement: (data: any) => Promise<void>;
}

export const MovementModal: React.FC<MovementModalProps> = ({
  isOpen,
  onClose,
  tracks,
  vehicles,
  currentUser,
  activeManobrador,
  onActivateManobrador,
  preselectedTrackId,
  preselectedSpotId,
  initialMovementType,
  initialVehicleId,
  forceEntryOnly,
  onSubmitMovement,
}) => {
  const [movementType, setMovementType] = useState<MovementType>(initialMovementType || 'entry');
  const [isNewVehicle, setIsNewVehicle] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('');
  const [targetSpotId, setTargetSpotId] = useState<string>(preselectedSpotId || '');
  
  // New vehicle form fields if entering new
  const [newId, setNewId] = useState('');
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<VehicleType>('train_passenger');
  const [newCompany, setNewCompany] = useState('VLT Carioca');
  const [newModel, setNewModel] = useState('VLT 7 Módulos Articulados');
  const [newLength, setNewLength] = useState(170);
  const [newPassengerService, setNewPassengerService] = useState('Linha 11 - Coral (Comercial)');
  const [newPassengerCapacity, setNewPassengerCapacity] = useState(2040);
  const [newCarCount, setNewCarCount] = useState(8);

  const [sourceTrackId, setSourceTrackId] = useState<string>('');
  const [targetTrackId, setTargetTrackId] = useState<string>('');
  const [reason, setReason] = useState<MovementReason>('Estacionamento / Aguardando Escala');
  const [authorizedByCCO, setAuthorizedByCCO] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Safety checklist
  const [handbrakeApplied, setHandbrakeApplied] = useState(true);
  const [trackChocksInstalled, setTrackChocksInstalled] = useState(true);
  const [pantographLowered, setPantographLowered] = useState(true);
  const [signalingFlagsPlaced, setSignalingFlagsPlaced] = useState(true);
  const [visualInspectionDone, setVisualInspectionDone] = useState(true);

  // Vias selecionáveis: remove "Linha de Entrada" (LE / VIA-LE) tanto da origem quanto do destino
  const selectableTracks = useMemo(() => {
    return tracks.filter(
      (t) => t.id !== 'VIA-LE' && t.code !== 'LE' && !t.name.toUpperCase().includes('LINHA DE ENTRADA')
    );
  }, [tracks]);

  useEffect(() => {
    if (preselectedSpotId) {
      setTargetSpotId(preselectedSpotId);
    }
  }, [preselectedSpotId, isOpen]);

  useEffect(() => {
    if (preselectedTrackId && preselectedTrackId !== 'VIA-LE') {
      setTargetTrackId(preselectedTrackId);
    } else if (selectableTracks.length > 0 && (!targetTrackId || targetTrackId === 'VIA-LE')) {
      const firstFree = selectableTracks.find(t => {
        if (!t || t.status === 'interdicted') return false;
        if (t.spots && t.spots.length > 0) return t.spots.some(s => s?.status === 'free');
        return (t.assignedVehicles?.length || 0) < (t.capacityWagons || 1);
      });
      setTargetTrackId(firstFree ? firstFree.id : selectableTracks[0].id);
    }
  }, [preselectedTrackId, selectableTracks, targetTrackId]);

  useEffect(() => {
    if (selectableTracks.length > 0 && (!sourceTrackId || !selectableTracks.some(t => t.id === sourceTrackId))) {
      setSourceTrackId(selectableTracks[0].id);
    }
  }, [selectableTracks, sourceTrackId]);

  useEffect(() => {
    if (initialVehicleId) {
      setSelectedVehicleId(initialVehicleId);
      setIsNewVehicle(false);
      const v = vehicles.find(item => item.id === initialVehicleId);
      if (v && v.currentTrackId) {
        setSourceTrackId(v.currentTrackId);
      }
    } else if (vehicles.length > 0 && !selectedVehicleId && !isNewVehicle) {
      setSelectedVehicleId(vehicles[0].id);
    }
  }, [vehicles, selectedVehicleId, isNewVehicle, initialVehicleId, isOpen]);

  // When selected vehicle changes, adjust source track
  useEffect(() => {
    if (selectedVehicleId && !isNewVehicle) {
      const v = vehicles.find(item => item.id === selectedVehicleId);
      if (v && v.currentTrackId && selectableTracks.some(t => t.id === v.currentTrackId)) {
        setSourceTrackId(v.currentTrackId);
        if (movementType === 'entry' && initialMovementType !== 'exit') {
          setMovementType('shunting');
        }
      } else if (selectableTracks.length > 0) {
        setSourceTrackId(selectableTracks[0].id);
      }
    } else if (isNewVehicle && selectableTracks.length > 0 && (!sourceTrackId || !selectableTracks.some(t => t.id === sourceTrackId))) {
      setSourceTrackId(selectableTracks[0].id);
    }
  }, [selectedVehicleId, vehicles, isNewVehicle, selectableTracks, initialMovementType]);

  useEffect(() => {
    if (initialMovementType) {
      setMovementType(initialMovementType);
      if (initialMovementType === 'exit') {
        setReason('Despacho Comercial / Saída do Pátio');
      }
    }
  }, [initialMovementType, isOpen]);

  const targetTrack = tracks.find(t => t.id === targetTrackId);
  const isTargetInterdicted = targetTrack?.status === 'interdicted';
  const isTargetHigh = targetTrack?.status === 'high' || targetTrack?.status === 'critical';

  // REGRA DE IMPEDIMENTO: Verifica se a via de destino está ocupada (sem vagas livres)
  const isMovingWithinSameTrack = !!selectedVehicleId && targetTrack?.assignedVehicles?.includes(selectedVehicleId);
  const targetHasFreeSpot = targetTrack ? (
    isMovingWithinSameTrack
      ? true
      : targetTrack.spots && targetTrack.spots.length > 0
        ? targetTrack.spots.some(s => s?.status === 'free')
        : ((targetTrack.assignedVehicles?.length || 0) < (targetTrack.capacityWagons || 1) && targetTrack.status !== 'critical')
  ) : true;
  const isTargetOccupied = targetTrack ? !targetHasFreeSpot : false;

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (movementType !== 'exit' && !targetTrackId) {
      setErrorMessage('Selecione uma via de destino para o veículo.');
      return;
    }

    if (targetTrack && isTargetInterdicted && movementType !== 'exit') {
      setErrorMessage('A via selecionada está interditada para obras e não pode receber trens.');
      return;
    }

    // BLOQUEIO DE INTERTRAVAMENTO: Impede manobra se a via de destino estiver ocupada
    if (movementType !== 'exit' && isTargetOccupied) {
      setErrorMessage(
        `BLOQUEIO DE INTERTRAVAMENTO: Manobra impedida! A via de destino ${targetTrack?.code} (${targetTrack?.name}) encontra-se ocupada sem vagas disponíveis.`
      );
      return;
    }

    try {
      setIsSubmitting(true);

      let effectiveVehicleId = selectedVehicleId;
      if (isNewVehicle) {
        effectiveVehicleId = newId.trim().toUpperCase();
        if (!effectiveVehicleId) {
          setErrorMessage('Informe a identificação / prefixo do novo veículo.');
          setIsSubmitting(false);
          return;
        }
      }

      const trimmedODT = authorizedByCCO.trim();
      if (!trimmedODT) {
        setErrorMessage('Por favor, digite o nome do Operador de Trem (ODT) para registrar a manobra.');
        setIsSubmitting(false);
        return;
      }

      await onSubmitMovement({
        vehicleId: effectiveVehicleId,
        type: movementType,
        reason,
        sourceTrackId: movementType === 'entry' ? null : (sourceTrackId || null),
        sourceTrackName: movementType === 'entry' ? 'Via Comercial' : selectableTracks.find(t => t.id === sourceTrackId)?.name,
        targetTrackId: movementType === 'exit' ? null : targetTrackId,
        targetSpotId: movementType === 'exit' ? null : (targetSpotId || null),
        operatorId: currentUser.id,
        operatorName: currentUser.name,
        operatorRole: currentUser.roleLabel,
        authorizedByCCO: trimmedODT,
        safetyChecklist: {
          handbrakeApplied: true,
          trackChocksInstalled: true,
          pantographLowered: true,
          signalingFlagsPlaced: true,
          visualInspectionDone: true,
        },
        notes: notes.trim(),
        // Pass new vehicle info if applicable
        newVehicleData: isNewVehicle ? {
          id: effectiveVehicleId,
          name: newName || `TUE ${effectiveVehicleId}`,
          type: newType,
          operatorCompany: newCompany,
          model: newModel,
          lengthMeters: Number(newLength) || 170,
          passengerService: newPassengerService,
          passengerCapacity: Number(newPassengerCapacity) || 2000,
          carCount: Number(newCarCount) || 8,
          cargoType: `Transporte de Passageiros (${newCarCount || 8} Carros Climatizados)`,
        } : undefined,
      });

      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro ao registrar movimentação.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-xl bg-slate-900 border border-slate-700 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400">
              <Train className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Registrar Movimentação no Pátio</h2>
              <p className="text-xs text-slate-400">Geração de histórico oficial, notificação automática CCO e auditoria</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body with Scroll */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          
          {errorMessage && (
            <div className="p-3 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* MANOBRADOR EXCLUSIVITY STATUS BANNER */}
          {activeManobrador ? (
            activeManobrador.userId === currentUser.id ? (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Unlock className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <span className="font-bold">Manobrador Ativo: Você ({currentUser.name} • {currentUser.badgeNumber})</span>
                    <p className="text-[11px] text-emerald-400/80">Comando exclusivo do pátio ativado. Demais operadores bloqueados para manobra.</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold border border-emerald-500/30">
                  AUTORIZADO
                </span>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/50 text-rose-200 space-y-1.5 shadow-md shadow-rose-950/40">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="font-bold text-rose-300">
                    TRAVA OPERACIONAL DE MANOBRADOR ATIVA
                  </span>
                </div>
                <p className="text-[11px] text-slate-300">
                  O pátio está sob o comando exclusivo do operador <strong>{activeManobrador.userName}</strong> (Matrícula: <strong className="text-amber-400">{activeManobrador.badgeNumber}</strong>).
                </p>
                <p className="text-[11px] text-rose-300 font-semibold">
                  Nenhum outro usuário consegue realizar manobras enquanto esta função estiver ocupada. Aguarde a liberação ou consulte o Supervisor de CCO.
                </p>
              </div>
            )
          ) : (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="font-bold">Função Manobrador Desocupada</span>
                  <p className="text-[11px] text-slate-400">Para garantir a segurança, assuma o comando exclusivo antes de confirmar a manobra.</p>
                </div>
              </div>
              {onActivateManobrador && (
                <button
                  type="button"
                  onClick={onActivateManobrador}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition shrink-0 flex items-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Assumir Manobrador</span>
                </button>
              )}
            </div>
          )}

          {/* 1. Movement Type Selection */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block font-semibold text-slate-200">
                1. Tipo de Movimentação Ferroviária
              </label>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setMovementType('entry')}
                className={`p-2.5 rounded-lg border text-center font-medium transition cursor-pointer ${
                  movementType === 'entry'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                Entrada no Pátio
              </button>
              <button
                type="button"
                onClick={() => setMovementType('shunting')}
                className={`p-2.5 rounded-lg border text-center font-medium transition cursor-pointer ${
                  movementType === 'shunting'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                Manobra Entre Vias
              </button>
              <button
                type="button"
                onClick={() => setMovementType('maintenance_in')}
                className={`p-2.5 rounded-lg border text-center font-medium transition cursor-pointer ${
                  movementType === 'maintenance_in'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                Oficina / Preventiva
              </button>
              <button
                type="button"
                onClick={() => setMovementType('exit')}
                className={`p-2.5 rounded-lg border text-center font-medium transition cursor-pointer ${
                  movementType === 'exit'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                Despacho / Saída
              </button>
            </div>
          </div>

          {/* 2. Vehicle Selection */}
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-slate-200">
                2. Veículo / Composição Ferroviária
              </label>
              <button
                type="button"
                onClick={() => setIsNewVehicle(!isNewVehicle)}
                className="text-[11px] text-amber-400 hover:text-amber-300 underline font-medium cursor-pointer"
              >
                {isNewVehicle ? 'Selecionar veículo existente no pátio' : '+ Cadastrar novo trem/vagão'}
              </button>
            </div>

            {!isNewVehicle ? (
              <div>
                <select
                  value={selectedVehicleId}
                  onChange={(e) => setSelectedVehicleId(e.target.value)}
                  className="w-full p-2.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-500 text-xs font-medium cursor-pointer"
                >
                  {vehicles.map((v) => {
                    const currentTrack = tracks.find((t) => t.id === v.currentTrackId);
                    const currentSpot = currentTrack?.spots?.find((s) => s.id === v.currentSpotId || s.vehicleId === v.id);
                    const spotSuffix = currentSpot?.positionLetter ? ` (Posição ${currentSpot.positionLetter})` : '';
                    const trackLabel = currentTrack
                      ? `${currentTrack.name}${spotSuffix}`
                      : (v.currentTrackId ? v.currentTrackId.replace('VIA-', 'Via ') : 'Fora do pátio');

                    return (
                      <option key={v.id} value={v.id}>
                        {v.id} &bull; Linha atual: {trackLabel}
                      </option>
                    );
                  })}
                </select>
              </div>
            ) : (
              <div className="space-y-2.5 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-slate-400 mb-1">Prefixo / ID (ex: VLT-118)</label>
                    <input
                      type="text"
                      value={newId}
                      onChange={(e) => setNewId(e.target.value)}
                      placeholder="VLT-118"
                      className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white uppercase focus:border-amber-500 focus:outline-none font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Tipo de Composição</label>
                    <select
                      value={newType}
                      onChange={(e) => setNewType(e.target.value as VehicleType)}
                      className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none text-xs"
                    >
                      <option value="train_passenger">Trem Unidade Elétrica (TUE) - Passageiros</option>
                      <option value="maintenance_car">Veículo Auxiliar de Manutenção de Via</option>
                      <option value="locomotive_electric">Locomotiva Manobreira Elétrica</option>
                      <option value="locomotive_diesel">Locomotiva Manobreira Diesel</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Operadora / CCO</label>
                    <input
                      type="text"
                      value={newCompany}
                      onChange={(e) => setNewCompany(e.target.value)}
                      placeholder="VLT Carioca"
                      className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-slate-400 mb-1">Linha Comercial de Atendimento</label>
                    <input
                      type="text"
                      value={newPassengerService}
                      onChange={(e) => setNewPassengerService(e.target.value)}
                      placeholder="Linha 11 - Coral (Comercial)"
                      className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Capacidade de Passageiros</label>
                    <input
                      type="number"
                      value={newPassengerCapacity}
                      onChange={(e) => setNewPassengerCapacity(Number(e.target.value))}
                      placeholder="2040"
                      className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Quantidade de Carros</label>
                    <select
                      value={newCarCount}
                      onChange={(e) => setNewCarCount(Number(e.target.value))}
                      className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:border-amber-500 focus:outline-none text-xs"
                    >
                      <option value={8}>8 Carros (Padrão Metropolitano)</option>
                      <option value={4}>4 Carros (Extensão Operacional)</option>
                      <option value={6}>6 Carros</option>
                    </select>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 3. Movement Reason (Mandatory user requirement) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block font-semibold text-slate-200">
                3. Motivo da Entrada / Movimentação no Pátio
              </label>
              {isMaintenanceReason(reason) && (
                <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-rose-500/20 text-rose-300 border border-rose-500/40">
                  Status: Em Manutenção
                </span>
              )}
            </div>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value as MovementReason)}
              className={`w-full p-2.5 rounded-lg bg-slate-800 border ${
                isMaintenanceReason(reason) ? 'border-amber-500/80 ring-1 ring-amber-500/40' : 'border-slate-700'
              } text-slate-100 focus:outline-none focus:border-amber-500 text-xs font-semibold cursor-pointer`}
            >
              <optgroup label="Motivos de Manutenção (Alteram status para 'Em Manutenção')">
                <option value="Higienização">Higienização</option>
                <option value="Revisão de Ar">Revisão de ar</option>
                <option value="Manutenção Preventiva">Manutenção preventiva</option>
                <option value="Manutenção Corretiva">Manutenção corretiva</option>
                <option value="Inspeção de Truque">Inspeção de truque</option>
              </optgroup>
              <optgroup label="Outros Motivos Operacionais">
                <option value="Estacionamento / Aguardando Escala">Estacionamento / Aguardando Escala</option>
                <option value="Inserção em Carrossel Comercial (Pico)">Inserção em Carrossel Comercial (Pico)</option>
                <option value="Recolhimento Após Horário de Pico">Recolhimento Após Horário de Pico</option>
                <option value="Despacho para Linha Tronco">Despacho para Linha Comercial</option>
              </optgroup>
            </select>

            {isMaintenanceReason(reason) && (
              <div className="mt-2 p-2 rounded-lg bg-rose-950/40 border border-rose-500/40 flex items-center gap-2 text-rose-200 text-xs animate-in fade-in">
                <Wrench className="w-4 h-4 text-rose-400 shrink-0" />
                <span>
                  <strong>Regra Operacional Ativa:</strong> Manobras motivadas por <em>"{reason}"</em> alteram automaticamente o status da composição para <span className="font-bold text-rose-300 uppercase">"Em Manutenção"</span>.
                </span>
              </div>
            )}
          </div>

          {/* 4. Origin and Destination Tracks */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Via de Origem
              </label>
              {movementType === 'entry' ? (
                <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 font-medium flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="font-bold text-white">Via Comercial</span>
                    <span className="text-[11px] text-slate-400 font-normal">(Operação Comercial Externa)</span>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 font-bold uppercase font-mono">
                    Origem Comercial
                  </span>
                </div>
              ) : (
                <select
                  value={sourceTrackId}
                  onChange={(e) => setSourceTrackId(e.target.value)}
                  className="w-full p-2.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  {selectableTracks.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.code} - {t.name} ({t.assignedVehicles.length} composições)
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Via de Destino
              </label>
              {movementType === 'exit' ? (
                <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/40 text-xs">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Via Comercial (Operação Comercial Externa)</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Despacho da composição para a malha comercial externa fora do pátio.
                  </p>
                </div>
              ) : (
                <select
                  value={targetTrackId}
                  onChange={(e) => setTargetTrackId(e.target.value)}
                  className={`w-full p-2.5 rounded-lg bg-slate-800 border focus:outline-none cursor-pointer ${
                    isTargetInterdicted || (isTargetOccupied && movementType !== 'exit')
                      ? 'border-rose-500 text-rose-300'
                      : isTargetHigh
                      ? 'border-amber-500 text-amber-300'
                      : 'border-slate-700 text-slate-200 focus:border-amber-500'
                  }`}
                >
                  {selectableTracks.map((t) => {
                    const maxCap = t.capacityWagons || 1;
                    const isFull = t.spots && t.spots.length > 0
                      ? t.spots.every(s => s.status !== 'free')
                      : (t.assignedVehicles.length >= maxCap || t.status === 'critical');
                    const freeSpots = t.spots ? t.spots.filter(s => s.status === 'free').length : Math.max(0, maxCap - t.assignedVehicles.length);

                    return (
                      <option key={t.id} value={t.id} disabled={t.status === 'interdicted'}>
                        {t.code} - {t.name} {t.status === 'interdicted' ? '(⛔ INTERDITADA)' : isFull ? '⛔ [OCUPADA - IMPEDIDA]' : `[${freeSpots} vaga(s) livre(s)]`}
                      </option>
                    );
                  })}
                </select>
              )}

              {/* Optional Spot selection on target track */}
              {targetTrack && targetTrack.spots && targetTrack.spots.length > 0 && movementType !== 'exit' && (
                <div className="mt-2.5">
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Posição / Vaga na Via {targetTrack.code} (Opcional):
                  </label>
                  <select
                    value={targetSpotId}
                    onChange={(e) => setTargetSpotId(e.target.value)}
                    className="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-200 focus:border-amber-500 cursor-pointer"
                  >
                    <option value="">Automático (prioridade fim de via / vagas livres)</option>
                    {targetTrack.spots.map((s) => (
                      <option key={s.id} value={s.id} disabled={s.status !== 'free'}>
                        {s.positionName || `Vaga ${s.spotNumber}`} - {s.status === 'free' ? '✅ Livre' : `⛔ Ocupada (${s.vehicleId || 'trem'})`}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* Interdiction or High Occupancy Warnings */}
          {targetTrack && isTargetInterdicted && (
            <div className="p-3 rounded-lg bg-rose-500/20 border border-rose-500 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>Atenção: A {targetTrack.name} está interditada para obras de via. Selecione outra via de destino.</span>
            </div>
          )}

          {/* REGRA DE IMPEDIMENTO: ALERTA DESTACADO DE VIA OCUPADA */}
          {targetTrack && isTargetOccupied && movementType !== 'exit' && (
            <div className="p-3.5 rounded-lg bg-rose-950/60 border-2 border-rose-500 text-rose-200 text-xs flex items-start gap-2.5 shadow-lg">
              <AlertTriangle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
              <div>
                <div className="font-bold text-rose-300 text-sm">⛔ MANOBRA IMPEDIDA: VIA DE DESTINO OCUPADA</div>
                <p className="mt-1 text-rose-200 leading-relaxed">
                  A via de destino <strong>{targetTrack.code} ({targetTrack.name})</strong> não possui nenhuma vaga disponível.
                  O regulamento operacional e o intertravamento de segurança <strong>proíbem qualquer manobra direcionada a vias ocupadas</strong>.
                </p>
              </div>
            </div>
          )}

          {targetTrack && !isTargetOccupied && isTargetHigh && (
            <div className="p-2.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
              <Info className="w-4 h-4 shrink-0 text-amber-400" />
              <span>Aviso CCO: A {targetTrack.code} já opera próxima do limite ({targetTrack.assignedVehicles.length}/{targetTrack.capacityWagons} vagões). Uma notificação será despachada.</span>
            </div>
          )}

          {/* 5. Operator & ODT Information (Auditing context) */}
          <div className="p-3 rounded-lg bg-slate-800/60 border border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between font-semibold text-slate-300">
              <div className="flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-emerald-400" />
                <span>Quem fez a manobra</span>
              </div>
              <span className="text-[11px] text-slate-400">Gravado em auditoria em tempo real</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-slate-400">Operador / Manobrador:</span>
                <div className="font-semibold text-white mt-0.5">
                  {currentUser.name} <span className="text-amber-400">({currentUser.badgeNumber})</span>
                </div>
                <div className="text-[11px] text-slate-400">{currentUser.roleLabel}</div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-0.5">
                  Operador de Trem (ODT) <span className="text-amber-400">*</span>:
                </label>
                <input
                  type="text"
                  required
                  value={authorizedByCCO}
                  onChange={(e) => {
                    setAuthorizedByCCO(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="Digite o nome do ODT responsável..."
                  className="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-xs font-medium"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Informe o nome do ODT (obrigatório)
                </span>
              </div>
            </div>
          </div>

          {/* 6. Observações e Avarias */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Observações Técnicas / Registro de Ocorrência
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Manobra realizada sem intercorrências. Truque dianteiro inspecionado com conformidade."
              className="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 text-xs"
            />
          </div>

          {/* Submit and Cancel Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition cursor-pointer"
            >
              Cancelar
            </button>
            {(() => {
              const isBlockedByManobrador = !!activeManobrador && activeManobrador.userId !== currentUser.id;
              const isBlockedBySpot = isTargetOccupied && movementType !== 'exit';
              const isBlocked = isSubmitting || isBlockedByManobrador || isBlockedBySpot || (isTargetInterdicted && movementType !== 'exit');

              return (
                <button
                  type="submit"
                  disabled={isBlocked}
                  className={`px-5 py-2 rounded-lg font-bold shadow-md transition flex items-center gap-2 ${
                    isBlockedByManobrador
                      ? 'bg-rose-950/70 border border-rose-600/70 text-rose-300 opacity-70 cursor-not-allowed shadow-none'
                      : isBlockedBySpot
                      ? 'bg-rose-900/60 border border-rose-500/80 text-rose-300 opacity-60 cursor-not-allowed shadow-none'
                      : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 shadow-amber-500/20 cursor-pointer'
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>Registrando...</span>
                    </>
                  ) : isBlockedByManobrador ? (
                    <>
                      <Lock className="w-4 h-4 text-rose-400" />
                      <span>⛔ Trancado por Outro Manobrador</span>
                    </>
                  ) : isBlockedBySpot ? (
                    <>
                      <AlertTriangle className="w-4 h-4 text-rose-400" />
                      <span>⛔ Manobra Impedida (Via Ocupada)</span>
                    </>
                  ) : (
                    <>
                      {movementType === 'exit' ? (
                        <LogOut className="w-4 h-4" />
                      ) : (
                        <ShieldCheck className="w-4 h-4" />
                      )}
                      <span>
                        {movementType === 'exit' ? 'Confirmar Saída do Pátio' : 'Confirmar e Notificar CCO'}
                      </span>
                    </>
                  )}
                </button>
              );
            })()}
          </div>

        </form>

      </div>
    </div>
  );
};
