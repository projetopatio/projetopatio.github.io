import React, { useState } from 'react';
import { UserProfile, ActiveManobradorState } from '../types';
import { isSupervisor } from '../utils/rbac';
import { 
  KeyRound, 
  Lock, 
  Unlock, 
  X, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  User, 
  Clock 
} from 'lucide-react';

interface ManobradorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  activeManobrador: ActiveManobradorState | null;
  onActivate: () => Promise<void>;
  onRelease: () => Promise<void>;
}

export const ManobradorModal: React.FC<ManobradorModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  activeManobrador,
  onActivate,
  onRelease,
}) => {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const isCurrentUserManobrador = !!activeManobrador && activeManobrador.userId === currentUser?.id;
  const isSomeoneElse = !!activeManobrador && activeManobrador.userId !== currentUser?.id;
  const userIsSupervisor = isSupervisor(currentUser?.role || '');

  const handleConfirmActivate = async () => {
    setSubmitting(true);
    setError(null);
    try {
      await onActivate();
      onClose();
    } catch (e: any) {
      setError(e.message || 'Falha ao ativar função de Manobrador');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmRelease = async () => {
    setSubmitting(true);
    setError(null);
    try {
      await onRelease();
      onClose();
    } catch (e: any) {
      setError(e.message || 'Falha ao liberar função de Manobrador');
    } finally {
      setSubmitting(false);
    }
  };

  const formatTime = (iso?: string) => {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl ${
              isSomeoneElse 
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' 
                : isCurrentUserManobrador
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
            }`}>
              {isSomeoneElse ? <Lock className="w-5 h-5" /> : isCurrentUserManobrador ? <Unlock className="w-5 h-5" /> : <KeyRound className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                Controle Operacional: Função MANOBRADOR
              </h3>
              <p className="text-[11px] text-slate-400">
                Regra de Exclusividade de Manobras no Pátio Ferroviário
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 text-xs text-slate-300">
          
          {error && (
            <div className="p-3 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* Scenario 1: Someone else has the lock */}
          {isSomeoneElse && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/40 space-y-2 text-slate-200">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-rose-300 text-sm flex items-center gap-1.5">
                    <Lock className="w-4 h-4 text-rose-400" />
                    Pátio Trancado para Outros Usuários
                  </span>
                  <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-mono text-[10px] font-bold border border-rose-500/30">
                    BLOQUEADO
                  </span>
                </div>
                <div className="text-xs text-slate-300 space-y-1 pt-1 border-t border-rose-500/20">
                  <p>
                    Manobrador Ativo: <strong className="text-white">{activeManobrador?.userName}</strong>
                  </p>
                  <p>
                    Matrícula: <strong className="font-mono text-amber-400">{activeManobrador?.badgeNumber}</strong> • Cargo: <span>{activeManobrador?.role}</span>
                  </p>
                  <p className="flex items-center gap-1 text-[11px] text-slate-400">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    Ativo desde: {formatTime(activeManobrador?.activatedAt)}
                  </p>
                </div>
              </div>

              <p className="text-slate-300 leading-relaxed">
                Por norma de segurança operacional ferroviária, <strong>nenhum outro usuário consegue realizar manobras</strong> enquanto houver um Manobrador com a função ativa no pátio.
              </p>

              {userIsSupervisor ? (
                <div className="p-3 rounded-lg bg-purple-500/15 border border-purple-500/30 text-purple-200 space-y-1.5">
                  <p className="font-semibold text-purple-300 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-purple-400" />
                    Privilégio de Supervisor de CCO Detectado
                  </p>
                  <p className="text-[11px]">
                    Como Supervisor do CCO, você tem autorização para realizar o <strong>override administrativo</strong> e assumir a função para si ou liberar o pátio.
                  </p>
                </div>
              ) : (
                <p className="text-amber-400/90 text-[11px] italic">
                  Para realizar manobras, aguarde a liberação da função pelo operador responsável ou contate a Supervisão do CCO.
                </p>
              )}
            </div>
          )}

          {/* Scenario 2: Current user is the active Manobrador */}
          {isCurrentUserManobrador && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 space-y-2 text-slate-200">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-300 text-sm flex items-center gap-1.5">
                    <Unlock className="w-4 h-4 text-emerald-400" />
                    Você é o Manobrador Ativo
                  </span>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold border border-emerald-500/30">
                    EXCLUSIVIDADE ATIVA
                  </span>
                </div>
                <div className="text-xs text-slate-300 space-y-1 pt-1 border-t border-emerald-500/20">
                  <p>
                    Operador: <strong className="text-white">{currentUser.name}</strong> ({currentUser.badgeNumber})
                  </p>
                  <p className="text-[11px] text-emerald-400/90">
                    O pátio está sob seu comando exclusivo. Todos os demais operadores estão impedidos de efetuar manobras até que você libere a função.
                  </p>
                </div>
              </div>

              <p className="text-slate-300 leading-relaxed">
                Ao concluir suas movimentações, clique em <strong>"Liberar Função de Manobrador"</strong> para disponibilizar o pátio para os demais operadores da escala.
              </p>
            </div>
          )}

          {/* Scenario 3: No one is active */}
          {!activeManobrador && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-2 text-slate-200">
                <span className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-amber-400" />
                  Função de Manobrador Disponível
                </span>
                <p className="text-xs text-slate-300">
                  Nenhum operador está atualmente registrado com o comando exclusivo do pátio.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-800/80 border border-slate-700/80 space-y-1.5">
                <p className="font-semibold text-white">Regra Operacional CCO:</p>
                <ul className="space-y-1 text-[11px] text-slate-300 list-disc list-inside">
                  <li>Ao assumir como <strong>Manobrador</strong>, o sistema tranca as manobras para todos os outros usuários.</li>
                  <li>Sua matrícula (<strong className="text-amber-400">{currentUser.badgeNumber}</strong>) ficará visível em tempo real no sinóptico.</li>
                  <li>Todos os registros de manobra conterão sua assinatura operacional oficial.</li>
                </ul>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 border-t border-slate-800 bg-slate-950/40 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition cursor-pointer"
          >
            Fechar
          </button>

          {isCurrentUserManobrador && (
            <button
              type="button"
              disabled={submitting}
              onClick={handleConfirmRelease}
              className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
            >
              {submitting ? (
                <span>Liberando...</span>
              ) : (
                <>
                  <Unlock className="w-4 h-4" />
                  <span>Liberar Função de Manobrador</span>
                </>
              )}
            </button>
          )}

          {isSomeoneElse && userIsSupervisor && (
            <>
              <button
                type="button"
                disabled={submitting}
                onClick={handleConfirmRelease}
                className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/40 font-bold text-xs transition cursor-pointer"
              >
                Liberar Pátio (Forçar)
              </button>
              <button
                type="button"
                disabled={submitting}
                onClick={handleConfirmActivate}
                className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>Assumir Função (Override)</span>
              </button>
            </>
          )}

          {!activeManobrador && (
            <button
              type="button"
              disabled={submitting}
              onClick={handleConfirmActivate}
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition flex items-center gap-1.5 cursor-pointer"
            >
              {submitting ? (
                <span>Ativando...</span>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>Assumir Função de MANOBRADOR</span>
                </>
              )}
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
