import React, { useEffect, useState } from 'react';
import { CheckCircle2, Wrench, X, Train, ExternalLink, ShieldCheck, AlertCircle } from 'lucide-react';
import { UserProfile } from '../types';

export interface StatusPopupItem {
  id: string;
  vehicleId: string;
  vehicleName: string;
  compositionNumber?: string | number;
  newStatus: 'operacional' | 'em_manutencao';
  statusLabel: string;
  targetRole: 'controlador_cco' | 'tecnico_mro';
  timestamp: string;
  createdAt: number;
  trackName?: string;
  durationMs?: number;
}

export const isUserEligibleForPopup = (user: UserProfile, popup: StatusPopupItem): boolean => {
  if (popup.targetRole === 'controlador_cco') {
    return user.role === 'controlador_cco' || user.role === 'cco_dispatcher';
  }
  if (popup.targetRole === 'tecnico_mro') {
    return user.role === 'tecnico_mro' || user.role === 'maintenance_tech';
  }
  return false;
};

interface StatusNotificationPopupsProps {
  popups: StatusPopupItem[];
  currentUser: UserProfile;
  onDismiss: (id: string) => void;
  onSelectVehicle?: (vehicleId: string) => void;
}

const POPUP_DURATION = 14000; // 14 seconds display time

const SinglePopupCard: React.FC<{
  popup: StatusPopupItem;
  onDismiss: () => void;
  onSelectVehicle?: (vehicleId: string) => void;
}> = ({ popup, onDismiss, onSelectVehicle }) => {
  const [progress, setProgress] = useState(100);
  const isOperacional = popup.newStatus === 'operacional';
  const duration = popup.durationMs || POPUP_DURATION;

  useEffect(() => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remainingPct = Math.max(0, 100 - (elapsed / duration) * 100);
      setProgress(remainingPct);
      if (remainingPct <= 0) {
        clearInterval(interval);
        onDismiss();
      }
    }, 100);

    return () => clearInterval(interval);
  }, [duration, onDismiss]);

  return (
    <div
      className={`pointer-events-auto w-full rounded-xl border-2 p-3.5 shadow-2xl backdrop-blur-md transition-all duration-300 transform translate-x-0 ${
        isOperacional
          ? 'bg-slate-900/95 border-emerald-500/80 shadow-emerald-950/60 text-slate-100'
          : 'bg-slate-900/95 border-amber-500/80 shadow-amber-950/60 text-slate-100'
      }`}
      role="alert"
    >
      {/* Top Header Tag */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider border ${
              isOperacional
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
            }`}
          >
            {isOperacional ? (
              <>
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>EXCLUSIVO CONTROLADOR CCO</span>
              </>
            ) : (
              <>
                <Wrench className="w-3 h-3 text-amber-400" />
                <span>EXCLUSIVO TÉCNICO MRO</span>
              </>
            )}
          </span>

          <span className="text-[11px] font-mono text-slate-400">
            {popup.timestamp}
          </span>
        </div>

        <button
          type="button"
          onClick={onDismiss}
          className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          title="Fechar notificação"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Main Content */}
      <div className="flex items-start gap-3">
        <div
          className={`p-2.5 rounded-lg shrink-0 border ${
            isOperacional
              ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-400'
              : 'bg-amber-950/60 border-amber-500/50 text-amber-400'
          }`}
        >
          {isOperacional ? (
            <Train className="w-6 h-6" />
          ) : (
            <Wrench className="w-6 h-6 animate-pulse" />
          )}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className="text-sm font-black text-white truncate">
              {popup.vehicleName}
            </h4>
            {popup.compositionNumber && (
              <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                Comp. {popup.compositionNumber}
              </span>
            )}
          </div>

          <div className="mt-1">
            <span
              className={`inline-block px-2 py-0.5 rounded text-xs font-black uppercase tracking-wide border ${
                isOperacional
                  ? 'bg-emerald-500/25 text-emerald-300 border-emerald-500/40'
                  : 'bg-amber-500/25 text-amber-300 border-amber-500/40'
              }`}
            >
              STATUS: {popup.statusLabel}
            </span>
          </div>

          <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
            {isOperacional ? (
              <>
                A composição <strong className="text-white">{popup.vehicleName}</strong> teve seu status alterado para <strong className="text-emerald-400">OPERACIONAL</strong> e está liberada para manobras e despacho comercial.
              </>
            ) : (
              <>
                A composição <strong className="text-white">{popup.vehicleName}</strong> teve seu status alterado para <strong className="text-amber-400">EM MANUTENÇÃO</strong>. Requer intervenção da equipe técnica MRO.
              </>
            )}
          </p>

          {popup.trackName && (
            <div className="text-[11px] text-slate-400 mt-1 font-mono">
              Localização: <span className="text-sky-300 font-semibold">{popup.trackName}</span>
            </div>
          )}

          {/* Action Button */}
          {onSelectVehicle && (
            <div className="mt-2.5 flex items-center justify-end">
              <button
                type="button"
                onClick={() => {
                  onSelectVehicle(popup.vehicleId);
                  onDismiss();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-md cursor-pointer ${
                  isOperacional
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-amber-600 hover:bg-amber-500 text-white'
                }`}
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Ver Ficha da Composição</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Auto-Dismiss Progress Bar */}
      <div className="mt-3 w-full bg-slate-800/80 rounded-full h-1 overflow-hidden">
        <div
          className={`h-full transition-all duration-100 ${
            isOperacional ? 'bg-emerald-500' : 'bg-amber-500'
          }`}
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export const StatusNotificationPopups: React.FC<StatusNotificationPopupsProps> = ({
  popups,
  currentUser,
  onDismiss,
  onSelectVehicle,
}) => {
  // Filter popups strictly for the current user's role
  const visiblePopups = popups.filter((p) => isUserEligibleForPopup(currentUser, p));

  if (visiblePopups.length === 0) return null;

  return (
    <div
      id="status-popups-container"
      className="fixed top-4 left-4 z-[9999] flex flex-col gap-2.5 sm:gap-3 max-w-sm sm:max-w-md w-[calc(100vw-2rem)] sm:w-[420px] pointer-events-none animate-fadeIn"
      aria-live="assertive"
    >
      {visiblePopups.map((popup) => (
        <SinglePopupCard
          key={popup.id}
          popup={popup}
          onDismiss={() => onDismiss(popup.id)}
          onSelectVehicle={onSelectVehicle}
        />
      ))}
    </div>
  );
};
