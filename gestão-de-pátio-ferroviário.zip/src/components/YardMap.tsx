import React, { useState, useEffect } from 'react';
import { 
  YardTrack, 
  TrainVehicle, 
  YardSpot, 
  YardSpotStatus, 
  UserProfile,
  MovementType,
  ActiveManobradorState
} from '../types';
import { apiService } from '../services/apiService';
import { YardSynopticMap } from './YardSynopticMap';
import { getTrainTheme } from '../utils/trainStatus';
import { getVehicleIconUri } from '../utils/trainIcon';
import { 
  Train, 
  AlertTriangle, 
  CheckCircle2, 
  Wrench, 
  Clock, 
  Box, 
  CornerDownRight, 
  Layers, 
  X, 
  Check, 
  Fuel, 
  Users, 
  Wheat, 
  ChevronRight,
  Smartphone,
  MapPin,
  Calendar,
  Info,
  LogOut,
  Activity
} from 'lucide-react';

interface YardMapProps {
  tracks: YardTrack[];
  vehicles: TrainVehicle[];
  currentUser?: UserProfile;
  activeManobrador?: ActiveManobradorState | null;
  onToggleManobrador?: () => void;
  onSelectVehicle: (vehicle: TrainVehicle) => void;
  onQuickMove: (vehicleId: string, trackId: string, spotId?: string) => void;
  onNewMovementWithTrack?: (trackId: string, spotId?: string, forcedType?: MovementType, entryOnly?: boolean) => void;
  onSpotUpdated?: () => void;
}

export const YardMap: React.FC<YardMapProps> = ({
  tracks,
  vehicles,
  currentUser,
  activeManobrador,
  onToggleManobrador,
  onSelectVehicle,
  onQuickMove,
  onNewMovementWithTrack,
  onSpotUpdated,
}) => {
  // Selected Spot for Drill-Down Modal
  const [selectedSpot, setSelectedSpot] = useState<{ spot: YardSpot; track: YardTrack } | null>(null);
  const [isEditingSpotStatus, setIsEditingSpotStatus] = useState(false);
  const [editStatus, setEditStatus] = useState<YardSpotStatus>('free');
  const [editRestrictionReason, setEditRestrictionReason] = useState('');
  const [selectedVehicleIdForSpot, setSelectedVehicleIdForSpot] = useState<string>('');
  const [isSavingSpot, setIsSavingSpot] = useState(false);
  const [isTogglingPhone, setIsTogglingPhone] = useState(false);
  const [spotErrorMsg, setSpotErrorMsg] = useState<string | null>(null);
  const [showMaintenancePanel, setShowMaintenancePanel] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedSpot(null);
      }
    };
    if (selectedSpot) {
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [selectedSpot]);

  const handleSynopticTrackSelect = (track: YardTrack, specificSpot?: YardSpot) => {
    if (track.spots && track.spots.length > 0) {
      const preferredSpot = specificSpot
        ? (track.spots.find(s => s.id === specificSpot.id) || specificSpot)
        : (track.spots.find(s => s.status === 'occupied') || track.spots[0]);
      setSelectedSpot({ spot: preferredSpot, track });
      setEditStatus(preferredSpot.status);
      setEditRestrictionReason(preferredSpot.restrictionReason || '');
      setSelectedVehicleIdForSpot(preferredSpot.vehicleId || '');
      setIsEditingSpotStatus(false);
    }
  };

  // Helper to retrieve vehicle in a spot or track
  const getVehicleForSpot = (spot: YardSpot): TrainVehicle | undefined => {
    if (spot.vehicleId) {
      return vehicles.find(v => v.id === spot.vehicleId);
    }
    return vehicles.find(v => v.currentSpotId === spot.id);
  };

  // Helper to get spot status config
  const getSpotStatusConfig = (status?: YardSpotStatus | string | null) => {
    switch (status) {
      case 'free':
        return {
          label: 'Vaga Livre',
          bgColor: 'bg-emerald-950/40 hover:bg-emerald-950/60 border-emerald-500/30 text-emerald-300',
          badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
          indicatorDot: 'bg-emerald-400',
          icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />,
        };
      case 'occupied':
        return {
          label: 'Ocupada',
          bgColor: 'bg-sky-950/50 hover:bg-sky-950/70 border-sky-500/40 text-sky-200',
          badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-500/30',
          indicatorDot: 'bg-sky-400',
          icon: <Train className="w-3.5 h-3.5 text-sky-400" />,
        };
      case 'maintenance':
        return {
          label: 'Em Manutenção',
          bgColor: 'bg-amber-950/40 hover:bg-amber-950/60 border-amber-500/40 text-amber-200',
          badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
          indicatorDot: 'bg-amber-400 animate-pulse',
          icon: <Wrench className="w-3.5 h-3.5 text-amber-400" />,
        };
      case 'restricted':
        return {
          label: 'Com Restrição',
          bgColor: 'bg-rose-950/40 hover:bg-rose-950/60 border-rose-500/50 text-rose-200',
          badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
          indicatorDot: 'bg-rose-500',
          icon: <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />,
        };
      default:
        return {
          label: 'Indefinido',
          bgColor: 'bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-300',
          badgeColor: 'bg-slate-700/50 text-slate-300 border-slate-600',
          indicatorDot: 'bg-slate-400',
          icon: <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />,
        };
    }
  };

  const getCargoIcon = (cargoType?: string) => {
    if (!cargoType) return <Box className="w-3 h-3 text-slate-400" />;
    const lower = cargoType.toLowerCase();
    if (lower.includes('diesel') || lower.includes('combustível') || lower.includes('etanol') || lower.includes('tanque')) {
      return <Fuel className="w-3 h-3 text-violet-400" />;
    }
    if (lower.includes('soja') || lower.includes('milho') || lower.includes('grão')) {
      return <Wheat className="w-3 h-3 text-amber-400" />;
    }
    if (lower.includes('passageiro')) {
      return <Users className="w-3 h-3 text-emerald-400" />;
    }
    return <Box className="w-3 h-3 text-sky-400" />;
  };

  const handleSpotClick = (spot: YardSpot, track: YardTrack) => {
    setSelectedSpot({ spot, track });
    setIsEditingSpotStatus(false);
    setEditStatus(spot.status);
    setEditRestrictionReason(spot.restrictionReason || '');
    setSelectedVehicleIdForSpot(spot.vehicleId || '');
  };

  const handleSaveSpotStatus = async () => {
    if (!selectedSpot) return;
    try {
      setIsSavingSpot(true);
      const chosenVehId = editStatus === 'occupied' && selectedVehicleIdForSpot ? selectedVehicleIdForSpot : undefined;
      await apiService.updateSpotStatus(
        selectedSpot.spot.id,
        editStatus,
        editStatus === 'restricted' ? editRestrictionReason : undefined,
        chosenVehId
      );

      // Update local state
      selectedSpot.spot.status = editStatus;
      if (editStatus === 'free') {
        selectedSpot.spot.vehicleId = null;
      } else if (editStatus === 'occupied' && chosenVehId) {
        selectedSpot.spot.vehicleId = chosenVehId;
      }
      if (editStatus === 'restricted') {
        selectedSpot.spot.restrictionReason = editRestrictionReason;
      }
      setIsEditingSpotStatus(false);
      if (onSpotUpdated) onSpotUpdated();
    } catch (err: any) {
      setSpotErrorMsg(`Falha ao alterar status da vaga: ${err.message}`);
    } finally {
      setIsSavingSpot(false);
    }
  };

  const handleQuickFreeSpot = async (spot: YardSpot, track: YardTrack) => {
    try {
      setIsSavingSpot(true);
      setSpotErrorMsg(null);
      await apiService.updateSpotStatus(spot.id, 'free');
      spot.status = 'free';
      spot.vehicleId = null;
      setSelectedSpot({ spot, track });
      setEditStatus('free');
      setSelectedVehicleIdForSpot('');
      setIsEditingSpotStatus(false);
      if (onSpotUpdated) onSpotUpdated();
    } catch (err: any) {
      setSpotErrorMsg(`Erro ao liberar vaga: ${err.message}`);
    } finally {
      setIsSavingSpot(false);
    }
  };

  const handleQuickOccupySpot = async (spot: YardSpot, track: YardTrack, vehId?: string) => {
    try {
      setIsSavingSpot(true);
      setSpotErrorMsg(null);
      await apiService.updateSpotStatus(spot.id, 'occupied', undefined, vehId);
      spot.status = 'occupied';
      if (vehId) spot.vehicleId = vehId;
      setSelectedSpot({ spot, track });
      setEditStatus('occupied');
      setSelectedVehicleIdForSpot(vehId || '');
      setIsEditingSpotStatus(false);
      if (onSpotUpdated) onSpotUpdated();
    } catch (err: any) {
      setSpotErrorMsg(`Erro ao definir vaga como ocupada: ${err.message}`);
    } finally {
      setIsSavingSpot(false);
    }
  };

  const handleToggleOperationalPhone = async (veh: TrainVehicle, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    try {
      setIsTogglingPhone(true);
      setSpotErrorMsg(null);
      const res = await apiService.toggleVehicleOperationalPhone(veh.id, {
        hasOperationalPhone: !veh.hasOperationalPhone,
        user: currentUser,
      });
      veh.hasOperationalPhone = res.hasOperationalPhone;
      if (selectedVehicle && selectedVehicle.id === veh.id) {
        selectedVehicle.hasOperationalPhone = res.hasOperationalPhone;
      }
      if (onSpotUpdated) onSpotUpdated();
    } catch (err: any) {
      setSpotErrorMsg(`Erro ao alterar celular operacional: ${err.message}`);
    } finally {
      setIsTogglingPhone(false);
    }
  };

  // Synchronized references to track and spot
  const activeModalTrack = selectedSpot
    ? (tracks.find(t => t.id === selectedSpot.track.id) || selectedSpot.track)
    : null;
  const activeModalSpot = selectedSpot && activeModalTrack
    ? (activeModalTrack.spots?.find(s => s.id === selectedSpot.spot.id) || selectedSpot.spot)
    : null;
  const selectedVehicle = activeModalSpot ? getVehicleForSpot(activeModalSpot) : null;

  // Global spot metrics - mathematically precise sum: free + occupied + restricted = total
  let totalSpotsCount = 0;
  let freeSpotsCount = 0;
  let occupiedSpotsCount = 0;
  let restrictedSpotsCount = 0;

  const isSpotOccupied = (s: YardSpot) => {
    return s.status === 'occupied' || s.status === 'maintenance' || Boolean(s.vehicleId || getVehicleForSpot(s));
  };

  tracks.forEach(t => {
    (t.spots || []).forEach(s => {
      totalSpotsCount++;
      if (s.status === 'restricted') {
        restrictedSpotsCount++;
      } else if (isSpotOccupied(s)) {
        occupiedSpotsCount++;
      } else {
        freeSpotsCount++;
      }
    });
  });

  const occupancyRate = totalSpotsCount > 0 ? Math.round((occupiedSpotsCount / totalSpotsCount) * 100) : 0;

  // Real-time Compositions in Maintenance
  const yardMaintenanceVehicles = vehicles.filter(v => {
    const isMaint = v.status === 'in_maintenance' || v.maintenanceStatus === 'in_progress';
    return isMaint && v.currentTrackId !== null;
  });
  const totalFleetMaintenanceVehicles = vehicles.filter(v => 
    v.status === 'in_maintenance' || v.maintenanceStatus === 'in_progress'
  );
  const maintenanceCount = yardMaintenanceVehicles.length;

  return (
    <div className="space-y-4">
      {/* Indicadores Operacionais do Pátio */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* 1. Ocupação do Pátio */}
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Ocupação do Pátio</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white">{occupancyRate}%</span>
            <span className="text-xs text-slate-400 font-mono">({freeSpotsCount} livres de {totalSpotsCount})</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                occupancyRate >= 80 ? 'bg-rose-500' : occupancyRate >= 50 ? 'bg-amber-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(100, occupancyRate)}%` }}
            />
          </div>
        </div>

        {/* 2. Vagas Ocupadas */}
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-sky-500/30 shadow-md">
          <div className="flex items-center justify-between text-sky-400 text-xs font-medium">
            <span>Vagas Ocupadas</span>
            <Train className="w-4 h-4 text-sky-400" />
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-sky-300">{occupiedSpotsCount}</span>
            <span className="text-xs text-slate-400">trens estacionados</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-mono">
            {tracks.length} vias operacionais
          </p>
        </div>

        {/* 3. Composições em Manutenção */}
        <button
          type="button"
          onClick={() => setShowMaintenancePanel(prev => !prev)}
          className={`p-3.5 rounded-xl text-left transition-all cursor-pointer shadow-md border ${
            showMaintenancePanel
              ? 'bg-amber-950/50 border-amber-500 ring-1 ring-amber-500 shadow-amber-500/25'
              : 'bg-slate-900/90 border-amber-500/30 hover:border-amber-500/60'
          }`}
          title="Clique para inspecionar as composições em manutenção"
        >
          <div className="flex items-center justify-between text-amber-400 text-xs font-medium">
            <span>Composições em Manutenção</span>
            <Wrench className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-amber-300">{maintenanceCount}</span>
            <span className="text-xs text-slate-400">no pátio ({totalFleetMaintenanceVehicles.length} na frota)</span>
          </div>
          <p className="text-[10px] text-amber-400/80 mt-2 font-medium">
            {showMaintenancePanel ? '▲ Fechar detalhes' : '▼ Clique para inspecionar'}
          </p>
        </button>

        {/* 4. Vias com Restrição */}
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-rose-500/30 shadow-md">
          <div className="flex items-center justify-between text-rose-400 text-xs font-medium">
            <span>Vias com Restrição</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-rose-300">{restrictedSpotsCount}</span>
            <span className="text-xs text-slate-400">bloqueadas / gabarito</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-mono">
            {restrictedSpotsCount === 0 ? 'Nenhuma restrição ativa' : 'Interdição / Obras'}
          </p>
        </div>
      </div>

      {/* Painel Expansível de Composições em Manutenção */}
      {showMaintenancePanel && (
        <div id="maintenance-compositions-panel" className="p-4 rounded-xl bg-slate-900 border border-amber-500/40 shadow-xl shadow-amber-950/30 space-y-3 animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Wrench className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <span>Painel de Composições em Manutenção</span>
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                    {maintenanceCount} no pátio ({totalFleetMaintenanceVehicles.length} na frota)
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400">
                  Composições sinalizadas para manutenção (corretiva, preventiva ou revisão técnica). Clique para abrir a ficha técnica.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowMaintenancePanel(false)}
              className="text-xs text-slate-400 hover:text-white px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 transition border border-slate-700 self-end sm:self-auto cursor-pointer"
            >
              Fechar Painel &times;
            </button>
          </div>

          {totalFleetMaintenanceVehicles.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-400 bg-slate-950/60 rounded-lg border border-slate-800">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto mb-1.5" />
              Nenhuma composição com status de manutenção no pátio no momento.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5">
              {totalFleetMaintenanceVehicles.map((veh) => {
                const trk = tracks.find(t => t.id === veh.currentTrackId || t.assignedVehicles.includes(veh.id));
                const spot = trk?.spots?.find(s => s.id === veh.currentSpotId || s.vehicleId === veh.id);

                return (
                  <div
                    key={veh.id}
                    id={`maint-card-${veh.id}`}
                    className="p-3 rounded-lg bg-slate-950 border border-amber-500/40 hover:border-amber-400 transition flex flex-col justify-between gap-2 shadow-sm"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="font-mono font-bold text-xs text-white flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                          {veh.name}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">
                          MANUTENÇÃO
                        </span>
                        {veh.hasOperationalPhone && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-black font-mono flex items-center gap-0.5 shadow-sm border border-emerald-300">
                            <Smartphone className="w-2.5 h-2.5" /> Cel
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {trk ? `${trk.code} • ${trk.name}` : 'Em trânsito / Pátio'}
                        {spot ? ` (${spot.positionName || `Vaga ${spot.spotNumber}`})` : ''}
                      </div>
                      <div className="text-[11px] text-slate-300 mt-1">
                        <strong>Motivo:</strong> {veh.maintenanceReason || 'Intervenção preventiva periódica'}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSelectVehicle(veh)}
                      className="w-full mt-1 px-2.5 py-1.5 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-semibold border border-amber-500/40 transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      <span>Ficha &bull; Alterar Status</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Sinóptico CCO Fiel (CTC Intertravamento) */}
      <YardSynopticMap
        tracks={tracks}
        vehicles={vehicles}
        currentUser={currentUser}
        activeManobrador={activeManobrador}
        onToggleManobrador={onToggleManobrador}
        onSelectTrack={handleSynopticTrackSelect}
        onSelectVehicle={onSelectVehicle}
        onNewMovementWithTrack={onNewMovementWithTrack}
      />

      {/* MODAL: SPOT DRILL-DOWN DETAILS & TRAIN INFORMATION */}
      {selectedSpot && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedSpot(null);
          }}
        >
          <div 
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 p-3.5 sm:p-4 shrink-0 bg-slate-900/90">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className={`p-2 rounded-lg ${getSpotStatusConfig(activeModalSpot?.status || selectedSpot?.spot?.status).bgColor} shrink-0`}>
                  {getSpotStatusConfig(activeModalSpot?.status || selectedSpot?.spot?.status).icon}
                </div>
                <div className="min-w-0">
                  <h2 className="text-sm sm:text-base font-bold text-white truncate flex items-center gap-1.5 flex-wrap">
                    <span className="text-amber-400 font-extrabold">
                      {activeModalSpot?.positionName || `Posição ${activeModalSpot?.positionLetter || activeModalSpot?.spotNumber || 'A'}`}
                    </span>
                    <span className="text-slate-500 font-normal">&bull;</span>
                    <span className="text-sky-300 font-semibold">{activeModalTrack?.name || selectedSpot.track.name}</span>
                    {selectedVehicle && (
                      <>
                        <span className="text-slate-500 font-normal">&bull;</span>
                        <span className="text-emerald-400 font-mono text-xs bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                          {selectedVehicle.name}
                        </span>
                      </>
                    )}
                  </h2>
                  <div className="text-[11px] text-slate-400 font-mono truncate mt-0.5">
                    Extensão da vaga: <strong>{activeModalSpot?.lengthMeters || selectedSpot.spot.lengthMeters}m</strong> &bull; Via: <strong>{activeModalTrack?.name || selectedSpot.track.name}</strong>
                  </div>
                </div>
              </div>

              <button
                id="close-spot-modal"
                type="button"
                onClick={() => setSelectedSpot(null)}
                className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition flex items-center justify-center cursor-pointer shrink-0 ml-2"
                aria-label="Fechar janela"
                title="Fechar"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-3.5 sm:p-4 overflow-y-auto flex-1 space-y-4 text-xs">

            {/* SELETOR INTERATIVO DE TODAS AS POSIÇÕES DA VIA (Posição A, Posição B, Posição C) */}
            {activeModalTrack && activeModalTrack.spots && activeModalTrack.spots.length > 1 && (
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-sky-400" />
                    Posições desta Via ({activeModalTrack.name}):
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Clique para inspecionar ou alterar
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {activeModalTrack.spots.map((spot) => {
                    const isCurrent = spot.id === (activeModalSpot?.id || selectedSpot.spot.id);
                    const veh = getVehicleForSpot(spot);
                    const isMaint = spot.status === 'maintenance' || veh?.status === 'in_maintenance' || veh?.maintenanceStatus === 'in_progress';
                    const isOcc = spot.status === 'occupied' || (veh && !isMaint);
                    const isRestr = spot.status === 'restricted';
                    const isFree = !isOcc && !isMaint && !isRestr;

                    return (
                      <button
                        key={spot.id}
                        type="button"
                        onClick={() => handleSpotClick(spot, activeModalTrack)}
                        className={`p-2.5 rounded-lg border text-left transition cursor-pointer flex flex-col justify-between gap-1.5 relative ${
                          isCurrent
                            ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/50 shadow-md shadow-sky-500/20'
                            : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-bold text-xs text-white flex items-center gap-1.5 truncate">
                            <span className={`w-2 h-2 rounded-full shrink-0 ${
                              isMaint ? 'bg-amber-400 animate-pulse' :
                              isOcc ? 'bg-sky-400' :
                              isRestr ? 'bg-rose-400' : 'bg-emerald-400'
                            }`} />
                            <span className="truncate">{spot.positionName || `Posição ${spot.positionLetter || spot.spotNumber}`}</span>
                          </span>
                          {isCurrent && (
                            <span className="text-[9px] px-1 py-0.2 rounded bg-sky-500 text-slate-950 font-bold uppercase shrink-0">
                              Ativa
                            </span>
                          )}
                        </div>

                        <div className="flex items-center justify-between gap-1 mt-0.5">
                          <span className={`text-[10px] font-mono font-semibold truncate ${
                            isMaint ? 'text-amber-300' :
                            isOcc ? 'text-sky-300' :
                            isRestr ? 'text-rose-300' : 'text-emerald-300'
                          }`}>
                            {isMaint ? '🔧 Manutenção' :
                             isOcc ? `🚄 ${veh ? veh.name : 'Ocupada'}` :
                             isRestr ? '⛔ Interditada' : '🟢 Vazia / Livre'}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono shrink-0">
                            {spot.lengthMeters}m
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Current Spot Status Badge & Quick Action Buttons */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-slate-400">
                    Status de <strong className="text-white">{activeModalSpot?.positionName || `Posição ${activeModalSpot?.positionLetter || activeModalSpot?.spotNumber || 'A'}`}</strong>:
                  </span>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold border ${getSpotStatusConfig(activeModalSpot?.status || selectedSpot?.spot?.status).badgeColor}`}>
                    {getSpotStatusConfig(activeModalSpot?.status || selectedSpot?.spot?.status).icon}
                    {getSpotStatusConfig(activeModalSpot?.status || selectedSpot?.spot?.status).label}
                  </span>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Direct 1-Click Quick Toggle */}
                  {(activeModalSpot?.status === 'occupied' || selectedVehicle) ? (
                    <button
                      type="button"
                      disabled={isSavingSpot}
                      onClick={() => activeModalSpot && activeModalTrack && handleQuickFreeSpot(activeModalSpot, activeModalTrack)}
                      className="px-2.5 py-1 rounded bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                      title="Desocupar esta posição e torná-la Livre/Vazia imediatamente"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Liberar / Tornar Vazia</span>
                    </button>
                  ) : (activeModalSpot?.status === 'free') ? (
                    <button
                      type="button"
                      disabled={isSavingSpot}
                      onClick={() => {
                        setEditStatus('occupied');
                        setIsEditingSpotStatus(true);
                      }}
                      className="px-2.5 py-1 rounded bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 border border-sky-500/40 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                      title="Definir esta posição como ocupada"
                    >
                      <Train className="w-3.5 h-3.5 text-sky-400" />
                      <span>Definir Ocupada</span>
                    </button>
                  ) : null}

                  <button
                    id="toggle-edit-spot-status-btn"
                    onClick={() => setIsEditingSpotStatus(!isEditingSpotStatus)}
                    className="text-xs text-amber-400 hover:text-amber-300 underline font-medium"
                  >
                    {isEditingSpotStatus ? 'Fechar Edição' : 'Alterar Status / Opções'}
                  </button>
                </div>
              </div>
            </div>

            {/* Error Message Feedback */}
            {spotErrorMsg && (
              <div className="p-3 bg-rose-950/80 border border-rose-500/50 rounded-lg text-rose-300 text-xs flex items-center justify-between gap-2 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{spotErrorMsg}</span>
                </div>
                <button type="button" onClick={() => setSpotErrorMsg(null)} className="text-rose-400 hover:text-white">✕</button>
              </div>
            )}

            {/* Editing Spot Status Form */}
            {isEditingSpotStatus && (
              <div className="p-4 bg-slate-950/90 border border-amber-500/40 rounded-lg space-y-3 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 block">
                    Definir Status para {activeModalSpot?.positionName || `Posição ${activeModalSpot?.positionLetter || activeModalSpot?.spotNumber || 'A'}`} ({activeModalTrack?.name || selectedSpot.track.name}):
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Atualização em tempo real
                  </span>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <label className={`p-2 rounded border cursor-pointer text-center ${editStatus === 'free' ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <input type="radio" name="spot_status" checked={editStatus === 'free'} onChange={() => setEditStatus('free')} className="sr-only" />
                    Vazia / Livre
                  </label>
                  <label className={`p-2 rounded border cursor-pointer text-center ${editStatus === 'occupied' ? 'bg-sky-950/60 border-sky-500 text-sky-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <input type="radio" name="spot_status" checked={editStatus === 'occupied'} onChange={() => setEditStatus('occupied')} className="sr-only" />
                    Ocupada
                  </label>
                  <label className={`p-2 rounded border cursor-pointer text-center ${editStatus === 'maintenance' ? 'bg-amber-950/60 border-amber-500 text-amber-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <input type="radio" name="spot_status" checked={editStatus === 'maintenance'} onChange={() => setEditStatus('maintenance')} className="sr-only" />
                    Manutenção
                  </label>
                  <label className={`p-2 rounded border cursor-pointer text-center ${editStatus === 'restricted' ? 'bg-rose-950/60 border-rose-500 text-rose-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <input type="radio" name="spot_status" checked={editStatus === 'restricted'} onChange={() => setEditStatus('restricted')} className="sr-only" />
                    Com Restrição
                  </label>
                </div>

                {editStatus === 'occupied' && (
                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-semibold">
                      Composição / Trem nesta Posição (Opcional):
                    </label>
                    <select
                      value={selectedVehicleIdForSpot}
                      onChange={(e) => setSelectedVehicleIdForSpot(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white outline-none focus:border-sky-500"
                    >
                      <option value="">(Sem composição associada / Apenas marcar Ocupada)</option>
                      {vehicles.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name} ({v.id}) {v.currentTrackId ? `• Na via ${v.currentTrackId.replace('VIA-', '')}` : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {editStatus === 'restricted' && (
                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-semibold">
                      Motivo / Justificativa da Restrição *
                    </label>
                    <input
                      type="text"
                      required
                      value={editRestrictionReason}
                      onChange={(e) => setEditRestrictionReason(e.target.value)}
                      placeholder="Ex: Interdição física de via para manutenção"
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white outline-none focus:border-rose-500"
                    >
                    </input>
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    onClick={() => setIsEditingSpotStatus(false)}
                    className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleSaveSpotStatus}
                    disabled={isSavingSpot}
                    className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded shadow transition cursor-pointer"
                  >
                    {isSavingSpot ? 'Salvando...' : 'Confirmar Alteração'}
                  </button>
                </div>
              </div>
            )}

            {/* Restriction Warning if Spot is Restricted */}
            {(activeModalSpot?.status === 'restricted' || selectedSpot?.spot?.status === 'restricted') && (
              <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded-lg text-xs text-rose-300 flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-rose-200 block">Restrição Operacional Ativa Nesta Vaga:</strong>
                  <p className="mt-0.5 text-rose-300/90 leading-relaxed">
                    {activeModalSpot?.restrictionReason || selectedSpot?.spot?.restrictionReason || 'Interdição preventiva de via em conformidade com as normas regulamentadoras.'}
                  </p>
                </div>
              </div>
            )}

            {/* If Occupied with Train Vehicle: Drill-Down Details Required by User */}
            {selectedVehicle ? (
              <div className="space-y-4">
                {/* Composition Image Banner - Scaled +15% */}
                <div className="w-full bg-slate-950 rounded-xl border border-slate-800 p-3 flex flex-col items-center justify-center relative overflow-hidden">
                  <img
                    src={getVehicleIconUri(selectedVehicle)}
                    alt={selectedVehicle.name}
                    className="max-h-28 w-auto object-contain"
                  />
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-sky-950/80 border border-sky-600/50 text-sky-300 font-mono font-bold text-xs">
                    VLT {selectedVehicle.compositionNumber || selectedVehicle.id}
                  </div>

                  {/* Indicação Celular Operacional na parte inferior esquerda: "Cel" */}
                  {selectedVehicle.hasOperationalPhone && (
                    <div 
                      title="Composição com Celular Operacional a Bordo"
                      className="absolute bottom-2 left-2 px-2.5 py-1 rounded-md bg-emerald-500 text-slate-950 font-black font-mono text-xs flex items-center gap-1.5 shadow-lg border border-emerald-300 z-10 select-none animate-in fade-in"
                    >
                      <Smartphone className="w-3.5 h-3.5 text-slate-950 stroke-[2.5]" />
                      <span>Cel</span>
                    </div>
                  )}
                </div>

                {/* Botão e Indicador de Celular Operacional */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-inner">
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl transition ${selectedVehicle.hasOperationalPhone ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400 border border-slate-700'}`}>
                      <Smartphone className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">Celular Operacional a Bordo</span>
                        {selectedVehicle.hasOperationalPhone ? (
                          <span className="px-2 py-0.5 rounded bg-emerald-500 text-slate-950 font-black font-mono text-[10px] shadow-sm flex items-center gap-1 border border-emerald-300">
                            <Smartphone className="w-2.5 h-2.5" /> Cel Ativo
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-semibold border border-slate-700">
                            Não indicado
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {selectedVehicle.hasOperationalPhone
                          ? 'Composição com celular operacional em mãos. A indicação "Cel" é exibida na parte inferior esquerda no pátio.'
                          : 'Clique no botão ao lado para indicar que a composição está com celular operacional de pátio.'}
                      </p>
                    </div>
                  </div>

                  <button
                    id={`toggle-cel-btn-${selectedVehicle.id}`}
                    type="button"
                    onClick={(e) => handleToggleOperationalPhone(selectedVehicle, e)}
                    disabled={isTogglingPhone}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shrink-0 shadow-md ${
                      selectedVehicle.hasOperationalPhone
                        ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500 shadow-emerald-600/30'
                    }`}
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>
                      {isTogglingPhone 
                        ? 'Atualizando...' 
                        : selectedVehicle.hasOperationalPhone 
                          ? 'Remover Celular Operacional' 
                          : 'Indicar com Celular Operacional (Cel)'}
                    </span>
                  </button>
                </div>

                <div className="p-4 bg-slate-950/90 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
                    <div className="flex items-center gap-2">
                      <Train className="w-4 h-4 text-sky-400" />
                      <div>
                        <h4 className="font-bold text-sm text-white">{selectedVehicle.name}</h4>
                        <span className="text-[11px] font-mono text-amber-400">{selectedVehicle.id} &bull; {selectedVehicle.operatorCompany}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {(() => {
                        const theme = getTrainTheme(selectedVehicle);
                        return (
                          <span className={`text-[11px] px-2.5 py-0.5 rounded font-bold border flex items-center gap-1 ${theme.badgeBg} ${theme.badgeText} ${theme.badgeBorder}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${theme.dotColor}`} />
                            {theme.label}
                          </span>
                        );
                      })()}
                    </div>
                  </div>

                  {/* Tempo de Permanência */}
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1 font-semibold">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>Tempo de Permanência no Pátio:</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="font-bold text-amber-300 text-xs">
                        ~{selectedVehicle.estimatedDwellTimeHours || 8.0} horas estimadas
                      </span>
                      <span className="text-[11px] text-slate-400">
                        &bull; Tempo decorrido: <strong className="text-white">{selectedVehicle.dwellTimeHours || 10.5} horas</strong>
                      </span>
                    </div>
                  </div>

                  {/* Technical details row */}
                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                    <span>Peso Total: <strong className="text-white">{selectedVehicle.weightTons}t</strong></span>
                    <span>Extensão: <strong className="text-white">{selectedVehicle.lengthMeters}m</strong></span>
                    <span>Entrada no Pátio: <strong className="text-white">{new Date(selectedVehicle.entryDate).toLocaleString('pt-BR')}</strong></span>
                    <span>Registrado por: <strong className="text-white">{selectedVehicle.registeredBy}</strong></span>
                  </div>
                </div>

                {/* Modal Footer Actions for Occupied Spot */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                  <button
                    id="open-full-vehicle-passport-btn"
                    onClick={() => {
                      setSelectedSpot(null);
                      onSelectVehicle(selectedVehicle);
                    }}
                    className="w-full sm:w-auto px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 hover:text-white text-xs font-semibold border border-slate-700 transition flex items-center justify-center gap-2"
                  >
                    <Info className="w-4 h-4" />
                    <span>Ver Passaporte & Histórico Completo ({selectedVehicle.id})</span>
                  </button>

                  {onNewMovementWithTrack && (
                    <div className="flex flex-wrap items-center gap-2">
                      {selectedSpot.track.code === 'TF' && (
                        <button
                          id="exit-train-from-tf-spot-btn"
                          onClick={() => {
                            setSelectedSpot(null);
                            onNewMovementWithTrack(selectedSpot.track.id, selectedSpot.spot.id, 'exit');
                          }}
                          className="w-full sm:w-auto px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 transition flex items-center justify-center gap-1.5 cursor-pointer"
                          title="Tirar a composição da Via TF e despachar para fora do pátio"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>Sair do Pátio</span>
                        </button>
                      )}

                      <button
                        id="move-train-from-spot-btn"
                        onClick={() => {
                          setSelectedSpot(null);
                          onNewMovementWithTrack(selectedSpot.track.id, selectedSpot.spot.id);
                        }}
                        className="w-full sm:w-auto px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <CornerDownRight className="w-4 h-4" />
                        <span>Manobrar Este Trem</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : selectedSpot?.spot?.status === 'free' ? (
              <div className="p-4 bg-emerald-950/20 border border-emerald-800/30 rounded-xl text-center space-y-3">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <div>
                  <h4 className="text-sm font-bold text-white">Vaga Desimpedida e Disponível</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
                    Esta vaga de {selectedSpot.spot.lengthMeters}m na linha {selectedSpot.track.name} está pronta para receber manobra de composição ou estacionamento de material rodante.
                  </p>
                </div>

                {onNewMovementWithTrack && (
                  <button
                    id="park-in-free-spot-btn"
                    onClick={() => {
                      setSelectedSpot(null);
                      onNewMovementWithTrack(selectedSpot.track.id, selectedSpot.spot.id);
                    }}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-md transition inline-flex items-center gap-2"
                  >
                    <CornerDownRight className="w-4 h-4" />
                    <span>Estacionar / Manobrar Trem Nesta Vaga</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-center text-xs text-slate-400">
                Nenhum trem individual alocado no momento para esta vaga técnica.
              </div>
            )}

            </div>

            {/* Modal Sticky Footer */}
            <div className="p-3 sm:p-4 border-t border-slate-800 shrink-0 bg-slate-900 flex items-center justify-between gap-2">
              <button
                id="footer-close-spot-modal"
                type="button"
                onClick={() => setSelectedSpot(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs sm:text-sm transition cursor-pointer border border-slate-700/80 shadow-sm"
              >
                Fechar
              </button>
              <div className="text-[11px] text-slate-400 font-mono">
                {selectedSpot.track.name} &bull; {selectedSpot.spot.lengthMeters}m
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
