import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { 
  getStoredUsers, 
  setStoredUsers, 
  validateBadgeNumber, 
  formatBadgeNumber, 
  saveUser, 
  getClientDeviceName,
  isSupervisor 
} from '../utils/rbac';
import { apiService } from '../services/apiService';
import { 
  ShieldCheck, 
  User, 
  X, 
  Trash2, 
  Search, 
  RefreshCw, 
  AlertTriangle, 
  Users, 
  Laptop, 
  Smartphone, 
  Monitor, 
  UserPlus, 
  CheckCircle2, 
  Lock, 
  ShieldAlert,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';

interface ProfileManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onUserDeleted?: (deletedUserId: string) => void;
  onUserCreated?: (newUser: UserProfile) => void;
}

export const ProfileManagementModal: React.FC<ProfileManagementModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserDeleted,
  onUserCreated,
}) => {
  const [usersList, setUsersList] = useState<UserProfile[]>(() => getStoredUsers());
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'tecnico_mro' | 'controlador_cco' | 'supervisor_cco'>('all');
  const [deviceFilter, setDeviceFilter] = useState<'all' | 'windows' | 'mobile'>('all');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Deletion state
  const [deleteTargetUser, setDeleteTargetUser] = useState<UserProfile | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  // Creation state inside supervisor management
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [newName, setNewName] = useState('');
  const [newBadge, setNewBadge] = useState('38-');
  const [newRole, setNewRole] = useState<'tecnico_mro' | 'controlador_cco' | 'supervisor_cco'>('controlador_cco');
  const [newPassword, setNewPassword] = useState('');
  const [isSubmittingNew, setIsSubmittingNew] = useState(false);

  const isSupervisorUser = currentUser ? isSupervisor(currentUser.role) : false;

  // Fetch users from unified backend database
  const fetchUnifiedUsers = async () => {
    try {
      setLoadingUsers(true);
      setErrorMsg(null);
      const res = await apiService.getUsers();
      if (res && Array.isArray(res.users) && res.users.length > 0) {
        setUsersList(res.users);
        setStoredUsers(res.users);
      }
    } catch (e: any) {
      console.warn('[Unified DB] Carregando usuários do cache local:', e);
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchUnifiedUsers();
      setIsCreatingUser(false);
      setDeleteTargetUser(null);
      setErrorMsg(null);
      setSuccessMsg(null);
    }
  }, [isOpen]);

  // Subscribe to real-time 'users_updated' SSE events
  useEffect(() => {
    const unsubscribe = apiService.subscribe('users_updated', (data: any) => {
      if (data && Array.isArray(data.users)) {
        setUsersList(data.users);
        setStoredUsers(data.users);
      }
    });
    return () => unsubscribe();
  }, []);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Deletion logic
  const handleInitiateDelete = (user: UserProfile) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    // Safety constraint: Prevent deleting the last remaining supervisor
    const supervisors = usersList.filter(u => u.role === 'supervisor_cco' || u.role === 'admin');
    const isTargetSupervisor = user.role === 'supervisor_cco' || user.role === 'admin';
    if (isTargetSupervisor && supervisors.length <= 1) {
      setErrorMsg('Operação Bloqueada: Não é permitido excluir o único Supervisor do CCO restante no sistema.');
      return;
    }

    setDeleteTargetUser(user);
    setDeleteReason('');
  };

  const handleConfirmDelete = async () => {
    if (!deleteTargetUser || !currentUser) return;
    if (!isSupervisorUser) {
      setErrorMsg('Apenas o Supervisor de CCO pode executar a exclusão de perfis.');
      return;
    }

    setIsDeleting(true);
    setErrorMsg(null);
    try {
      const res = await apiService.deleteUser(deleteTargetUser.id, currentUser, deleteReason);
      if (res && Array.isArray(res.users)) {
        setUsersList(res.users);
        setStoredUsers(res.users);
      } else {
        const remaining = usersList.filter(u => u.id !== deleteTargetUser.id);
        setUsersList(remaining);
        setStoredUsers(remaining);
      }

      setSuccessMsg(`Perfil do operador "${deleteTargetUser.name}" (${deleteTargetUser.badgeNumber}) excluído permanentemente do banco unificado.`);
      if (onUserDeleted) {
        onUserDeleted(deleteTargetUser.id);
      }
      setDeleteTargetUser(null);
      setDeleteReason('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Falha ao excluir perfil do operador.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Creation logic directly from supervisor management
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!newName.trim() || newName.trim().length < 3) {
      setErrorMsg('Informe o nome completo do operador.');
      return;
    }

    const cleanBadge = formatBadgeNumber(newBadge);
    if (!validateBadgeNumber(cleanBadge)) {
      setErrorMsg('Matrícula inválida. Utilize o formato padrão: 38-XXXXX.');
      return;
    }

    if (!newPassword || newPassword.length < 3) {
      setErrorMsg('A senha operacional deve possuir pelo menos 3 dígitos.');
      return;
    }

    const badgeExists = usersList.some(u => u.badgeNumber.toLowerCase() === cleanBadge.toLowerCase());
    if (badgeExists) {
      setErrorMsg(`A matrícula ${cleanBadge} já está cadastrada no sistema.`);
      return;
    }

    setIsSubmittingNew(true);
    try {
      const clientDevice = getClientDeviceName();
      const roleLabel = 
        newRole === 'tecnico_mro' ? 'Técnico de Manutenção MRO' :
        newRole === 'controlador_cco' ? 'Controlador de Tráfego CCO' : 
        'Supervisor de Turno CCO';
      const department = 
        newRole === 'tecnico_mro' ? 'Oficina & Manutenção (MRO)' : 
        'Centro de Controle Operacional (CCO)';

      let createdUser: UserProfile;
      try {
        const serverRes = await apiService.registerUser({
          name: newName.trim(),
          badgeNumber: cleanBadge,
          role: newRole,
          password: newPassword,
          createdDevice: clientDevice,
          deviceType: /windows/i.test(clientDevice) ? 'windows' : /mobile|android|iphone|ipad|celular/i.test(clientDevice) ? 'mobile' : 'other',
          avatar: newRole === 'tecnico_mro'
            ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
            : newRole === 'supervisor_cco'
            ? 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
            : 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        }, clientDevice);
        createdUser = serverRes.user;
        if (serverRes.users && Array.isArray(serverRes.users)) {
          setUsersList(serverRes.users);
          setStoredUsers(serverRes.users);
        }
      } catch (srvErr) {
        // Fallback local save
        const fallbackUser: UserProfile = {
          id: `usr-${Date.now().toString().slice(-6)}`,
          name: newName.trim(),
          badgeNumber: cleanBadge,
          role: newRole,
          roleLabel,
          department,
          password: newPassword,
          createdDevice: clientDevice,
          deviceType: /windows/i.test(clientDevice) ? 'windows' : /mobile|android|iphone|ipad|celular/i.test(clientDevice) ? 'mobile' : 'other',
          avatar: newRole === 'tecnico_mro'
            ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
            : newRole === 'supervisor_cco'
            ? 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
            : 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
          createdAt: new Date().toISOString()
        };
        const updatedUsers = saveUser(fallbackUser);
        createdUser = fallbackUser;
        setUsersList(updatedUsers);
      }

      setSuccessMsg(`Perfil do operador "${createdUser.name}" (${createdUser.badgeNumber}) cadastrado com sucesso.`);
      if (onUserCreated) onUserCreated(createdUser);

      // Reset form
      setNewName('');
      setNewBadge('38-');
      setNewPassword('');
      setIsCreatingUser(false);
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro ao cadastrar operador.');
    } finally {
      setIsSubmittingNew(false);
    }
  };

  // Filter users
  const filteredUsers = usersList.filter(u => {
    const matchesSearch = 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.badgeNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.department && u.department.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (!matchesSearch) return false;

    if (roleFilter === 'tecnico_mro' && u.role !== 'tecnico_mro' && u.role !== 'maintenance_tech') return false;
    if (roleFilter === 'controlador_cco' && u.role !== 'controlador_cco' && u.role !== 'cco_dispatcher') return false;
    if (roleFilter === 'supervisor_cco' && u.role !== 'supervisor_cco' && u.role !== 'admin') return false;

    if (deviceFilter === 'windows') {
      const isWin = u.deviceType === 'windows' || 
        (u.createdDevice && /windows/i.test(u.createdDevice)) || 
        (u.lastLoginDevice && /windows/i.test(u.lastLoginDevice));
      if (!isWin) return false;
    }

    if (deviceFilter === 'mobile') {
      const isMob = u.deviceType === 'mobile' || 
        (u.createdDevice && /mobile|android|iphone|ipad|celular/i.test(u.createdDevice)) || 
        (u.lastLoginDevice && /mobile|android|iphone|ipad|celular/i.test(u.lastLoginDevice));
      if (!isMob) return false;
    }

    return true;
  });

  // Calculate platform metrics
  const totalUsersCount = usersList.length;
  const windowsUsersCount = usersList.filter(u => 
    u.deviceType === 'windows' || 
    (u.createdDevice && /windows/i.test(u.createdDevice)) ||
    (u.lastLoginDevice && /windows/i.test(u.lastLoginDevice))
  ).length;
  const mobileUsersCount = usersList.filter(u => 
    u.deviceType === 'mobile' || 
    (u.createdDevice && /mobile|android|iphone|ipad|celular/i.test(u.createdDevice)) ||
    (u.lastLoginDevice && /mobile|android|iphone|ipad|celular/i.test(u.lastLoginDevice))
  ).length;
  const supervisorsCount = usersList.filter(u => u.role === 'supervisor_cco' || u.role === 'admin').length;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-2 sm:p-4 overflow-hidden animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div 
        className="w-full max-w-3xl max-h-[92vh] sm:max-h-[88vh] rounded-2xl bg-slate-900 border border-purple-500/40 shadow-2xl flex flex-col text-slate-100 overflow-hidden my-auto animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="profile-mgmt-title"
      >
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-purple-950/80 via-slate-900 to-slate-900 p-3 sm:p-4 border-b border-purple-500/30 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="p-2 sm:p-2.5 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40 shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 id="profile-mgmt-title" className="font-bold text-sm sm:text-base text-white tracking-tight">
                  Gestão de Perfis &bull; CCO
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-900/60 text-purple-200 border border-purple-500/30">
                  Banco de Dados Unificado
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5 flex-wrap">
                <span>Supervisor autenticado:</span>
                <strong className="text-amber-400 font-medium">{currentUser?.name}</strong>
                <span className="font-mono text-purple-300">({currentUser?.badgeNumber})</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={fetchUnifiedUsers}
              disabled={loadingUsers}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer disabled:opacity-50"
              title="Recarregar banco de dados unificado"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingUsers ? 'animate-spin text-purple-400' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition cursor-pointer"
              title="Fechar Janela"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Security Gate Check */}
        {!isSupervisorUser ? (
          <div className="p-6 sm:p-8 flex flex-col items-center justify-center text-center space-y-4">
            <div className="p-4 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-400">
              <ShieldAlert className="w-12 h-12" />
            </div>
            <div className="max-w-md space-y-2">
              <h3 className="font-bold text-base text-white">Acesso Restrito ao Supervisor de CCO</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                A gestão e exclusão de perfis do banco de dados unificado requer autenticação prévia com credenciais de <strong>Supervisor de CCO</strong>.
              </p>
              <p className="text-[11px] text-slate-400">
                Seu perfil atual ({currentUser?.name || 'Não identificado'}) possui perfil de {currentUser?.roleLabel || 'Operador sem permissão administrativa'}.
              </p>
            </div>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
            >
              Fechar
            </button>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto overscroll-contain p-3.5 sm:p-5 space-y-4">
            
            {/* Real-time Status & Platform Metrics */}
            <div className="p-3 rounded-xl bg-gradient-to-r from-purple-950/40 via-slate-850 to-slate-900 border border-purple-500/30">
              <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                  </span>
                  <span className="font-bold text-xs text-white">Sincronização Ativa em Tempo Real</span>
                </div>
                <span className="text-[10px] text-purple-300 font-mono bg-purple-900/50 px-2 py-0.5 rounded border border-purple-500/30">
                  Windows (PC) &bull; Mobile (Android/iOS)
                </span>
              </div>

              {/* Counter metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-700/80 text-center">
                  <div className="text-[10px] text-slate-400">Total de Perfis</div>
                  <div className="text-base font-bold text-white">{totalUsersCount}</div>
                </div>
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-700/80 text-center">
                  <div className="text-[10px] text-blue-400 flex items-center justify-center gap-1">
                    <Laptop className="w-3 h-3" />
                    <span>Windows (PC)</span>
                  </div>
                  <div className="text-base font-bold text-blue-300">{windowsUsersCount}</div>
                </div>
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-700/80 text-center">
                  <div className="text-[10px] text-emerald-400 flex items-center justify-center gap-1">
                    <Smartphone className="w-3 h-3" />
                    <span>Mobile (Celular)</span>
                  </div>
                  <div className="text-base font-bold text-emerald-300">{mobileUsersCount}</div>
                </div>
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-700/80 text-center">
                  <div className="text-[10px] text-purple-400 flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>Supervisores</span>
                  </div>
                  <div className="text-base font-bold text-purple-300">{supervisorsCount}</div>
                </div>
              </div>
            </div>

            {/* Error / Success Feedback */}
            {errorMsg && (
              <div className="p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2 animate-in fade-in">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span className="flex-1">{errorMsg}</span>
                <button onClick={() => setErrorMsg(null)} className="text-slate-400 hover:text-white">✕</button>
              </div>
            )}

            {successMsg && (
              <div className="p-2.5 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="flex-1">{successMsg}</span>
                <button onClick={() => setSuccessMsg(null)} className="text-slate-400 hover:text-white">✕</button>
              </div>
            )}

            {/* Sub-form: Create New Operator (as supervisor) */}
            {isCreatingUser ? (
              <div className="p-4 rounded-xl bg-slate-800/80 border border-purple-500/30 space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                  <div className="flex items-center gap-2 font-bold text-xs text-white">
                    <UserPlus className="w-4 h-4 text-purple-400" />
                    <span>Novo Cadastro de Operador no Banco Unificado</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsCreatingUser(false)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Cancelar
                  </button>
                </div>

                <form onSubmit={handleCreateUser} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-300 font-semibold mb-1">
                        Nome Completo do Operador
                      </label>
                      <input
                        type="text"
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="Ex: Carlos Santana"
                        className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-300 font-semibold mb-1">
                        Matrícula Operacional (Padrão 38-XXXXX)
                      </label>
                      <input
                        type="text"
                        value={newBadge}
                        onChange={(e) => {
                          const val = e.target.value.toUpperCase();
                          setNewBadge(val.startsWith('38-') ? val : `38-${val.replace(/^38-?/i, '')}`);
                        }}
                        placeholder="38-10492"
                        className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-amber-400 placeholder-slate-500 focus:outline-none focus:border-purple-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-300 font-semibold mb-1">
                        Perfil de Acesso (Função Operacional)
                      </label>
                      <select
                        value={newRole}
                        onChange={(e: any) => setNewRole(e.target.value)}
                        className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-purple-500"
                      >
                        <option value="controlador_cco">Controlador de Tráfego CCO</option>
                        <option value="tecnico_mro">Técnico de Manutenção MRO</option>
                        <option value="supervisor_cco">Supervisor de Turno CCO</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-300 font-semibold mb-1">
                        Senha Operacional (Mínimo 3 dígitos)
                      </label>
                      <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="••••••"
                        className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsCreatingUser(false)}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmittingNew}
                      className="px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{isSubmittingNew ? 'Gravando no Banco...' : 'Cadastrar Operador'}</span>
                    </button>
                  </div>
                </form>
              </div>
            ) : null}

            {/* Filter Toolbar */}
            <div className="space-y-2">
              <div className="flex flex-col sm:flex-row gap-2 items-center justify-between">
                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filtrar por nome, matrícula ou área..."
                    className="w-full pl-8 pr-2.5 py-1.5 bg-slate-800/90 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
                  {!isCreatingUser && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsCreatingUser(true);
                        setErrorMsg(null);
                        setSuccessMsg(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Novo Perfil</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Role & Device Filter Chips */}
              <div className="flex items-center gap-2 flex-wrap text-[10px]">
                <div className="flex items-center gap-1 bg-slate-950/60 p-0.5 rounded-lg border border-slate-800">
                  <span className="px-1.5 text-slate-500 font-semibold">Função:</span>
                  <button
                    type="button"
                    onClick={() => setRoleFilter('all')}
                    className={`px-2 py-1 rounded transition cursor-pointer ${
                      roleFilter === 'all' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Todos ({usersList.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setRoleFilter('controlador_cco')}
                    className={`px-2 py-1 rounded transition cursor-pointer ${
                      roleFilter === 'controlador_cco' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Controladores
                  </button>
                  <button
                    type="button"
                    onClick={() => setRoleFilter('tecnico_mro')}
                    className={`px-2 py-1 rounded transition cursor-pointer ${
                      roleFilter === 'tecnico_mro' ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    MRO
                  </button>
                  <button
                    type="button"
                    onClick={() => setRoleFilter('supervisor_cco')}
                    className={`px-2 py-1 rounded transition cursor-pointer ${
                      roleFilter === 'supervisor_cco' ? 'bg-purple-500/20 text-purple-300 font-bold border border-purple-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Supervisores
                  </button>
                </div>

                <div className="flex items-center gap-1 bg-slate-950/60 p-0.5 rounded-lg border border-slate-800">
                  <span className="px-1.5 text-slate-500 font-semibold">Origem:</span>
                  <button
                    type="button"
                    onClick={() => setDeviceFilter('all')}
                    className={`px-2 py-1 rounded transition cursor-pointer ${
                      deviceFilter === 'all' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Todos
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeviceFilter('windows')}
                    className={`px-2 py-1 rounded flex items-center gap-1 transition cursor-pointer ${
                      deviceFilter === 'windows' ? 'bg-blue-500/20 text-blue-300 font-bold border border-blue-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Laptop className="w-2.5 h-2.5" />
                    <span>Windows ({windowsUsersCount})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeviceFilter('mobile')}
                    className={`px-2 py-1 rounded flex items-center gap-1 transition cursor-pointer ${
                      deviceFilter === 'mobile' ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Smartphone className="w-2.5 h-2.5" />
                    <span>Mobile ({mobileUsersCount})</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Unified Profiles List */}
            <div className="space-y-2 max-h-[44vh] overflow-y-auto pr-1">
              {filteredUsers.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-800/40 rounded-xl border border-slate-800">
                  Nenhum operador encontrado com os filtros selecionados.
                </div>
              ) : (
                filteredUsers.map((user) => {
                  const isMro = user.role === 'tecnico_mro' || user.role === 'maintenance_tech';
                  const isCco = user.role === 'controlador_cco' || user.role === 'cco_dispatcher';
                  const isSup = user.role === 'supervisor_cco' || user.role === 'admin';
                  const isCurrent = currentUser?.id === user.id;
                  const isWin = user.deviceType === 'windows' || 
                    (user.createdDevice && /windows/i.test(user.createdDevice)) ||
                    (user.lastLoginDevice && /windows/i.test(user.lastLoginDevice));
                  const isMob = user.deviceType === 'mobile' || 
                    (user.createdDevice && /mobile|android|iphone|ipad|celular/i.test(user.createdDevice)) ||
                    (user.lastLoginDevice && /mobile|android|iphone|ipad|celular/i.test(user.lastLoginDevice));

                  return (
                    <div
                      key={user.id}
                      className={`p-3 rounded-xl border transition-all ${
                        isCurrent 
                          ? 'bg-purple-950/20 border-purple-500/50 ring-1 ring-purple-500/20' 
                          : 'bg-slate-800/60 border-slate-700/80 hover:bg-slate-800/90'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2.5">
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                            alt={user.name}
                            className="w-10 h-10 rounded-full object-cover border border-slate-700 shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h4 className="font-bold text-xs sm:text-sm text-white truncate max-w-[180px] sm:max-w-[280px]">
                                {user.name}
                              </h4>
                              <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                                isMro ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                                isCco ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                                'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                              }`}>
                                {user.roleLabel}
                              </span>
                              {isCurrent && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                                  Você (Sessão Atual)
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 flex-wrap">
                              <span className="font-mono font-bold text-amber-400">{user.badgeNumber}</span>
                              <span>•</span>
                              <span className="truncate max-w-[160px] sm:max-w-none">{user.department}</span>
                              <span>•</span>
                              <span className="inline-flex items-center gap-1 font-medium">
                                {isWin ? (
                                  <>
                                    <Laptop className="w-3 h-3 text-blue-400" />
                                    <span className="text-blue-300">Windows</span>
                                  </>
                                ) : isMob ? (
                                  <>
                                    <Smartphone className="w-3 h-3 text-emerald-400" />
                                    <span className="text-emerald-300">Mobile</span>
                                  </>
                                ) : (
                                  <>
                                    <Monitor className="w-3 h-3 text-slate-400" />
                                    <span>Estação CCO</span>
                                  </>
                                )}
                              </span>
                              {user.createdAt && (
                                <>
                                  <span>•</span>
                                  <span className="text-slate-500">
                                    Cadastrado em {new Date(user.createdAt).toLocaleDateString('pt-BR')}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Supervisor Delete Action */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleInitiateDelete(user)}
                            className="px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 hover:text-rose-200 transition cursor-pointer"
                            title={`Excluir perfil de ${user.name} (${user.badgeNumber})`}
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                            <span className="hidden sm:inline">Excluir Perfil</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <span className="text-[11px] text-slate-400">
            Ações auditadas sob registro CCO: <strong className="text-slate-200">{currentUser?.name}</strong>
          </span>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            Fechar Painel
          </button>
        </div>

        {/* DIALOG DE CONFIRMAÇÃO DE EXCLUSÃO DE PERFIL */}
        {deleteTargetUser && (
          <div className="absolute inset-0 z-50 bg-slate-950/90 backdrop-blur-md p-4 flex items-center justify-center animate-in fade-in">
            <div className="w-full max-w-md bg-slate-900 border border-rose-500/50 rounded-2xl p-4 sm:p-5 shadow-2xl space-y-3.5">
              <div className="flex items-center gap-2.5 text-rose-400">
                <div className="p-2 rounded-xl bg-rose-500/20 border border-rose-500/40">
                  <AlertTriangle className="w-5 h-5 text-rose-400" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">
                    Excluir Perfil do Banco Unificado?
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Ação restrita do Supervisor de CCO
                  </p>
                </div>
              </div>

              {/* Target Operator Card */}
              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center gap-3">
                <img 
                  src={deleteTargetUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                  alt={deleteTargetUser.name}
                  className="w-10 h-10 rounded-full object-cover border border-slate-600 shrink-0"
                />
                <div className="min-w-0">
                  <div className="font-bold text-xs sm:text-sm text-white truncate">
                    {deleteTargetUser.name}
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center gap-2">
                    <span className="font-mono text-amber-400">{deleteTargetUser.badgeNumber}</span>
                    <span>•</span>
                    <span>{deleteTargetUser.roleLabel}</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-300 space-y-1 bg-rose-500/10 p-2.5 rounded-lg border border-rose-500/25">
                <p className="font-semibold text-rose-300">
                  Atenção: Esta ação removerá permanentemente o perfil de operador do banco de dados centralizado.
                </p>
                <p className="text-[11px] text-slate-300">
                  A exclusão será sincronizada imediatamente em tempo real tanto no Windows quanto em celulares (Mobile).
                </p>
              </div>

              {/* Reason input for audit trail */}
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Motivo da exclusão (será gravado no log de auditoria CCO):
                </label>
                <input
                  type="text"
                  value={deleteReason}
                  onChange={(e) => setDeleteReason(e.target.value)}
                  placeholder="Ex: Desligamento, remanejamento de turno ou duplicidade..."
                  className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setDeleteTargetUser(null);
                    setDeleteReason('');
                  }}
                  disabled={isDeleting}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  disabled={isDeleting}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{isDeleting ? 'Excluindo do Banco...' : 'Confirmar Exclusão'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
