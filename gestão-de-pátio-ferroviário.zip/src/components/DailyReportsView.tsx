import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { apiService, DailyReportResponse } from '../services/apiService';
import { DailyReportSummary, MovementRecord, YardTrack } from '../types';
import { 
  FileText, 
  Printer, 
  Download, 
  Calendar, 
  TrendingUp, 
  Clock, 
  Gauge, 
  CheckCircle2, 
  Train, 
  ArrowRight, 
  ShieldCheck, 
  Filter,
  RefreshCw
} from 'lucide-react';

interface DailyReportsViewProps {
  tracks?: YardTrack[];
  liveOccupancyPct?: number;
}

export const DailyReportsView: React.FC<DailyReportsViewProps> = ({ tracks, liveOccupancyPct }) => {
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [data, setData] = useState<DailyReportResponse | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchReport = useCallback((dateStr: string) => {
    setLoading(true);
    apiService.getDailyReport(dateStr)
      .then((res) => setData(res))
      .catch((err) => console.error('Erro ao buscar RDO:', err))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetchReport(selectedDate);

    // Atualização automática em tempo real via SSE quando houver manobras ou alterações de vagas ou edição de ODT
    const unsubMov = apiService.subscribe('movement_registered', () => {
      fetchReport(selectedDate);
    });
    const unsubSpot = apiService.subscribe('spot_updated', () => {
      fetchReport(selectedDate);
    });
    const unsubMovUpdated = apiService.subscribe('movement_updated', () => {
      fetchReport(selectedDate);
    });

    return () => {
      unsubMov();
      unsubSpot();
      unsubMovUpdated();
    };
  }, [selectedDate, fetchReport]);

  const isToday = selectedDate === new Date().toISOString().split('T')[0];

  const computedLiveRate = useMemo(() => {
    if (liveOccupancyPct !== undefined) return liveOccupancyPct;
    if (!tracks || tracks.length === 0) return null;
    const totalCapacity = tracks.reduce((acc, t) => acc + ((t.spots && t.spots.length > 0) ? t.spots.length : (t.capacityWagons || 1)), 0);
    const occupied = tracks.reduce((acc, t) => {
      if (t.spots && t.spots.length > 0) {
        return acc + t.spots.filter(s => s && (s.status === 'occupied' || !!s.vehicleId)).length;
      }
      return acc + (t.assignedVehicles?.length || 0);
    }, 0);
    return totalCapacity > 0 ? Math.round((occupied / totalCapacity) * 100) : 0;
  }, [tracks, liveOccupancyPct]);

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    if (!data) return;
    const headers = ['ID', 'Horario', 'Veiculo', 'Tipo', 'Motivo', 'Origem', 'Destino', 'Operador', 'Operador de Trem (ODT)'];
    const rows = data.movements.map(m => [
      m.id,
      m.timestamp,
      m.vehicleId,
      m.type,
      `"${m.reason}"`,
      `"${m.sourceTrackName || ''}"`,
      `"${m.targetTrackName || ''}"`,
      `"${m.operatorName}"`,
      `"${m.authorizedByCCO}"`
    ]);
    const csvString = '\uFEFF' + [headers.join(';'), ...rows.map(e => e.join(';'))].join('\r\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `RDO_Ferroviario_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const report = data?.report;

  return (
    <div className="space-y-6">
      
      {/* Top Filter and Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl bg-slate-900 border border-slate-800">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <span>Relatório Diário de Operação (RDO Ferroviário)</span>
          </h2>
          <p className="text-xs text-slate-400">
            Análise de desempenho logístico, histórico diário completo e auditoria de ocupação
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent text-white focus:outline-none cursor-pointer"
            />
          </div>

          <button
            onClick={() => fetchReport(selectedDate)}
            title="Atualizar dados do dia"
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-400' : ''}`} />
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-sky-400" />
            <span>Exportar CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/20 transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Imprimir / Salvar PDF</span>
          </button>
        </div>
      </div>

      {loading ? (
        <div className="p-12 text-center rounded-xl bg-slate-900 border border-slate-800 text-slate-400">
          <span className="inline-block w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-2" />
          <p className="text-xs">Consolidando dados diários de manobras e ocupação...</p>
        </div>
      ) : report ? (
        <div id="printable-rdo-area" className="space-y-6">
          
          {/* Printable Official Header */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-xs uppercase tracking-wider text-amber-400 font-bold">
                Relatório Operacional Oficial &bull; Centro de Controle Ferroviário
              </div>
              <h3 className="text-lg font-black text-white mt-0.5">
                RDO - PÁTIO INTEGRADO DE ESTACIONAMENTO E MANOBRA
              </h3>
              <p className="text-xs text-slate-400">
                Data de Referência: <strong className="text-white">{selectedDate}</strong> &bull; Gerado automaticamente pelo sistema às 18:30:00
              </p>
            </div>
            <div className="text-right text-xs">
              <div className="font-semibold text-emerald-400 flex items-center sm:justify-end gap-1">
                <CheckCircle2 className="w-4 h-4" />
                <span>Auditoria CCO Validada</span>
              </div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Pontualidade Geral: <strong className="text-white">{report.punctualityRatePercent}%</strong>
              </div>
            </div>
          </div>

          {/* Operational KPIs Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-slate-400 text-xs flex items-center justify-between">
                <span>Movimentações Realizadas</span>
                <Train className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white mt-1">
                {report.totalMovements}
              </div>
              <div className="text-[11px] text-slate-400 mt-1 flex gap-2 flex-wrap">
                <span className="text-emerald-400 font-medium">+{report.entries} entradas</span>
                <span className="text-sky-400 font-medium">-{report.exits} saídas</span>
                <span className="text-amber-400 font-medium">{report.internalShunts} manobras</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-slate-400 text-xs flex items-center justify-between">
                <span>{isToday ? 'Taxa de Ocupação (Tempo Real)' : 'Taxa Média de Ocupação'}</span>
                <Gauge className="w-4 h-4 text-sky-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white mt-1 flex items-baseline gap-2">
                <span>{isToday && computedLiveRate !== null ? computedLiveRate : report.averageOccupancyRate}%</span>
                {isToday && (
                  <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    Ao vivo
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Pico diário registrado: <strong className="text-rose-400">{Math.max(report.peakOccupancyRate, isToday && computedLiveRate !== null ? computedLiveRate : 0)}%</strong>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-slate-400 text-xs flex items-center justify-between">
                <span>Dwell Time Médio (Estadia)</span>
                <Clock className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white mt-1">
                {report.averageDwellTimeHours}h
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Dentro do SLA operacional (&le; 24h)
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-slate-400 text-xs flex items-center justify-between">
                <span>Preventivas Sincronizadas</span>
                <ShieldCheck className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white mt-1">
                {report.preventiveMaintenancesDone}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {report.criticalAlertsResolved} alertas operacionais resolvidos
              </div>
            </div>
          </div>

          {/* Detailed Movements Table for the Day */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-white flex items-center gap-2">
                <span>Registro Detalhado de Atividades no Dia</span>
                <span className="text-xs font-normal text-slate-400">({data.movements.length} eventos registrados)</span>
              </h4>
              <span className="text-[11px] text-slate-400">
                Via mais movimentada: <strong className="text-amber-400">{report.busiestTrack}</strong>
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-800/80 text-slate-400 font-semibold uppercase text-[10px] tracking-wider border-b border-slate-700">
                  <tr>
                    <th className="p-2.5">Horário</th>
                    <th className="p-2.5">Código / Prefixo</th>
                    <th className="p-2.5">Tipo</th>
                    <th className="p-2.5">Motivo da Movimentação</th>
                    <th className="p-2.5">Trajeto (Origem &rarr; Destino)</th>
                    <th className="p-2.5">Operador Responsável</th>
                    <th className="p-2.5">Operador de Trem (ODT)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-normal">
                  {data.movements.map((mov) => {
                    const timeStr = new Date(mov.timestamp).toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    });
                    return (
                      <tr key={mov.id} className="hover:bg-slate-800/40 transition">
                        <td className="p-2.5 font-mono text-slate-400">{timeStr}</td>
                        <td className="p-2.5 font-bold text-white font-mono">{mov.vehicleId}</td>
                        <td className="p-2.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            mov.type === 'entry'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : mov.type === 'exit'
                              ? 'bg-rose-500/20 text-rose-300'
                              : 'bg-sky-500/20 text-sky-300'
                          }`}>
                            {mov.type === 'entry' ? 'Entrada' : mov.type === 'exit' ? 'Saída' : 'Manobra'}
                          </span>
                        </td>
                        <td className="p-2.5 font-medium text-slate-200">{mov.reason}</td>
                        <td className="p-2.5 font-mono text-[11px] text-amber-300">
                          {mov.sourceTrackName?.split(' ')[0] || 'Ext'} &rarr; {mov.targetTrackName?.split(' ')[0] || 'Ext'}
                        </td>
                        <td className="p-2.5">
                          <div className="text-white font-medium">{mov.operatorName}</div>
                          <div className="text-[10px] text-slate-500">{mov.operatorRole}</div>
                        </td>
                        <td className="p-2.5 text-slate-400 text-[11px]">{mov.authorizedByCCO}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

          </div>

        </div>
      ) : null}

    </div>
  );
};
