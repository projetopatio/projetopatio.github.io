import React, { useState, useEffect } from 'react';
import { MaintenanceSchedule } from '../types';
import { apiService } from '../services/apiService';
import { 
  Share2, 
  RefreshCw, 
  CheckCircle2, 
  Calendar, 
  Wrench, 
  Code, 
  Copy, 
  Check, 
  Play, 
  ExternalLink, 
  Clock, 
  Building, 
  Database,
  ArrowUpRight
} from 'lucide-react';

export const SchedulesSyncView: React.FC = () => {
  const [schedules, setSchedules] = useState<MaintenanceSchedule[]>([]);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncSuccessMessage, setSyncSuccessMessage] = useState<string | null>(null);
  const [copiedToken, setCopiedToken] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'schedules' | 'api_docs' | 'sandbox'>('schedules');

  // Interactive API Sandbox state
  const [sandboxEndpoint, setSandboxEndpoint] = useState('/api/v1/schedules');
  const [sandboxMethod, setSandboxMethod] = useState<'GET' | 'POST'>('POST');
  const [sandboxPayload, setSandboxPayload] = useState(JSON.stringify({
    vehicleId: 'TUE-8501',
    vehicleName: 'TUE Alstom Série 8500 #8501 (8 Carros)',
    type: 'Revisão F1 Preventiva',
    scheduledDate: new Date(Date.now() + 86400000 * 5).toISOString(),
    estimatedDurationHours: 6,
    assignedWorkshopTrackId: 'VIA-P1',
    systemSource: 'SAP PM Ferroviário',
    technicianInCharge: 'Dra. Beatriz Fontana (Engª de Material Rodante)',
    description: 'Inspeção de pantógrafo, ar-condicionado de salão e ultrassom de truques.',
    externalSystemId: 'SAP-PM-99214',
  }, null, 2));
  const [sandboxResponse, setSandboxResponse] = useState<string | null>(null);
  const [sandboxLoading, setSandboxLoading] = useState(false);

  const fetchSchedules = () => {
    setLoading(true);
    apiService.getSchedules()
      .then(res => setSchedules(res.schedules))
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchSchedules();
  }, []);

  const handleTriggerSync = async () => {
    setSyncing(true);
    setSyncSuccessMessage(null);
    try {
      const res = await apiService.triggerScheduleSync('SAP PM Gateway Ferroviário v2');
      setSyncSuccessMessage(`Sincronização com SAP PM concluída com sucesso! 1 nova ordem de manutenção preventiva injetada e CCO notificado.`);
      fetchSchedules();
    } catch (err: any) {
      setSyncSuccessMessage('Erro ao sincronizar com sistema externo.');
    } finally {
      setSyncing(false);
    }
  };

  const handleCopyToken = () => {
    navigator.clipboard.writeText('ferro_api_token_live_994021a8d07e1c8b93');
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const handleRunSandbox = async () => {
    setSandboxLoading(true);
    setSandboxResponse(null);
    try {
      if (sandboxMethod === 'GET') {
        const res = await fetch(sandboxEndpoint);
        const json = await res.json();
        setSandboxResponse(JSON.stringify(json, null, 2));
      } else {
        const parsed = JSON.parse(sandboxPayload);
        const res = await fetch(sandboxEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ferro_api_token_live_994021a8d07e1c8b93',
          },
          body: JSON.stringify(parsed),
        });
        const json = await res.json();
        setSandboxResponse(JSON.stringify(json, null, 2));
        fetchSchedules();
      }
    } catch (err: any) {
      setSandboxResponse(JSON.stringify({ error: err.message }, null, 2));
    } finally {
      setSandboxLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header & Connected Integrations */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Integração API com Sistemas de Agendamento & Manutenção Preventiva
              </h2>
              <p className="text-xs text-slate-400">
                Sincronização bidirecional em tempo real com SAP PM, IBM Maximo e ERPs ferroviários
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-sync-schedules-now"
            onClick={handleTriggerSync}
            disabled={syncing}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
            <span>{syncing ? 'Sincronizando...' : 'Disparar Sincronização API Agora'}</span>
          </button>
        </div>
      </div>

      {/* Sync Success Alert Message */}
      {syncSuccessMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{syncSuccessMessage}</span>
          </div>
          <button
            onClick={() => setSyncSuccessMessage(null)}
            className="text-emerald-400 hover:text-white text-xs underline"
          >
            Dispensar
          </button>
        </div>
      )}

      {/* Active Connectors Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="font-bold text-xs text-white flex items-center gap-1.5">
              <Database className="w-4 h-4 text-amber-400" />
              SAP PM Gateway v2
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Conectado &bull; 200 OK
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Sincronização de ordens preventivas de locomotivas e vagões minerários.
          </p>
          <div className="text-[10px] text-slate-500 mt-2">
            Último sync: <strong className="text-slate-300">Hoje às 18:25</strong> &bull; Latência: 42ms
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="font-bold text-xs text-white flex items-center gap-1.5">
              <Building className="w-4 h-4 text-sky-400" />
              IBM Maximo Enterprise
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Webhook Ativo
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Gestão de ativos elétricos, catenárias e trens de passageiros (TUE).
          </p>
          <div className="text-[10px] text-slate-500 mt-2">
            Escuta ativa na rota <code className="text-sky-300">/api/v1/schedules</code>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="font-bold text-xs text-white flex items-center gap-1.5">
              <Code className="w-4 h-4 text-emerald-400" />
              RailOps REST API
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Pronto
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Integração com sistemas legados e coletores Zebra em campo.
          </p>
          <div className="text-[10px] text-slate-500 mt-2">
            Token de acesso ativo com escopo de manobrador
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setSelectedTab('schedules')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            selectedTab === 'schedules'
              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Cronograma de Preventivas ({schedules.length})
        </button>

        <button
          onClick={() => setSelectedTab('api_docs')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            selectedTab === 'api_docs'
              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Documentação de Endpoints REST
        </button>

        <button
          onClick={() => setSelectedTab('sandbox')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            selectedTab === 'sandbox'
              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Console de Teste da API (Sandbox)
        </button>
      </div>

      {/* Tab 1: Scheduled Maintenance List */}
      {selectedTab === 'schedules' && (
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">
              Cronograma Sincronizado de Manutenção Preventiva
            </h3>
            <span className="text-xs text-slate-400">
              Vias de oficina: <strong className="text-amber-400">P1 / P2 (Preventiva)</strong> &bull; <strong className="text-sky-400">CR (Corretiva)</strong> &bull; <strong className="text-emerald-400">MC (Macacos)</strong>
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-800/80 text-slate-400 font-semibold uppercase text-[10px] tracking-wider border-b border-slate-700">
                <tr>
                  <th className="p-2.5">Código Ordem</th>
                  <th className="p-2.5">Veículo</th>
                  <th className="p-2.5">Tipo de Preventiva</th>
                  <th className="p-2.5">Data Programada</th>
                  <th className="p-2.5">Oficina / Via</th>
                  <th className="p-2.5">Sistema Origem</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {schedules.map((sch) => {
                  const dateStr = new Date(sch.scheduledDate).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  });
                  return (
                    <tr key={sch.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-2.5 font-mono text-amber-400 font-bold">{sch.externalSystemId}</td>
                      <td className="p-2.5 font-semibold text-white">{sch.vehicleId} &bull; {sch.vehicleName}</td>
                      <td className="p-2.5">
                        <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-200">
                          {sch.type}
                        </span>
                      </td>
                      <td className="p-2.5 font-mono text-slate-300">{dateStr}</td>
                      <td className="p-2.5 font-mono text-amber-300 font-semibold">{sch.assignedWorkshopTrackId}</td>
                      <td className="p-2.5">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-sky-400 border border-slate-700">
                          {sch.systemSource}
                        </span>
                      </td>
                      <td className="p-2.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          sch.status === 'in_progress'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : sch.status === 'completed'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        }`}>
                          {sch.status === 'in_progress' ? 'Em Execução' : sch.status === 'completed' ? 'Concluída' : 'Programada'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: REST API Documentation */}
      {selectedTab === 'api_docs' && (
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <div>
            <h3 className="text-sm font-bold text-white mb-1">
              Especificação da API de Pátio Ferroviário (OpenAPI / REST)
            </h3>
            <p className="text-slate-400">
              Utilize os endpoints abaixo para integrar seu ERP, sistema de manutenção preventiva SAP PM ou telemetria de campo.
            </p>
          </div>

          {/* Authentication Token */}
          <div className="p-3 rounded-lg bg-slate-800/80 border border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-slate-400 font-semibold">Chave de Acesso API (Bearer Token):</span>
              <div className="font-mono text-amber-400 text-xs mt-0.5">
                Bearer ferro_api_token_live_994021a8d07e1c8b93
              </div>
            </div>
            <button
              onClick={handleCopyToken}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-medium cursor-pointer self-start sm:self-auto"
            >
              {copiedToken ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedToken ? 'Copiado!' : 'Copiar Token'}</span>
            </button>
          </div>

          {/* Endpoints List */}
          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-slate-800/60 border border-slate-700 space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-sky-500/20 text-sky-400 border border-sky-500/30">
                  GET
                </span>
                <code className="font-mono text-amber-400 text-xs">/api/v1/yard</code>
              </div>
              <p className="text-slate-300">
                Retorna o status em tempo real de todas as vias do pátio, composições estacionadas e percentual de ocupação.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/60 border border-slate-700 space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  POST
                </span>
                <code className="font-mono text-amber-400 text-xs">/api/v1/movements</code>
              </div>
              <p className="text-slate-300">
                Registra uma movimentação (entrada, manobra interna ou saída) no pátio, atualiza os status das vias, despacha notificações e gera auditoria.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/60 border border-slate-700 space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  POST
                </span>
                <code className="font-mono text-amber-400 text-xs">/api/v1/schedules</code>
              </div>
              <p className="text-slate-300">
                Injeta uma ordem preventiva de sistemas como SAP PM ou IBM Maximo diretamente na fila das oficinas.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/60 border border-slate-700 space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-sky-500/20 text-sky-400 border border-sky-500/30">
                  GET
                </span>
                <code className="font-mono text-amber-400 text-xs">/api/v1/vehicles/:id/passport</code>
              </div>
              <p className="text-slate-300">
                Consulta o histórico completo do veículo, motivo de entrada no pátio e auditoria de manobras.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/60 border border-slate-700 space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-purple-500/20 text-purple-400 border border-purple-500/30">
                  SSE
                </span>
                <code className="font-mono text-amber-400 text-xs">/api/v1/events</code>
              </div>
              <p className="text-slate-300">
                Canal de Server-Sent Events (SSE) para atualização instantânea em tempo real de ocupação e alertas operacionais.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Interactive Sandbox Tester */}
      {selectedTab === 'sandbox' && (
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <div>
            <h3 className="text-sm font-bold text-white mb-1">
              Console de Teste Interativo da API (Live Sandbox)
            </h3>
            <p className="text-slate-400">
              Simule chamadas REST como se fossem feitas pelo SAP PM ou por coletores Android de campo.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={sandboxMethod}
              onChange={(e) => setSandboxMethod(e.target.value as any)}
              className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-amber-400 font-bold font-mono focus:outline-none"
            >
              <option value="POST">POST</option>
              <option value="GET">GET</option>
            </select>

            <select
              value={sandboxEndpoint}
              onChange={(e) => setSandboxEndpoint(e.target.value)}
              className="flex-1 p-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono focus:outline-none"
            >
              <option value="/api/v1/schedules">/api/v1/schedules (Injetar Ordem Preventiva SAP)</option>
              <option value="/api/v1/yard">/api/v1/yard (Consultar Status de Ocupação)</option>
              <option value="/api/v1/movements">/api/v1/movements (Listar Movimentações)</option>
              <option value="/api/v1/reports/daily">/api/v1/reports/daily (Gerar RDO)</option>
            </select>

            <button
              onClick={handleRunSandbox}
              disabled={sandboxLoading}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{sandboxLoading ? 'Executando...' : 'Executar Chamada'}</span>
            </button>
          </div>

          {sandboxMethod === 'POST' && (
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Payload JSON:</label>
              <textarea
                rows={8}
                value={sandboxPayload}
                onChange={(e) => setSandboxPayload(e.target.value)}
                className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-emerald-400 font-mono text-xs focus:outline-none focus:border-amber-500"
              />
            </div>
          )}

          {sandboxResponse && (
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Resposta do Servidor (JSON 200 OK):</label>
              <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-amber-300 font-mono text-xs overflow-x-auto max-h-64">
                {sandboxResponse}
              </pre>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
