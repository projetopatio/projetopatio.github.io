import React, { useState, useEffect } from 'react';
import { 
  NotificationRule, 
  UserProfile, 
  NotificationEventType, 
  YardTrack 
} from '../types';
import { apiService } from '../services/apiService';
import { 
  Bell, 
  AlertTriangle, 
  Smartphone, 
  Mail, 
  MessageSquare, 
  Plus, 
  Trash2, 
  Play, 
  Sliders, 
  Sparkles,
  Check,
  ShieldAlert,
  Power
} from 'lucide-react';

interface NotificationCenterViewProps {
  currentUser: UserProfile;
  tracks: YardTrack[];
  onOpenVehiclePassport?: (vehicleId: string) => void;
  onRefreshYard?: () => void;
}

export const NotificationCenterView: React.FC<NotificationCenterViewProps> = ({
  currentUser,
  tracks,
  onOpenVehiclePassport,
  onRefreshYard,
}) => {
  const [rules, setRules] = useState<NotificationRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreatingRule, setIsCreatingRule] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  // New Rule Form State
  const [newRuleName, setNewRuleName] = useState('');
  const [newRuleDesc, setNewRuleDesc] = useState('');
  const [newRuleEventType, setNewRuleEventType] = useState<NotificationEventType>('cargo_arrival');
  const [newRuleCargoFilter, setNewRuleCargoFilter] = useState('Linha 11 - Coral (Pico)');
  const [newRuleThreshold, setNewRuleThreshold] = useState(80);
  const [newRuleZone, setNewRuleZone] = useState('Todas as Zonas');
  const [newRuleDwellHours, setNewRuleDwellHours] = useState(24);
  const [channelPush, setChannelPush] = useState(true);
  const [channelEmail, setChannelEmail] = useState(true);
  const [channelSms, setChannelSms] = useState(false);
  const [recipientEmails, setRecipientEmails] = useState('cco.operacoes@ferropatio.com.br');
  const [recipientPhones, setRecipientPhones] = useState('+55 11 98888-7711');

  useEffect(() => {
    loadData();

    const unsubRules = apiService.subscribe('rules_updated', (data) => {
      if (data.rules) setRules(data.rules);
    });

    return () => {
      unsubRules();
    };
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const rulesData = await apiService.getRules();
      setRules(rulesData.rules || []);
    } catch (err) {
      console.error('Erro ao carregar notificações e regras:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleRule = async (rule: NotificationRule) => {
    try {
      const updated = await apiService.updateRule(rule.id, { isActive: !rule.isActive });
      if (updated.rule) {
        setRules(prev => prev.map(r => r.id === rule.id ? updated.rule : r));
      }
    } catch (err) {
      console.error('Falha ao alternar regra:', err);
    }
  };

  const handleDeleteRule = async (ruleId: string) => {
    if (!confirm('Deseja realmente excluir esta regra de notificação?')) return;
    try {
      await apiService.deleteRule(ruleId);
      setRules(prev => prev.filter(r => r.id !== ruleId));
    } catch (err) {
      console.error('Falha ao excluir regra:', err);
    }
  };

  const handleTestTrigger = async (ruleId: string) => {
    try {
      setTestResult('Disparando alerta de teste pelos canais configurados...');
      const res = await apiService.triggerTestRule(ruleId);
      setTestResult(res.message || 'Alerta de teste enviado com sucesso!');
      await loadData();
      if (onRefreshYard) onRefreshYard();
      setTimeout(() => setTestResult(null), 5000);
    } catch (err: any) {
      setTestResult(`Erro: ${err.message}`);
      setTimeout(() => setTestResult(null), 5000);
    }
  };

  const handleCreateRuleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleName.trim()) return;

    try {
      const created = await apiService.createRule({
        name: newRuleName,
        description: newRuleDesc || `Alerta automático para ${newRuleEventType}`,
        eventType: newRuleEventType,
        criteria: {
          cargoTypeFilter: newRuleEventType === 'cargo_arrival' ? newRuleCargoFilter : undefined,
          occupancyThresholdPct: newRuleEventType === 'zone_occupancy' ? Number(newRuleThreshold) : undefined,
          zoneFilter: newRuleEventType === 'zone_occupancy' ? newRuleZone : undefined,
          maxDwellHours: newRuleEventType === 'dwell_time_exceeded' ? Number(newRuleDwellHours) : undefined,
        },
        channels: {
          pushApp: channelPush,
          email: channelEmail,
          sms: channelSms,
        },
        recipients: {
          roles: ['cco_dispatcher', 'yard_operator'],
          emails: recipientEmails,
          phones: recipientPhones,
        },
        isActive: true,
      });

      if (created.rule) {
        setRules(prev => [created.rule, ...prev]);
        setIsCreatingRule(false);
        setNewRuleName('');
        setNewRuleDesc('');
      }
    } catch (err: any) {
      setErrorMessage(`Falha ao cadastrar regra: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg">
                <Bell className="w-5 h-5 animate-pulse" />
              </div>
              <h1 className="text-xl font-bold text-white tracking-wide">
                Central de Regras de Notificação & Alertas CCO
              </h1>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Configure regras operacionais de despacho por eventos (cargas perigosas, ocupação acima de 80%, atrasos de permanência)
              e canais de entrega automática (Push no App, Email, SMS).
            </p>
          </div>
        </div>

        {/* Global Feedback Toast */}
        {testResult && (
          <div className="mt-4 p-3 bg-emerald-950/80 border border-emerald-700/50 rounded-lg text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span className="font-medium">{testResult}</span>
          </div>
        )}
        {errorMessage && (
          <div className="mt-4 p-3 bg-rose-950/80 border border-rose-700/50 rounded-lg text-rose-300 text-xs flex items-center justify-between gap-2 animate-fadeIn">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span className="font-medium">{errorMessage}</span>
            </div>
            <button onClick={() => setErrorMessage(null)} className="text-rose-400 hover:text-white text-xs">✕</button>
          </div>
        )}
      </div>

      {/* RULES CONFIGURATION */}
      <div className="space-y-6">
          {/* Action Banner */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900/60 border border-slate-800/80 p-4 rounded-xl">
            <div className="text-xs text-slate-300">
              <span className="font-semibold text-white">Regras Ativas de Disparo: </span>
              {rules.filter(r => r.isActive).length} de {rules.length} regras monitorando o pátio continuamente em segundo plano.
            </div>
            <button
              id="create-new-rule-btn"
              onClick={() => setIsCreatingRule(!isCreatingRule)}
              className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow transition-colors"
            >
              {isCreatingRule ? <Trash2 className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
              {isCreatingRule ? 'Cancelar Cadastro' : 'Nova Regra Personalizada'}
            </button>
          </div>

          {/* New Rule Form */}
          {isCreatingRule && (
            <form onSubmit={handleCreateRuleSubmit} className="bg-slate-900 border border-emerald-500/40 rounded-xl p-5 shadow-2xl space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Sliders className="w-4 h-4 text-emerald-400" />
                  Configurar Nova Regra de Notificação
                </div>
                <span className="text-[11px] text-slate-400">Suporta Push, Email e SMS</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Nome da Regra *</label>
                  <input
                    type="text"
                    required
                    value={newRuleName}
                    onChange={(e) => setNewRuleName(e.target.value)}
                    placeholder="Ex: Alerta de Inserção / Recolhimento TUE Linha 11"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Tipo de Evento Disparador *</label>
                  <select
                    value={newRuleEventType}
                    onChange={(e) => setNewRuleEventType(e.target.value as NotificationEventType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:border-emerald-500 outline-none"
                  >
                    <option value="cargo_arrival">Entrada / Chegada de TUE com Linha ou Serviço Específico</option>
                    <option value="zone_occupancy">Taxa de Ocupação Crítica em Zona / Plataforma (&gt; %)</option>
                    <option value="dwell_time_exceeded">Tempo de Permanência Excedido no Pátio (Dwell Time)</option>
                    <option value="maintenance_due">Vencimento de Manutenção Preventiva (SAP PM)</option>
                    <option value="track_restriction">Tentativa de Manobra em Linha Restrita/Interditada</option>
                  </select>
                </div>
              </div>

              {/* Specific Criteria based on Event Type */}
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-lg space-y-3">
                <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
                  Critérios de Disparo do Evento
                </span>

                {newRuleEventType === 'cargo_arrival' && (
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Filtro de Serviço / Linha / Composição de Passageiros</label>
                    <input
                      type="text"
                      value={newRuleCargoFilter}
                      onChange={(e) => setNewRuleCargoFilter(e.target.value)}
                      placeholder="Ex: Linha 11 - Coral, Linha 7 - Rubi, TUE-8500, Passageiros"
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white outline-none focus:border-emerald-500"
                    />
                  </div>
                )}

                {newRuleEventType === 'zone_occupancy' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Limite Crítico de Ocupação: {newRuleThreshold}%</label>
                      <input
                        type="range"
                        min="50"
                        max="100"
                        step="5"
                        value={newRuleThreshold}
                        onChange={(e) => setNewRuleThreshold(Number(e.target.value))}
                        className="w-full accent-emerald-500 cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Zona Alvo</label>
                      <select
                        value={newRuleZone}
                        onChange={(e) => setNewRuleZone(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white outline-none"
                      >
                        <option value="Todas as Zonas">Todas as Zonas do Pátio</option>
                        <option value="Zona Norte">Zona Norte</option>
                        <option value="Zona Sul">Zona Sul</option>
                        <option value="Zona Carga">Zona Carga (Graneleiros)</option>
                        <option value="Zona Industrial / Tanques">Zona Industrial / Tanques</option>
                        <option value="Oficinas">Oficinas</option>
                      </select>
                    </div>
                  </div>
                )}

                {newRuleEventType === 'dwell_time_exceeded' && (
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Tempo Máximo de Permanência (Horas): {newRuleDwellHours}h</label>
                    <input
                      type="number"
                      min="1"
                      max="72"
                      value={newRuleDwellHours}
                      onChange={(e) => setNewRuleDwellHours(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white outline-none"
                    />
                  </div>
                )}
              </div>

              {/* Channels Configuration */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-2">
                  Canais de Envio Desejados (Usuário pode escolher quais ativar):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    channelPush ? 'bg-emerald-950/40 border-emerald-500/60 text-white' : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={channelPush}
                      onChange={(e) => setChannelPush(e.target.checked)}
                      className="rounded accent-emerald-500"
                    />
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-medium">Push no App</span>
                  </label>

                  <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    channelEmail ? 'bg-sky-950/40 border-sky-500/60 text-white' : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={channelEmail}
                      onChange={(e) => setChannelEmail(e.target.checked)}
                      className="rounded accent-sky-500"
                    />
                    <Mail className="w-4 h-4 text-sky-400" />
                    <span className="text-xs font-medium">Email da Central</span>
                  </label>

                  <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    channelSms ? 'bg-amber-950/40 border-amber-500/60 text-white' : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={channelSms}
                      onChange={(e) => setChannelSms(e.target.checked)}
                      className="rounded accent-amber-500"
                    />
                    <MessageSquare className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-medium">SMS para Operadores</span>
                  </label>
                </div>
              </div>

              {/* Recipient Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {channelEmail && (
                  <div>
                    <label className="block text-slate-400 mb-1">Emails dos Destinatários</label>
                    <input
                      type="text"
                      value={recipientEmails}
                      onChange={(e) => setRecipientEmails(e.target.value)}
                      placeholder="separados por vírgula"
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white outline-none focus:border-sky-500"
                    />
                  </div>
                )}
                {channelSms && (
                  <div>
                    <label className="block text-slate-400 mb-1">Telefones SMS</label>
                    <input
                      type="text"
                      value={recipientPhones}
                      onChange={(e) => setRecipientPhones(e.target.value)}
                      placeholder="+55 11 98888-7711, +55 11 99911-0022"
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white outline-none focus:border-amber-500"
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreatingRule(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg font-medium transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-md transition-colors flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  Salvar Regra de Notificação
                </button>
              </div>
            </form>
          )}

          {/* Rules List Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {rules.map((rule) => (
              <div
                key={rule.id}
                className={`bg-slate-900 border rounded-xl p-5 shadow-lg flex flex-col justify-between transition-all ${
                  rule.isActive
                    ? 'border-slate-800 hover:border-slate-700'
                    : 'border-slate-800/50 opacity-60 bg-slate-950/40'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-lg ${
                        rule.eventType === 'cargo_arrival'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : rule.eventType === 'zone_occupancy'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : rule.eventType === 'dwell_time_exceeded'
                          ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      }`}>
                        <ShieldAlert className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white leading-tight">{rule.name}</h3>
                        <span className="text-[11px] font-mono text-slate-400">{rule.id} &bull; {rule.eventType}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleToggleRule(rule)}
                      title={rule.isActive ? 'Desativar Regra' : 'Ativar Regra'}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        rule.isActive
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                          : 'bg-slate-800 border-slate-700 text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      <Power className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                    {rule.description}
                  </p>

                  {/* Criteria Badge */}
                  <div className="mt-3 p-2 bg-slate-950/80 rounded-lg border border-slate-800 text-[11px] text-slate-300 space-y-1">
                    {rule.criteria.cargoTypeFilter && (
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-500">Filtro de Carga:</span>
                        <span className="font-semibold text-amber-300">{rule.criteria.cargoTypeFilter}</span>
                      </div>
                    )}
                    {rule.criteria.occupancyThresholdPct && (
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-500">Gatilho de Ocupação:</span>
                        <span className="font-semibold text-rose-300">&gt; {rule.criteria.occupancyThresholdPct}% na {rule.criteria.zoneFilter || 'Via'}</span>
                      </div>
                    )}
                    {rule.criteria.maxDwellHours && (
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-500">Tempo Máximo de Pátio:</span>
                        <span className="font-semibold text-indigo-300">&gt; {rule.criteria.maxDwellHours} horas</span>
                      </div>
                    )}
                  </div>

                  {/* Active Channels */}
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Canais:</span>
                    {rule.channels.pushApp && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        <Smartphone className="w-3 h-3" /> App Push
                      </span>
                    )}
                    {rule.channels.email && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium bg-sky-500/10 text-sky-300 border border-sky-500/20">
                        <Mail className="w-3 h-3" /> Email
                      </span>
                    )}
                    {rule.channels.sms && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium bg-amber-500/10 text-amber-300 border border-amber-500/20">
                        <MessageSquare className="w-3 h-3" /> SMS
                      </span>
                    )}
                  </div>
                </div>

                {/* Footer with stats & trigger test */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <div>
                    <span>Disparos: <strong className="text-white">{rule.triggerCount}</strong></span>
                    {rule.lastTriggeredAt && (
                      <span className="ml-2 text-slate-400">&bull; Último: {new Date(rule.lastTriggeredAt).toLocaleTimeString('pt-BR')}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      id={`test-rule-btn-${rule.id}`}
                      onClick={() => handleTestTrigger(rule.id)}
                      className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-300 rounded font-medium transition-colors"
                      title="Simular disparo imediato deste alerta através de Push, Email e SMS"
                    >
                      <Play className="w-3 h-3 text-emerald-400" />
                      Testar Disparo
                    </button>
                    <button
                      onClick={() => handleDeleteRule(rule.id)}
                      className="p-1 hover:text-rose-400 text-slate-400 transition-colors"
                      title="Excluir Regra"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };
