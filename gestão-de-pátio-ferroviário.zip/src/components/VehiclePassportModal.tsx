import React, { useEffect, useState } from 'react';
import { TrainVehicle, YardTrack, MovementRecord, MaintenanceSchedule, UserProfile, ActiveManobradorState } from '../types';
import { apiService, VehiclePassportResponse } from '../services/apiService';
import { canSetOperacional, canSetManutencao, canSetPreparadoComercial, checkManeuverPermission } from '../utils/rbac';
import { getTrainTheme, NormalizedTrainStatus } from '../utils/trainStatus';
import { 
  Train, 
  X, 
  Clock, 
  Calendar, 
  Wrench, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  User, 
  FileText, 
  ShieldCheck, 
  CornerDownRight, 
  MapPin, 
  Tag,
  Shield,
  Activity,
  Sparkles,
  LogOut,
  Send,
  Smartphone
} from 'lucide-react';

interface VehiclePassportModalProps {
  vehicle: TrainVehicle | null;
  isOpen: boolean;
  currentUser: UserProfile;
  activeManobrador?: ActiveManobradorState | null;
  tracks?: YardTrack[];
  onClose: () => void;
  onMoveVehicle: (vehicleId: string) => void;
  onExitVehicle?: (vehicleId: string) => void;
  onStatusUpdated?: (vehicleId: string, newStatus: string) => void;
}

export const VehiclePassportModal: React.FC<VehiclePassportModalProps> = ({
  vehicle,
  isOpen,
  currentUser,
  activeManobrador,
  tracks,
  onClose,
  onMoveVehicle,
  onExitVehicle,
  onStatusUpdated,
}) => {
  const [data, setData] = useState<VehiclePassportResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusUpdating, setStatusUpdating] = useState(false);
  const [statusSuccessMsg, setStatusSuccessMsg] = useState<string | null>(null);
  const [statusErrorMsg, setStatusErrorMsg] = useState<string | null>(null);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'status'>('overview');

  useEffect(() => {
    setActiveTab('overview');
    setShowExitConfirm(false);
    setIsExiting(false);
  }, [vehicle, isOpen]);

  const [isTogglingPhone, setIsTogglingPhone] = useState(false);

  const handleToggleOperationalPhone = async () => {
    const currentV = data?.vehicle || vehicle;
    if (!currentV) return;
    try {
      setIsTogglingPhone(true);
      const res = await apiService.toggleVehicleOperationalPhone(currentV.id, {
        hasOperationalPhone: !currentV.hasOperationalPhone,
        user: currentUser,
      });
      currentV.hasOperationalPhone = res.hasOperationalPhone;
      setData(prev => prev ? {
        ...prev,
        vehicle: {
          ...prev.vehicle,
          hasOperationalPhone: res.hasOperationalPhone,
        }
      } : null);
      if (vehicle) {
        vehicle.hasOperationalPhone = res.hasOperationalPhone;
      }
      if (onStatusUpdated) {
        onStatusUpdated(currentV.id, currentV.status);
      }
    } catch (err: any) {
      setStatusErrorMsg(`Erro ao atualizar celular operacional: ${err.message}`);
    } finally {
      setIsTogglingPhone(false);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onClose]);

  const activeVehicle = data?.vehicle || vehicle;
  const trainTheme = getTrainTheme(activeVehicle);

  const isCurrentInMaintenance = 
    trainTheme.id === 'em_manutencao' || 
    activeVehicle?.status === 'in_maintenance' || 
    activeVehicle?.maintenanceStatus === 'in_progress';
  const isTecnicoMRO = currentUser.role === 'tecnico_mro' || currentUser.role === 'maintenance_tech';

  // Se a composição estiver com status em manutenção, SOMENTE o Técnico MRO pode alterar!
  const allowedToSetOperacional = isCurrentInMaintenance ? isTecnicoMRO : canSetOperacional(currentUser.role);
  const allowedToSetManutencao = isCurrentInMaintenance ? isTecnicoMRO : canSetManutencao(currentUser.role);
  const allowedToSetPreparadoComercial = isCurrentInMaintenance ? isTecnicoMRO : canSetPreparadoComercial(currentUser.role);

  const handleUpdateStatus = async (targetStatus: 'operacional' | 'em_manutencao' | 'preparado_comercial') => {
    if (!vehicle) return;
    setStatusUpdating(true);
    setStatusSuccessMsg(null);
    setStatusErrorMsg(null);

    if (isCurrentInMaintenance && !isTecnicoMRO) {
      setStatusErrorMsg('Composição em manutenção: somente o Técnico MRO possui autorização para alterar o status deste trem.');
      setStatusUpdating(false);
      return;
    }

    try {
      const res = await apiService.updateVehicleStatus(vehicle.id, targetStatus, currentUser);
      setStatusSuccessMsg(`Status atualizado com sucesso para "${res.statusLabel}"`);
      if (onStatusUpdated) {
        onStatusUpdated(vehicle.id, targetStatus);
      }
      // Update local vehicle state in passport
      const newStatus = targetStatus === 'em_manutencao' 
        ? 'in_maintenance' 
        : targetStatus === 'preparado_comercial' 
          ? 'ready_for_dispatch' 
          : 'active';
      const newMaint = targetStatus === 'em_manutencao' ? 'in_progress' : 'up_to_date';

      setData(prev => prev ? {
        ...prev,
        vehicle: {
          ...prev.vehicle,
          status: newStatus,
          maintenanceStatus: newMaint
        }
      } : null);
    } catch (err: any) {
      setStatusErrorMsg(err.message || 'Falha ao atualizar status');
    } finally {
      setStatusUpdating(false);
    }
  };

  useEffect(() => {
    if (vehicle && isOpen) {
      setLoading(true);
      apiService.getVehiclePassport(vehicle.id)
        .then((res) => setData(res))
        .catch(() => {
          // fallback to client vehicle data
          setData({
            vehicle,
            currentTrack: null,
            movementsCount: 1,
            history: [],
            schedules: [],
            dwellTimeHours: vehicle.dwellTimeHours || 12,
          });
        })
        .finally(() => setLoading(false));
    }
  }, [vehicle, isOpen]);

  const isVehicleInTF = Boolean(
    data?.currentTrack?.code === 'TF' || 
    data?.currentTrack?.id === 'VIA-TF' ||
    vehicle?.currentTrackId === 'VIA-TF' ||
    (tracks && vehicle?.currentTrackId ? tracks.find(t => t.id === vehicle.currentTrackId)?.code === 'TF' : false)
  );

  const handleDirectExit = async () => {
    if (!vehicle) return;
    const perm = checkManeuverPermission(currentUser, activeManobrador || null);
    if (!perm.allowed) {
      setStatusErrorMsg(perm.reason || 'Manobra bloqueada: Você não possui a função de Manobrador ativa.');
      setShowExitConfirm(false);
      return;
    }

    setIsExiting(true);
    setStatusErrorMsg(null);
    try {
      await apiService.registerMovement({
        vehicleId: vehicle.id,
        type: 'exit',
        reason: 'Despacho Comercial / Saída do Pátio',
        sourceTrackId: vehicle.currentTrackId || 'VIA-TF',
        targetTrackId: null,
        operatorId: currentUser.id,
        operatorName: currentUser.name,
        operatorRole: currentUser.roleLabel || currentUser.role,
        authorizedByCCO: 'Carlos Menezes (ODT)',
        safetyChecklist: {
          handbrakeApplied: true,
          trackChocksInstalled: true,
          signalingFlagsPlaced: true,
          visualInspectionDone: true,
        },
        notes: `Composição despachada da Via TF para operação comercial externa fora do pátio.`,
      });
      if (onStatusUpdated) {
        onStatusUpdated(vehicle.id, 'ready_for_dispatch');
      }
      onClose();
    } catch (err: any) {
      setStatusErrorMsg(err.message || 'Falha ao registrar saída do pátio.');
      setShowExitConfirm(false);
    } finally {
      setIsExiting(false);
    }
  };

  if (!isOpen || !vehicle) return null;

  const currentTrackId = vehicle.currentTrackId;

  const formatDateTime = (isoString?: string) => {
    if (!isoString) return '--';
    const date = new Date(isoString);
    return date.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-2 sm:p-4 animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        className="w-full max-w-xl max-h-[82vh] sm:max-h-[85vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl text-slate-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between p-3.5 sm:p-4 border-b border-slate-800 shrink-0 bg-slate-900/90">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400 shrink-0">
              <Train className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-1.5">
                <h2 className="text-sm sm:text-base font-bold text-white truncate">{vehicle.id} - {vehicle.name}</h2>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center gap-1 ${trainTheme.badgeBg} ${trainTheme.badgeText} ${trainTheme.badgeBorder}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${trainTheme.dotColor}`} />
                  {trainTheme.label}
                </span>
                {activeVehicle.hasOperationalPhone && (
                  <span 
                    title="Composição com Celular Operacional a Bordo"
                    className="px-2 py-0.5 rounded bg-emerald-500 text-slate-950 font-black font-mono text-[10px] flex items-center gap-1 shadow-sm border border-emerald-300"
                  >
                    <Smartphone className="w-2.5 h-2.5 stroke-[2.5]" />
                    <span>Cel</span>
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                Via: <strong className="text-amber-300 font-mono">{currentTrackId || 'Fora do Pátio'}</strong> &bull; {vehicle.operatorCompany}
              </div>
            </div>
          </div>

          <button
            id="close-passport-modal-btn"
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition flex items-center justify-center cursor-pointer shrink-0 ml-2"
            aria-label="Fechar janela de detalhes"
            title="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-3 sm:px-4 pt-2 border-b border-slate-800 bg-slate-900/60 shrink-0 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`pb-2 px-2.5 sm:px-3 flex items-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === 'overview'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Train className="w-3.5 h-3.5" />
            <span>Visão Geral</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`pb-2 px-2.5 sm:px-3 flex items-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === 'history'
                ? 'border-sky-400 text-sky-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Histórico {data?.history?.length ? `(${data.history.length})` : ''}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('status')}
            className={`pb-2 px-2.5 sm:px-3 flex items-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeTab === 'status'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Alterar Status</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-3.5 sm:p-4 overflow-y-auto flex-1 text-xs">
          {activeTab === 'overview' && (
            <div className="space-y-3">
              {/* Controle e Indicação de Celular Operacional */}
              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 shadow-inner">
                <div className="flex items-center gap-2.5">
                  <div className={`p-2 rounded-lg transition ${activeVehicle.hasOperationalPhone ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400 border border-slate-700'}`}>
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white">Celular Operacional a Bordo</span>
                      {activeVehicle.hasOperationalPhone ? (
                        <span className="px-2 py-0.2 rounded bg-emerald-500 text-slate-950 font-black font-mono text-[10px] shadow-sm flex items-center gap-1 border border-emerald-300">
                          <Smartphone className="w-2.5 h-2.5 stroke-[2.5]" /> Cel Ativo
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 text-[10px] font-semibold border border-slate-700">
                          Não vinculado
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {activeVehicle.hasOperationalPhone
                        ? 'Composição portando celular operacional. A indicação "Cel" é apresentada na parte inferior esquerda no pátio.'
                        : 'Clique no botão ao lado para indicar que esta composição está com celular operacional a bordo.'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleToggleOperationalPhone}
                  disabled={isTogglingPhone}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0 shadow-md ${
                    activeVehicle.hasOperationalPhone
                      ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500 shadow-emerald-600/30'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>
                    {isTogglingPhone 
                      ? 'Atualizando...' 
                      : activeVehicle.hasOperationalPhone 
                        ? 'Remover Celular' 
                        : 'Indicar com Celular (Cel)'}
                  </span>
                </button>
              </div>

              {/* Quick Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700">
                  <span className="text-slate-400 flex items-center gap-1 text-[11px]">
                    <MapPin className="w-3 h-3 text-amber-400" />
                    Via / Posição
                  </span>
                  <div className="font-bold text-xs text-white mt-1 truncate">
                    {currentTrackId || 'Despachado'}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Posição: {vehicle.positionInTrack || 'Cabeça'}
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700">
                  <span className="text-slate-400 flex items-center gap-1 text-[11px]">
                    <Clock className="w-3 h-3 text-sky-400" />
                    Permanência
                  </span>
                  <div className="font-bold text-xs text-white mt-1">
                    {vehicle.dwellTimeHours || 10.5}h
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    Desde: {formatDateTime(vehicle.entryDate).split(' ')[0]}
                  </div>
                </div>
              </div>

              {/* Entry Reason & Operator */}
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-1.5">
                <h4 className="font-bold text-slate-200 text-xs flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  <span>Registro de Entrada no Pátio</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400 text-[11px]">Motivo Oficial:</span>
                    <div className="font-semibold text-amber-300">
                      {vehicle.entryReason}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px]">Registrado Por:</span>
                    <div className="font-semibold text-white">
                      {vehicle.registeredBy || 'Operador de Pátio'}
                    </div>
                  </div>
                </div>
                {vehicle.notes && (
                  <div className="mt-1 pt-1.5 border-t border-slate-700/60 text-slate-300 text-[11px]">
                    <span className="text-slate-400 font-medium">Obs: </span>
                    {vehicle.notes}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-xs flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-sky-400" />
                  <span>Histórico Cronológico de Atividades e Manobras</span>
                </h4>
                <span className="text-slate-400 text-[11px]">
                  {data?.history?.length || 0} registros
                </span>
              </div>

              {loading ? (
                <div className="p-6 text-center text-slate-400">Carregando histórico do veículo...</div>
              ) : data && data.history.length > 0 ? (
                <div className="space-y-2 max-h-[48vh] overflow-y-auto pr-1">
                  {data.history.map((mov) => (
                    <div
                      key={mov.id}
                      className="p-2.5 rounded-lg bg-slate-800/50 border border-slate-800 hover:border-slate-700 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between gap-1">
                        <div className="flex items-center gap-1.5">
                          <span className="px-1.5 py-0.5 rounded font-mono text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                            {mov.id}
                          </span>
                          <span className="font-semibold text-slate-200">
                            {mov.type === 'entry' && 'Entrada no Pátio'}
                            {mov.type === 'shunting' && 'Manobra Interna'}
                            {mov.type === 'maintenance_in' && 'Ida p/ Oficina'}
                            {mov.type === 'maintenance_out' && 'Saída da Oficina'}
                            {mov.type === 'exit' && 'Despacho Comercial'}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 flex items-center gap-1 shrink-0">
                          <Clock className="w-3 h-3 text-slate-500" />
                          {formatDateTime(mov.timestamp)}
                        </span>
                      </div>

                      {/* Route */}
                      <div className="flex items-center gap-1.5 text-slate-300 text-[11px]">
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 font-mono">
                          {mov.sourceTrackName || 'Linha Externa'}
                        </span>
                        <ArrowRight className="w-3 h-3 text-slate-500 shrink-0" />
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-emerald-300 font-mono">
                          {mov.targetTrackName || 'Destino'}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/60 gap-1">
                        <span>Motivo: <strong className="text-slate-200">{mov.reason}</strong></span>
                        <span>Manobrador: <strong className="text-slate-200">{mov.operatorName}</strong></span>
                        {mov.authorizedByCCO && (
                          <span>ODT: <strong className="text-amber-300">{mov.authorizedByCCO}</strong></span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 rounded-lg bg-slate-800/20 border border-slate-800 text-center text-slate-400">
                  Nenhum histórico anterior registrado para este veículo.
                </div>
              )}
            </div>
          )}

          {activeTab === 'status' && (
            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-200 text-xs flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-amber-400" />
                  <span>Alteração de Status Operacional (RBAC)</span>
                </h4>
                <span className="text-[10px] text-slate-400">
                  <strong className="text-white">{currentUser.name}</strong> ({currentUser.roleLabel || currentUser.role})
                </span>
              </div>

              {statusSuccessMsg && (
                <div className="p-2 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{statusSuccessMsg}</span>
                </div>
              )}
              {statusErrorMsg && (
                <div className="p-2 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{statusErrorMsg}</span>
                </div>
              )}

              {isCurrentInMaintenance && !isTecnicoMRO && (
                <div className="p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <Shield className="w-4 h-4 shrink-0 text-rose-400" />
                  <div>
                    <span className="font-bold text-white block">Acesso Restrito: Composição em Manutenção</span>
                    <span className="text-[11px] text-rose-200">
                      Somente o <strong>Técnico MRO</strong> tem permissão para alterar o status desta composição.
                    </span>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 gap-2 pt-1">
                {/* Option 1: Set to OPERACIONAL (Azul) */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-700/60 gap-2">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-sky-400"></span>
                      <span className="text-xs font-bold text-sky-400">Azul: Operacional</span>
                      {trainTheme.id === 'operacional' && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/50">
                          STATUS ATUAL
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400">Técnico MRO e Supervisor CCO</p>
                  </div>
                  <button
                    type="button"
                    disabled={statusUpdating || !allowedToSetOperacional}
                    onClick={() => handleUpdateStatus('operacional')}
                    className={`py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center gap-1 border shrink-0 ${
                      allowedToSetOperacional
                        ? trainTheme.id === 'operacional'
                          ? 'bg-sky-600 text-white border-sky-300 cursor-default'
                          : 'bg-sky-700 hover:bg-sky-600 text-white border-sky-400 cursor-pointer shadow'
                        : 'bg-slate-800/40 text-slate-500 border-slate-700/60 cursor-not-allowed opacity-50'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Definir</span>
                  </button>
                </div>

                {/* Option 2: Set to EM MANUTENÇÃO (Vermelho) */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-700/60 gap-2">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                      <span className="text-xs font-bold text-rose-400">Vermelho: Manutenção</span>
                      {trainTheme.id === 'em_manutencao' && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/50">
                          STATUS ATUAL
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400">Controlador CCO e Supervisor CCO</p>
                  </div>
                  <button
                    type="button"
                    disabled={statusUpdating || !allowedToSetManutencao}
                    onClick={() => handleUpdateStatus('em_manutencao')}
                    className={`py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center gap-1 border shrink-0 ${
                      allowedToSetManutencao
                        ? trainTheme.id === 'em_manutencao'
                          ? 'bg-rose-600 text-white border-rose-300 cursor-default'
                          : 'bg-rose-700 hover:bg-rose-600 text-white border-rose-400 cursor-pointer shadow'
                        : 'bg-slate-800/40 text-slate-500 border-slate-700/60 cursor-not-allowed opacity-50'
                    }`}
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Definir</span>
                  </button>
                </div>

                {/* Option 3: Set to PREPARADO PARA O COMERCIAL (Verde) */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-700/60 gap-2">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span className="text-xs font-bold text-emerald-400">Verde: Prep. Comercial</span>
                      {trainTheme.id === 'preparado_comercial' && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/50">
                          STATUS ATUAL
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400">Controlador CCO e Supervisor CCO</p>
                  </div>
                  <button
                    type="button"
                    disabled={statusUpdating || !allowedToSetPreparadoComercial}
                    onClick={() => handleUpdateStatus('preparado_comercial')}
                    className={`py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center gap-1 border shrink-0 ${
                      allowedToSetPreparadoComercial
                        ? trainTheme.id === 'preparado_comercial'
                          ? 'bg-emerald-600 text-white border-emerald-300 cursor-default'
                          : 'bg-emerald-700 hover:bg-emerald-600 text-white border-emerald-400 cursor-pointer shadow'
                        : 'bg-slate-800/40 text-slate-500 border-slate-700/60 cursor-not-allowed opacity-50'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Definir</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-3 sm:p-4 border-t border-slate-800 shrink-0 bg-slate-900 flex flex-col gap-2.5">
          {showExitConfirm && (
            <div className="p-3 bg-slate-950 border border-rose-600/70 rounded-xl space-y-2.5 animate-in fade-in text-xs">
              <div className="flex items-center justify-between gap-2 border-b border-rose-900/40 pb-2">
                <div className="flex items-center gap-2 text-rose-200">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <div>
                    <div className="font-bold text-xs text-rose-100">
                      Confirmar Despacho Comercial da Composição {vehicle.id}
                    </div>
                    <p className="text-[10px] text-rose-300">
                      Retirada da Via TF e inserção em operação comercial na malha do VLT Carioca.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0 justify-end pt-1">
                <button
                  type="button"
                  onClick={() => setShowExitConfirm(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer transition"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleDirectExit}
                  disabled={isExiting}
                  className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{isExiting ? 'Despachando...' : 'Confirmar Saída & Despachar'}</span>
                </button>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between gap-2">
            <button
              id="footer-close-passport-btn"
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs sm:text-sm transition cursor-pointer border border-slate-700/80 shadow-sm"
            >
              Fechar
            </button>
            
            <div className="flex items-center gap-2">
              {isVehicleInTF && (
                <button
                  id="exit-yard-tf-btn"
                  type="button"
                  onClick={() => setShowExitConfirm(true)}
                  className="px-3.5 sm:px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-rose-600/30 transition flex items-center gap-1.5 cursor-pointer"
                  title="Tirar a composição da Via TF e despachar para fora do pátio"
                >
                  <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span>Sair do Pátio</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onMoveVehicle(vehicle.id);
                }}
                className="px-3.5 sm:px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-amber-500/20 transition flex items-center gap-1.5 cursor-pointer"
              >
                <CornerDownRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span>Manobrar Veículo</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
