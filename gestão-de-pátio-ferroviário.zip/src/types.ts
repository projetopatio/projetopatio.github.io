export type VehicleType = 
  | 'train_passenger'
  | 'locomotive_electric'
  | 'locomotive_diesel'
  | 'maintenance_vehicle';

export type MovementType = 'entry' | 'shunting' | 'exit' | 'maintenance_in' | 'maintenance_out' | 'stabling';

export type MovementReason =
  | 'Higienização'
  | 'Revisão de Ar'
  | 'Manutenção Preventiva'
  | 'Manutenção Corretiva'
  | 'Inspeção de Truque'
  | 'Inserção em Carrossel Comercial (Pico)'
  | 'Recolhimento Após Horário de Pico'
  | 'Estacionamento / Aguardando Escala'
  | 'Higienização e Limpeza de Salão'
  | 'Revisão de Ar-Condicionado & Portas'
  | 'Inspeção Diária de Truques e Freios'
  | 'Manutenção Preventiva Periódica'
  | 'Manutenção Corretiva (Falha Técnica)'
  | 'Reserva Técnica Operacional CCO'
  | 'Despacho para Linha Tronco'
  | string;

export type TrackStatus = 'available' | 'moderate' | 'high' | 'critical' | 'interdicted';

export type TrackCategory = 'main' | 'stabling' | 'platform' | 'maintenance' | 'inspection_wash' | 'dead_end' | 'workshop';

// Vaga / Spot status for individual parking spots in the yard
export type YardSpotStatus = 'free' | 'occupied' | 'maintenance' | 'restricted';

export interface YardSpot {
  id: string; // e.g. "VIA-01-V01"
  spotNumber: number; // 1, 2, 3, 4
  trackId: string;
  trackCode: string;
  trackName: string;
  status: YardSpotStatus;
  restrictionReason?: string; // e.g. "Gabarito elétrico desligado", "Interdição preventiva", "Manutenção de rede aérea"
  vehicleId?: string | null;
  lengthMeters: number;
  positionLetter?: 'A' | 'B' | 'C' | string; // Posição A (Fim de Via), B (Intermediária), C (Entrada)
  positionName?: string; // e.g. "Posição A (Fim de Via)"
  priority?: number; // 1: Fim de Via (Prioridade máxima), 2: Posição B, 3: Posição C
  isEndOfTrack?: boolean; // true if this spot is at the dead-end/buffer stop
}

export type TrainOperationalStatus = 
  | 'operacional' 
  | 'em_manutencao' 
  | 'preparado_comercial' 
  | 'active' 
  | 'in_maintenance' 
  | 'stabled' 
  | 'ready_for_dispatch' 
  | 'interdicted';

export interface TrainVehicle {
  id: string; // e.g. "TUE-8501"
  name: string;
  type: VehicleType;
  operatorCompany: string; // e.g. "Metrô CCO", "CPTM / ViaMobilidade", "SuperVia", "Trem Metropolitano"
  model: string; // e.g. "Alstom Metropolis Série 8500 (8 Carros)", "CAF Série 9000", "Rotem Série 9500"
  lengthMeters: number; // e.g. 170m para TUE 8 carros
  weightTons: number;
  currentTrackId: string | null; // null if departed
  currentSpotId?: string | null;
  positionInTrack?: 'head' | 'middle' | 'tail';
  status: TrainOperationalStatus;
  
  imageUrl?: string;
  compositionNumber?: number;
  // Passenger train service specifications
  cargoType: string; // "Passageiros (8 Carros Climatizados)" - preserved for backward compatibility
  passengerService?: string; // e.g. "Linha 11 - Coral (Expresso Comercial)"
  passengerCapacity?: number; // e.g. 2040 passageiros
  carCount?: number; // e.g. 8 carros ou 4 carros
  destination: string; // e.g. "Terminal Estação da Luz", "Estação Estudantes", "Estação Barra Funda"
  estimatedDwellTimeHours: number; // e.g. 3.5
  departureEta: string; // Estimated Departure Time ISO string

  // Linha e Destino para Despacho da Composição (VLT Carioca)
  designatedLine?: string; // ex: "Linha 1 - Azul (Santos Dumont • Terminal Gentileza)"
  designatedDestination?: string; // ex: "Terminal Gentileza"

  // Celular Operacional a bordo ("Cel")
  hasOperationalPhone?: boolean; // Se a composição está com celular operacional a bordo
  operationalPhoneNotes?: string; // Identificador / número do celular operacional

  entryDate: string; // ISO date
  lastMovedAt: string; // ISO date
  entryReason: MovementReason;
  registeredBy: string; // Name of operator who registered entry
  preventiveMaintenanceDueDate?: string; // ISO date
  maintenanceStatus?: 'up_to_date' | 'warning' | 'overdue' | 'in_progress';
  dwellTimeHours?: number;
  notes?: string;
}

export interface YardTrack {
  id: string; // e.g. "VIA-01"
  name: string;
  code: string;
  zone: string; // e.g. "Zona Norte", "Zona Sul", "Zona Industrial", "Oficinas"
  category: TrackCategory;
  lengthMeters: number;
  capacityWagons: number;
  gauge: '1.60m (Larga)' | '1.00m (Métrica)' | 'Mista';
  isElectrified: boolean;
  hasInspectionPit: boolean;
  isCovered: boolean;
  status: TrackStatus;
  notes?: string;
  assignedVehicles: string[]; // array of vehicle IDs in track order
  spots: YardSpot[]; // Individual parking spots on this track
  parkingRule?: {
    type: 'end_of_track_first'; // Ocupação prioritária a partir do fim de via
    ruleName: string; // "Ocupação Prioritária de Fim de Via"
    priorityOrder: ('A' | 'B' | 'C')[]; // ['A', 'B', 'C']
    description: string;
  };
}

export interface MovementRecord {
  id: string;
  timestamp: string; // ISO date
  vehicleId: string;
  vehicleName: string;
  vehicleType: VehicleType;
  type: MovementType;
  reason: MovementReason;
  sourceTrackId: string | null;
  targetTrackId: string | null;
  sourceTrackName?: string;
  targetTrackName?: string;
  targetSpotId?: string | null;
  designatedLine?: string; // Linha designada no despacho comercial
  designatedDestination?: string; // Destino designado no despacho comercial
  operatorId: string;
  operatorName: string;
  operatorRole: string;
  authorizedByCCO: string;
  safetyChecklist: {
    handbrakeApplied: boolean;
    trackChocksInstalled: boolean;
    pantographLowered?: boolean;
    signalingFlagsPlaced: boolean;
    visualInspectionDone: boolean;
  };
  notes?: string;
}

export type AlertSeverity = 'info' | 'success' | 'warning' | 'critical';

export type NotificationEventType = 
  | 'cargo_arrival' // Chegada de trem com carga específica (ex: perigosa, química, inflamável)
  | 'zone_occupancy' // Ocupação acima de 80% em uma zona/pátio
  | 'dwell_time_exceeded' // Tempo de permanência excedido (> SLA)
  | 'maintenance_due' // Manutenção preventiva iminente ou vencida
  | 'track_restriction'; // Vaga com restrição ou interdição violada

// Customizable notification rule
export interface NotificationRule {
  id: string;
  name: string;
  description: string;
  eventType: NotificationEventType;
  criteria: {
    cargoTypeFilter?: string; // ex: "Diesel", "Inflamável", "Química", "Qualquer Carga", "Passageiros"
    cargoFilter?: string;
    occupancyThresholdPct?: number; // ex: 80
    thresholdPercent?: number;
    zoneFilter?: string; // ex: "Todas as Zonas", "Zona Norte", "Zona Sul", "Oficinas"
    maxDwellHours?: number; // ex: 24
  };
  channels: {
    pushApp: boolean;
    email: boolean;
    sms: boolean;
  };
  recipients: {
    roles: UserRole[];
    emails: string; // comma-separated
    phones: string; // comma-separated
  };
  isActive: boolean;
  triggerCount: number;
  lastTriggeredAt?: string;
}

export interface NotificationAlert {
  id: string;
  timestamp: string;
  title: string;
  message: string;
  severity: AlertSeverity;
  category: 'occupancy' | 'maintenance' | 'movement' | 'safety' | 'api_sync' | 'cargo';
  read: boolean;
  acknowledgedBy?: string;
  relatedVehicleId?: string;
  relatedTrackId?: string;
  relatedSpotId?: string;
  
  // Customizable Notification Channels metadata
  channelsDispatched: {
    push: boolean;
    email: boolean;
    sms: boolean;
  };
  recipientsSummary?: string;

  // Confirmation & acknowledgment history
  confirmed: boolean;
  confirmedAt?: string;
  confirmedBy?: string;
  confirmationNotes?: string;
  ruleId?: string;
}

export interface MaintenanceSchedule {
  id: string;
  vehicleId: string;
  vehicleName: string;
  type: 
    | 'Preventiva Sistemática' 
    | 'Revisão Periódica' 
    | 'Inspeção Lubrificação' 
    | 'Perfilagem de Rodas' 
    | 'Freios e Truques'
    | 'Revisão de Climatização & Portas'
    | 'Inspeção de Pantógrafo & Catenária'
    | 'Higienização & Lavagem Periódica'
    | 'Perfilagem de Rodas & Truques'
    | 'Sistemas Embarcados & Portas'
    | string;
  scheduledDate: string; // ISO
  estimatedDurationHours: number;
  assignedWorkshopTrackId: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'delayed';
  externalSystemId: string; // e.g. "SAP-PM-994021"
  systemSource: 'SAP PM' | 'IBM Maximo' | 'RailOps ERP' | 'Manual';
  technicianInCharge: string;
  description: string;
}

export type UserRole = 
  | 'tecnico_mro' // Técnico MRO
  | 'controlador_cco' // Controlador CCO
  | 'supervisor_cco' // Supervisor de CCO
  | 'admin' // Administrador Geral
  | 'cco_dispatcher' // Despachante CCO (legado)
  | 'yard_operator' // Operador de Pátio (legado)
  | 'maintenance_tech'; // Engenheiro / Técnico de Manutenção (legado)

export interface ActiveManobradorState {
  userId: string;
  userName: string;
  badgeNumber: string;
  role: UserRole;
  roleLabel: string;
  activatedAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  role: UserRole;
  roleLabel: string;
  badgeNumber: string; // Matrícula format "38-00000"
  department: string;
  avatar: string;
  password?: string;
  createdAt?: string;
  createdDevice?: string;
  deviceType?: 'windows' | 'mobile' | 'other';
  lastLoginAt?: string;
  lastLoginDevice?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  entityType: 'movement' | 'track' | 'vehicle' | 'schedule' | 'auth' | 'system' | 'notification';
  entityId: string;
  details: string;
  clientIp?: string;
  device?: string;
}

export interface DailyReportSummary {
  date: string;
  totalMovements: number;
  entries: number;
  exits: number;
  internalShunts: number;
  maintenanceMovements: number;
  averageOccupancyRate: number;
  peakOccupancyRate: number;
  averageDwellTimeHours: number;
  preventiveMaintenancesDone: number;
  criticalAlertsResolved: number;
  busiestTrack: string;
  activeVehiclesInYard: number;
  punctualityRatePercent: number;
}
