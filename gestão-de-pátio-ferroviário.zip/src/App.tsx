import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  YardTrack, 
  TrainVehicle, 
  MovementRecord, 
  MovementType,
  UserProfile, 
  NotificationAlert, 
  AuditLogEntry,
  ActiveManobradorState
} from './types';
import { 
  INITIAL_USERS, 
  INITIAL_TRACKS, 
  INITIAL_VEHICLES, 
  INITIAL_MOVEMENTS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_AUDIT_LOGS 
} from './data/initialData';
import { apiService, YardStatusResponse } from './services/apiService';
import { Header } from './components/Header';
import { YardMap } from './components/YardMap';
import { MovementModal } from './components/MovementModal';
import { VehiclePassportModal } from './components/VehiclePassportModal';
import { DailyReportsView } from './components/DailyReportsView';
import { SchedulesSyncView } from './components/SchedulesSyncView';
import { NotificationCenterView } from './components/NotificationCenterView';
import { AuthModal } from './components/AuthModal';
import { ProfileManagementModal } from './components/ProfileManagementModal';
import { ManobradorModal } from './components/ManobradorModal';
import { StatusNotificationPopups, StatusPopupItem } from './components/StatusNotificationPopups';
import { getStoredSession, setStoredSession, checkManeuverPermission } from './utils/rbac';
import { 
  Train, 
  ShieldCheck, 
  Clock, 
  Calendar, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  Filter, 
  Search, 
  UserCheck, 
  Smartphone, 
  Laptop, 
  RefreshCw,
  Bell,
  Check,
  Edit3,
  X
} from 'lucide-react';

const CONTINUOUS_MEMORY_KEY = 'motiva_yard_continuous_memory_v2';

function getLocalMemory() {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(CONTINUOUS_MEMORY_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && Array.isArray(parsed.vehicles)) {
      parsed.vehicles = parsed.vehicles.map((v: TrainVehicle) => {
        if (v.operatorCompany && v.operatorCompany.includes('Metrô CCO')) {
          return { ...v, operatorCompany: 'VLT Carioca' };
        }
        return v;
      });
    }
    return parsed;
  } catch (e) {
    return null;
  }
}

function saveLocalMemory(t: YardTrack[], v: TrainVehicle[], m: MovementRecord[], a?: AuditLogEntry[], o?: number) {
  if (typeof window === 'undefined') return;
  try {
    const existing = getLocalMemory() || {};
    localStorage.setItem(CONTINUOUS_MEMORY_KEY, JSON.stringify({
      ...existing,
      tracks: t,
      vehicles: v,
      movements: m,
      auditLogs: a !== undefined ? a : (existing.auditLogs || []),
      overallOccupancyPct: o !== undefined ? o : (existing.overallOccupancyPct || 65),
      lastSavedAt: new Date().toISOString(),
    }));
  } catch (e) {
    // Ignore storage quota
  }
}

// Format vaga to via e posicao: VIA-E2-V01 -> via-E2-A, VIA-E2-V02 -> via-E2-B
export function formatSpotToViaPosicao(spotId: string | null | undefined): string {
  if (!spotId) return '';
  return spotId.replace(/-V0?(\d+)$/i, (_, num) => {
    const n = parseInt(num, 10);
    const letter = String.fromCharCode(64 + n);
    return `-${letter}`;
  });
}

export default function App() {
  // State
  const [currentTab, setCurrentTab] = useState<'yard' | 'movements' | 'reports' | 'api' | 'audit' | 'notifications'>('yard');
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => getStoredSession());
  const [activeManobrador, setActiveManobrador] = useState<ActiveManobradorState | null>(null);
  
  const localSaved = useMemo(() => getLocalMemory(), []);
  const [tracks, setTracks] = useState<YardTrack[]>(() => 
    (localSaved?.tracks && localSaved.tracks.length > 0) ? localSaved.tracks : INITIAL_TRACKS
  );
  const [vehicles, setVehicles] = useState<TrainVehicle[]>(() => 
    (localSaved?.vehicles && localSaved.vehicles.length > 0) ? localSaved.vehicles : INITIAL_VEHICLES
  );
  const [movements, setMovements] = useState<MovementRecord[]>(() => 
    (localSaved?.movements && localSaved.movements.length > 0) ? localSaved.movements : INITIAL_MOVEMENTS
  );
  const [notifications, setNotifications] = useState<NotificationAlert[]>(() => 
    (localSaved?.notifications && localSaved.notifications.length > 0) ? localSaved.notifications : INITIAL_NOTIFICATIONS
  );
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => 
    (localSaved?.auditLogs && localSaved.auditLogs.length > 0) ? localSaved.auditLogs : INITIAL_AUDIT_LOGS
  );

  // Cálculo Dinâmico e Reativo da Taxa de Ocupação do Pátio VLT CARIOCA em Tempo Real
  const overallOccupancyPct = useMemo(() => {
    if (!tracks || tracks.length === 0) {
      return localSaved?.overallOccupancyPct || 0;
    }
    const totalCapacity = tracks.reduce((acc, t) => acc + ((t.spots && t.spots.length > 0) ? t.spots.length : (t.capacityWagons || 1)), 0);
    const occupied = tracks.reduce((acc, t) => {
      if (t.spots && t.spots.length > 0) {
        return acc + t.spots.filter(s => s && (s.status === 'occupied' || !!s.vehicleId)).length;
      }
      return acc + (t.assignedVehicles?.length || 0);
    }, 0);
    return totalCapacity > 0 ? Math.round((occupied / totalCapacity) * 100) : 0;
  }, [tracks, localSaved]);

  const [loading, setLoading] = useState(false);

  // Modals state
  const [isMovementModalOpen, setIsMovementModalOpen] = useState(false);
  const [preselectedTrackId, setPreselectedTrackId] = useState<string | null>(null);
  const [preselectedSpotId, setPreselectedSpotId] = useState<string | null>(null);
  const [preselectedMovementType, setPreselectedMovementType] = useState<MovementType | undefined>(undefined);
  const [preselectedVehicleId, setPreselectedVehicleId] = useState<string | null>(null);
  const [forceEntryOnly, setForceEntryOnly] = useState<boolean>(false);
  const [selectedVehicleForPassport, setSelectedVehicleForPassport] = useState<TrainVehicle | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const session = localStorage.getItem('ferropatio_session_user_v2') || localStorage.getItem('ferropatio_session_user');
    return !session;
  });
  const [authModalInitialTab, setAuthModalInitialTab] = useState<'register' | 'login'>('login');
  const [isProfileManagementModalOpen, setIsProfileManagementModalOpen] = useState<boolean>(false);
  
  const handleOpenAuthModal = (tab: 'register' | 'login' = 'login') => {
    setAuthModalInitialTab(tab);
    setIsAuthModalOpen(true);
  };
  const [isManobradorModalOpen, setIsManobradorModalOpen] = useState(false);
  const [isNotificationsDrawerOpen, setIsNotificationsDrawerOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Movement tab filters
  const [movementSearch, setMovementSearch] = useState('');
  const [movementTypeFilter, setMovementTypeFilter] = useState('all');

  // Movement ODT edit state
  const [editingMovementId, setEditingMovementId] = useState<string | null>(null);
  const [editingODTName, setEditingODTName] = useState<string>('');
  const [isSavingODT, setIsSavingODT] = useState<boolean>(false);

  const handleSaveMovementODT = async (movementId: string) => {
    const trimmed = editingODTName.trim();
    if (!trimmed) return;
    setIsSavingODT(true);
    try {
      await apiService.updateMovement(movementId, { authorizedByCCO: trimmed });
      setMovements((prev) => {
        const next = prev.map((m) => m.id === movementId ? { ...m, authorizedByCCO: trimmed } : m);
        saveLocalMemory(tracks, vehicles, next, auditLogs);
        return next;
      });
      setEditingMovementId(null);
      setEditingODTName('');
    } catch (err) {
      console.error('Erro ao atualizar ODT da movimentação:', err);
    } finally {
      setIsSavingODT(false);
    }
  };

  // Web Audio tone generator for operational railway radio beeps
  const playOperationalChime = useCallback((frequency = 880, duration = 0.15) => {
    if (!soundEnabled || typeof window === 'undefined') return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Audio context might be restricted before interaction
    }
  }, [soundEnabled]);

  // Pop-ups de Notificação de Mudança de Status
  // Exclusivo para:
  // - Controlador de CCO: quando status mudar para "OPERACIONAL"
  // - Técnico MRO: quando status mudar para "EM MANUTENÇÃO"
  const [statusPopups, setStatusPopups] = useState<StatusPopupItem[]>([]);
  const recentPopupsRef = useRef<{ [key: string]: number }>({});

  const triggerStatusNotificationPopup = useCallback((vehicle: Partial<TrainVehicle> | undefined, statusString?: string) => {
    if (!vehicle || !vehicle.id || !statusString) return;

    const normalized = statusString.toLowerCase().trim();
    const isOperacional = normalized === 'operacional' || normalized === 'active' || normalized === 'stabled';
    const isManutencao = normalized === 'em_manutencao' || normalized === 'in_maintenance' || normalized.includes('manu');

    if (!isOperacional && !isManutencao) return;

    const targetRole: 'controlador_cco' | 'tecnico_mro' = isOperacional ? 'controlador_cco' : 'tecnico_mro';
    const newStatus: 'operacional' | 'em_manutencao' = isOperacional ? 'operacional' : 'em_manutencao';
    const statusLabel = isOperacional ? 'OPERACIONAL' : 'EM MANUTENÇÃO';

    // Deduplicação: ignora disparos duplicados para o mesmo veículo e status em menos de 4s
    const dedupKey = `${vehicle.id.toLowerCase()}_${newStatus}`;
    const now = Date.now();
    if (recentPopupsRef.current[dedupKey] && now - recentPopupsRef.current[dedupKey] < 4000) {
      return;
    }
    recentPopupsRef.current[dedupKey] = now;

    let trackName: string | undefined;
    if (vehicle.currentTrackId) {
      const track = tracks.find((t) => t.id === vehicle.currentTrackId);
      if (track) trackName = `Linha ${track.code} - ${track.name}`;
    }

    const timeStr = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const newPopup: StatusPopupItem = {
      id: `POPUP-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      vehicleId: vehicle.id,
      vehicleName: vehicle.name || `Composição ${vehicle.compositionNumber || vehicle.id}`,
      compositionNumber: vehicle.compositionNumber,
      newStatus,
      statusLabel,
      targetRole,
      timestamp: timeStr,
      createdAt: now,
      trackName,
    };

    setStatusPopups((prev) => [newPopup, ...prev]);

    if (soundEnabled) {
      if (isOperacional) {
        playOperationalChime(920, 0.25);
      } else {
        playOperationalChime(480, 0.35);
      }
    }
  }, [tracks, soundEnabled, playOperationalChime]);

  const handleDismissStatusPopup = useCallback((id: string) => {
    setStatusPopups((prev) => prev.filter((p) => p.id !== id));
  }, []);

  const handleSelectVehicleFromPopup = useCallback((vehicleId: string) => {
    const v = vehicles.find((item) => item.id.toLowerCase() === vehicleId.toLowerCase());
    if (v) {
      setSelectedVehicleForPassport(v);
    }
  }, [vehicles]);

  // Load Initial Yard Data with Continuous Memory sync
  const loadYardData = useCallback(async () => {
    try {
      const [yardData, movementsData, notifData, auditData, manobradorData] = await Promise.all([
        apiService.getYardStatus(),
        apiService.getMovements(undefined, 100),
        apiService.getNotifications(),
        apiService.getAuditLogs(100),
        apiService.getManobrador().catch(() => ({ activeManobrador: null })),
      ]);

      const localMem = getLocalMemory();
      const serverMovements = movementsData.movements || [];

      // If client has preserved movements from previous sessions and server has fewer (e.g. container cold-reboot),
      // auto-restore continuous memory back to the server
      if (localMem && Array.isArray(localMem.movements) && localMem.movements.length > serverMovements.length) {
        console.log('[Memória Contínua] Restaurando histórico de movimentações preservado no cliente...');
        try {
          await apiService.syncClientState({
            tracks: localMem.tracks,
            vehicles: localMem.vehicles,
            movements: localMem.movements.slice(0, 100),
            auditLogs: localMem.auditLogs ? localMem.auditLogs.slice(0, 50) : [],
          });
        } catch (syncErr) {
          console.warn('Sincronização cliente->servidor:', syncErr);
        }

        const baseVehs = (yardData?.vehicles && yardData.vehicles.length > 0) ? yardData.vehicles : (localMem.vehicles || INITIAL_VEHICLES);
        const mergedVehs = baseVehs.map((sv: TrainVehicle) => {
          const lv = localMem?.vehicles?.find((v: TrainVehicle) => v.id.toLowerCase() === sv.id.toLowerCase());
          return {
            ...sv,
            hasOperationalPhone: sv.hasOperationalPhone || (lv?.hasOperationalPhone ?? false),
            operationalPhoneNotes: sv.operationalPhoneNotes || lv?.operationalPhoneNotes,
          };
        });

        setTracks(localMem.tracks || yardData.tracks);
        setVehicles(mergedVehs);
        setMovements(localMem.movements);
        if (localMem.auditLogs) setAuditLogs(localMem.auditLogs);
      } else {
        const baseVehicles = (yardData?.vehicles && yardData.vehicles.length > 0) 
          ? yardData.vehicles 
          : (localMem?.vehicles && localMem.vehicles.length > 0 ? localMem.vehicles : INITIAL_VEHICLES);

        // Merge phone flags: preserve phone if set either on server or in localStorage!
        const resolvedVehicles = baseVehicles.map((sv: TrainVehicle) => {
          const lv = localMem?.vehicles?.find((v: TrainVehicle) => v.id.toLowerCase() === sv.id.toLowerCase());
          return {
            ...sv,
            hasOperationalPhone: sv.hasOperationalPhone || (lv?.hasOperationalPhone ?? false),
            operationalPhoneNotes: sv.operationalPhoneNotes || lv?.operationalPhoneNotes,
          };
        });

        const resolvedTracks = (yardData?.tracks && yardData.tracks.length > 0) 
          ? yardData.tracks 
          : (localMem?.tracks && localMem.tracks.length > 0 ? localMem.tracks : INITIAL_TRACKS);

        setTracks(resolvedTracks);
        setVehicles(resolvedVehicles);
        setMovements(serverMovements);
        setNotifications(notifData.notifications || INITIAL_NOTIFICATIONS);
        setAuditLogs(auditData.logs || INITIAL_AUDIT_LOGS);

        saveLocalMemory(
          resolvedTracks, 
          resolvedVehicles, 
          serverMovements, 
          auditData.logs || INITIAL_AUDIT_LOGS, 
          yardData?.summary?.overallOccupancyPct || 0
        );
      }

      if (manobradorData?.activeManobrador !== undefined) {
        setActiveManobrador(manobradorData.activeManobrador);
      }
    } catch (err) {
      console.warn('Operando com memória local/offline:', err);
      // Preservação offline / fallback em hospedagem estática
      const fallback = getLocalMemory();
      setTracks(fallback?.tracks && fallback.tracks.length > 0 ? fallback.tracks : INITIAL_TRACKS);
      setVehicles(fallback?.vehicles && fallback.vehicles.length > 0 ? fallback.vehicles : INITIAL_VEHICLES);
      setMovements(fallback?.movements || INITIAL_MOVEMENTS);
      setNotifications(fallback?.notifications || INITIAL_NOTIFICATIONS);
      setAuditLogs(fallback?.auditLogs || INITIAL_AUDIT_LOGS);
    } finally {
      setLoading(false);
    }
  }, []);

  // SSE Real-Time Stream Connection
  useEffect(() => {
    loadYardData();

    // Connect to Server-Sent Events
    apiService.connectSSE();

    const unsubMovement = apiService.subscribe('movement_registered', (data) => {
      if (data.movement) {
        setMovements((prev) => [data.movement, ...prev]);
      }
      if (data.tracks) {
        setTracks(data.tracks);
      }
      if (data.vehicle) {
        setVehicles((prev) => prev.map((v) => (v.id === data.vehicle.id ? data.vehicle : v)));
        if (data.vehicle.status === 'in_maintenance' || data.vehicle.status === 'active') {
          triggerStatusNotificationPopup(data.vehicle, data.vehicle.status);
        }
      }
      if (data.alert) {
        setNotifications((prev) => [data.alert, ...prev]);
        playOperationalChime(1046, 0.2); // high beep
      }
      loadYardData();
    });

    const unsubNotif = apiService.subscribe('new_notification', (data) => {
      if (data.alert) {
        setNotifications((prev) => [data.alert, ...prev]);
        playOperationalChime(784, 0.25);
      }
    });

    const unsubConfirmed = apiService.subscribe('notification_confirmed', (data) => {
      if (data.notif) {
        setNotifications((prev) => prev.map(n => n.id === data.notif.id ? data.notif : n));
      }
      apiService.getAuditLogs(50).then(res => setAuditLogs(res.logs));
    });

    const unsubSpot = apiService.subscribe('spot_updated', (data) => {
      if (data.tracks) {
        setTracks(data.tracks);
      }
      loadYardData();
    });

    const unsubManobrador = apiService.subscribe('manobrador_changed', (data) => {
      setActiveManobrador(data.activeManobrador || null);
      if (data.activeManobrador) {
        playOperationalChime(950, 0.2);
      }
    });

    const unsubStatus = apiService.subscribe('vehicle_status_updated', (data) => {
      if (data.vehicle) {
        setVehicles((prev) => prev.map((v) => (v.id === data.vehicle.id ? data.vehicle : v)));
        setSelectedVehicleForPassport((prev) => (prev?.id === data.vehicle.id ? data.vehicle : prev));
        triggerStatusNotificationPopup(data.vehicle, data.vehicle.status);
      }
      loadYardData();
      playOperationalChime(800, 0.15);
    });

    const unsubVehicle = apiService.subscribe('vehicle_updated', (data) => {
      if (data && data.vehicle) {
        setVehicles((prev) => prev.map((v) => (v.id.toLowerCase() === data.vehicle.id.toLowerCase() ? { ...v, ...data.vehicle } : v)));
        setSelectedVehicleForPassport((prev) => (prev?.id.toLowerCase() === data.vehicle.id.toLowerCase() ? { ...prev, ...data.vehicle } : prev));
        const mem = getLocalMemory();
        if (mem && Array.isArray(mem.vehicles)) {
          const newVehs = mem.vehicles.map((v: TrainVehicle) => v.id.toLowerCase() === data.vehicle.id.toLowerCase() ? { ...v, ...data.vehicle } : v);
          saveLocalMemory(mem.tracks, newVehs, mem.movements, mem.auditLogs);
        }
      }
    });

    const unsubUsers = apiService.subscribe('users_updated', (data) => {
      if (data && data.user && currentUser && data.user.id === currentUser.id) {
        if (data.action === 'deleted') {
          handleOpenAuthModal('login');
        } else {
          setCurrentUser(data.user);
          setStoredSession(data.user);
        }
      }
    });

    const unsubMovementUpdated = apiService.subscribe('movement_updated', (data) => {
      if (data && data.movement) {
        setMovements((prev) => prev.map((m) => m.id === data.movement.id ? { ...m, ...data.movement } : m));
      }
    });

    return () => {
      unsubMovement();
      unsubMovementUpdated();
      unsubNotif();
      unsubConfirmed();
      unsubSpot();
      unsubManobrador();
      unsubStatus();
      unsubVehicle();
      unsubUsers();
    };
  }, [loadYardData, playOperationalChime, currentUser, triggerStatusNotificationPopup]);

  // Handlers for Manobrador exclusivity
  const handleActivateManobrador = async () => {
    const res = await apiService.activateManobrador(currentUser);
    setActiveManobrador(res.activeManobrador);
    playOperationalChime(1050, 0.2);
  };

  const handleReleaseManobrador = async () => {
    const res = await apiService.releaseManobrador(currentUser);
    setActiveManobrador(res.activeManobrador);
    playOperationalChime(600, 0.2);
  };

  // Handle Movement submission from modal
  const handleRegisterMovement = async (movementData: any) => {
    const perm = checkManeuverPermission(currentUser, activeManobrador);
    if (!perm.allowed) {
      throw new Error(perm.reason || 'Manobra bloqueada: Você não possui a função de Manobrador ativa.');
    }

    // Se nenhuma função de manobrador estiver ativa, assume automaticamente pelo usuário
    if (!activeManobrador) {
      try {
        const actRes = await apiService.activateManobrador(currentUser);
        if (actRes?.activeManobrador) {
          setActiveManobrador(actRes.activeManobrador);
        }
      } catch (e) {
        console.warn('Auto-ativação de manobrador:', e);
      }
    }

    const res = await apiService.registerMovement({
      ...movementData,
      operatorId: currentUser.id,
      operatorName: currentUser.name,
      operatorRole: currentUser.roleLabel || currentUser.role,
    });
    if (res?.tracks) {
      setTracks(res.tracks);
    }
    if (res?.vehicle) {
      setVehicles((prev) => prev.map((v) => (v.id === res.vehicle.id ? res.vehicle : v)));
    }
    if (res?.movement) {
      setMovements((prev) => [res.movement, ...prev.filter((m) => m.id !== res.movement.id)]);
    }
    if (res?.alert) {
      setNotifications((prev) => [res.alert!, ...prev]);
    }
    await loadYardData();
    setIsMovementModalOpen(false);
    setPreselectedTrackId(null);
    setPreselectedSpotId(null);
  };

  // Open Movement modal with a specific track preselected
  const handleNewMovementWithTrack = (trackId: string, spotId?: string, forcedType?: MovementType, entryOnly?: boolean) => {
    setPreselectedTrackId(trackId);
    setPreselectedSpotId(spotId || null);
    setPreselectedMovementType(forcedType);
    setForceEntryOnly(!!entryOnly);
    setIsMovementModalOpen(true);
  };

  // Open full vehicle passport
  const handleOpenVehiclePassport = (vehicleIdOrObj: string | TrainVehicle) => {
    if (typeof vehicleIdOrObj === 'string') {
      const found = vehicles.find(v => v.id.toLowerCase() === vehicleIdOrObj.toLowerCase());
      if (found) {
        setSelectedVehicleForPassport(found);
      } else {
        // Fetch on-demand
        apiService.getVehiclePassport(vehicleIdOrObj).then(res => {
          setSelectedVehicleForPassport(res.vehicle);
        });
      }
    } else {
      setSelectedVehicleForPassport(vehicleIdOrObj);
    }
  };

  // Immediate reactive vehicle status update
  const handleVehicleStatusUpdated = useCallback((vehicleId?: string, targetStatus?: string) => {
    if (vehicleId) {
      const isMaint = targetStatus === 'em_manutencao' || targetStatus === 'in_maintenance';
      const isCommercial = targetStatus === 'preparado_comercial' || targetStatus === 'ready_for_dispatch';
      const newStatus = isMaint ? 'in_maintenance' : isCommercial ? 'ready_for_dispatch' : 'active';
      const newMaint = isMaint ? 'in_progress' : 'up_to_date';

      setVehicles((prev) => {
        const found = prev.find((v) => v.id.toLowerCase() === vehicleId.toLowerCase());
        if (found) {
          const updated = {
            ...found,
            status: newStatus,
            maintenanceStatus: newMaint,
          };
          triggerStatusNotificationPopup(updated, targetStatus);
        }
        return prev.map((v) => {
          if (v.id.toLowerCase() === vehicleId.toLowerCase()) {
            return {
              ...v,
              status: newStatus,
              maintenanceStatus: newMaint,
            };
          }
          return v;
        });
      });

      setSelectedVehicleForPassport((prev) => {
        if (prev && prev.id.toLowerCase() === vehicleId.toLowerCase()) {
          return {
            ...prev,
            status: newStatus,
            maintenanceStatus: newMaint,
          };
        }
        return prev;
      });
    }
    loadYardData();
  }, [loadYardData, triggerStatusNotificationPopup]);

  const handleMarkAllRead = async () => {
    await apiService.markAllNotificationsRead();
    setNotifications((prev) => prev.map(n => ({ ...n, read: true })));
  };

  const filteredMovements = movements.filter((m) => {
    if (movementTypeFilter !== 'all' && m.type !== movementTypeFilter) return false;
    if (movementSearch) {
      const q = movementSearch.toLowerCase();
      return (
        m.vehicleId.toLowerCase().includes(q) ||
        m.vehicleName.toLowerCase().includes(q) ||
        m.reason.toLowerCase().includes(q) ||
        m.operatorName.toLowerCase().includes(q) ||
        m.sourceTrackName?.toLowerCase().includes(q) ||
        m.targetTrackName?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Header Bar with Navigation, Real-time status & RBAC Switcher */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        currentUser={currentUser}
        onOpenUserSwitcher={() => handleOpenAuthModal('login')}
        onOpenUserManagement={() => setIsProfileManagementModalOpen(true)}
        notifications={notifications}
        onOpenNotifications={() => setIsNotificationsDrawerOpen(true)}
        overallOccupancyPct={overallOccupancyPct}
      />

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {loading && tracks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-4">
            <RefreshCw className="w-8 h-8 text-amber-500 animate-spin" />
            <p className="text-sm text-slate-400 font-medium">
              Conectando aos sistemas CCO e sincronizando layout de vagas...
            </p>
          </div>
        ) : (
          <>
            {currentTab !== 'yard' && (
              <div className="mb-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentTab('yard')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-amber-400 hover:text-amber-300 text-xs font-semibold transition cursor-pointer shadow-sm"
                  title="Retornar à tela inicial do Sinóptico CCO"
                >
                  <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                  <span>Voltar ao Sinóptico CCO (Mapa do Pátio)</span>
                </button>
              </div>
            )}

            {/* TAB 1: YARD MAP (INTERACTIVE REAL-TIME SPOTS & DRILL-DOWN) */}
            {currentTab === 'yard' && (
              <YardMap
                tracks={tracks}
                vehicles={vehicles}
                currentUser={currentUser}
                activeManobrador={activeManobrador}
                onToggleManobrador={() => setIsManobradorModalOpen(true)}
                onSelectVehicle={(veh) => setSelectedVehicleForPassport(veh)}
                onQuickMove={(vehId, trkId) => {
                  setPreselectedTrackId(trkId);
                  setIsMovementModalOpen(true);
                }}
                onNewMovementWithTrack={handleNewMovementWithTrack}
                onSpotUpdated={loadYardData}
              />
            )}

            {/* TAB 2: MOVEMENTS REGISTRATION & LIFE-CYCLE HISTORY */}
            {currentTab === 'movements' && (
              <div className="space-y-6">
                {/* Header & Controls */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-white flex items-center gap-2">
                        <Train className="w-5 h-5 text-amber-400" />
                        Histórico Completo de Movimentações em Tempo Real
                      </h2>
                      <p className="text-xs text-slate-400 mt-1">
                        Auditoria de manobras com registro do operador, motivo de entrada e autorização ODT
                      </p>
                    </div>

                    <button
                      id="btn-new-movement-from-view"
                      onClick={() => {
                        setPreselectedTrackId(null);
                        setIsMovementModalOpen(true);
                      }}
                      className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
                    >
                      <Train className="w-4 h-4" />
                      <span>Registrar Nova Manobra</span>
                    </button>
                  </div>

                  {/* Filter Toolbar */}
                  <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="relative w-full sm:w-80">
                      <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={movementSearch}
                        onChange={(e) => setMovementSearch(e.target.value)}
                        placeholder="Buscar por veículo, operador, via..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <Filter className="w-3.5 h-3.5 text-slate-500" />
                      <select
                        value={movementTypeFilter}
                        onChange={(e) => setMovementTypeFilter(e.target.value)}
                        className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white outline-none"
                      >
                        <option value="all">Todos os Tipos de Manobra</option>
                        <option value="entry">Entrada no Pátio</option>
                        <option value="shunting">Manobra Interna</option>
                        <option value="maintenance_in">Entrada na Oficina</option>
                        <option value="maintenance_out">Saída da Oficina</option>
                        <option value="exit">Despacho / Saída</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Movements Table / Cards */}
                <div className="space-y-3">
                  {filteredMovements.length === 0 ? (
                    <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-xl text-slate-500 text-xs">
                      Nenhuma movimentação localizada com os filtros especificados.
                    </div>
                  ) : (
                    filteredMovements.map((mov) => (
                      <div
                        key={mov.id}
                        className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 shadow-sm transition space-y-2.5"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                          <div className="flex items-center gap-2.5">
                            <span className="font-mono text-xs text-amber-400 font-bold px-2 py-0.5 rounded bg-slate-800 border border-slate-700">
                              {mov.id}
                            </span>
                            <span className="text-xs text-slate-400">
                              {new Date(mov.timestamp).toLocaleString('pt-BR')}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className={`text-[11px] px-2 py-0.5 rounded font-semibold border ${
                              mov.type === 'entry' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                              mov.type === 'exit' ? 'bg-sky-500/20 text-sky-300 border-sky-500/30' :
                              mov.type === 'shunting' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                              'bg-purple-500/20 text-purple-300 border-purple-500/30'
                            }`}>
                              {mov.type === 'entry' && 'Entrada no Pátio'}
                              {mov.type === 'exit' && 'Despacho Linha Tronco'}
                              {mov.type === 'shunting' && 'Manobra Interna'}
                              {mov.type === 'maintenance_in' && 'Envio para Oficina'}
                              {mov.type === 'maintenance_out' && 'Retorno de Manutenção'}
                            </span>
                          </div>
                        </div>

                        {/* Movement Core details */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                          {/* Vehicle */}
                          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                            <span className="text-[10px] text-slate-500 block mb-0.5">Veículo Ferroviário:</span>
                            <button
                              onClick={() => handleOpenVehiclePassport(mov.vehicleId)}
                              className="font-bold text-white hover:text-amber-400 text-left transition flex items-center gap-1.5"
                            >
                              <Train className="w-3.5 h-3.5 text-amber-400" />
                              <span>{mov.vehicleName || mov.vehicleId}</span>
                            </button>
                            <span className="text-[10px] text-slate-400 block mt-0.5">
                              Motivo: <strong>{mov.reason}</strong>
                            </span>
                          </div>

                          {/* Origin & Destination Tracks */}
                          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                            <span className="text-[10px] text-slate-500 block mb-0.5">Trajeto de Linhas / Vagas:</span>
                            <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                              <span className="truncate">{mov.sourceTrackName || 'Linha Externa'}</span>
                              <ArrowRight className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              <span className="text-amber-300 truncate">{mov.targetTrackName || 'Linha Tronco'}</span>
                            </div>
                            {mov.targetSpotId && (
                              <span className="text-[10px] font-mono text-emerald-400 block mt-0.5">
                                via alocada {formatSpotToViaPosicao(mov.targetSpotId)}
                              </span>
                            )}
                          </div>

                          {/* Operator & Responsáveis */}
                          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col justify-between">
                            <div>
                              <span className="text-[10px] text-slate-500 block mb-0.5">Responsáveis:</span>
                              <div className="flex items-center gap-1.5 text-slate-300">
                                <UserCheck className="w-3.5 h-3.5 text-sky-400" />
                                <span>Operador: <strong>{mov.operatorName}</strong></span>
                              </div>
                            </div>

                            <div className="mt-2 pt-1.5 border-t border-slate-800/80">
                              {editingMovementId === mov.id ? (
                                <form
                                  onSubmit={(e) => {
                                    e.preventDefault();
                                    handleSaveMovementODT(mov.id);
                                  }}
                                  className="space-y-1.5 animate-fadeIn"
                                >
                                  <label className="text-[10px] text-amber-400 font-semibold block">
                                    Editar Nome do ODT:
                                  </label>
                                  <div className="flex items-center gap-1.5">
                                    <input
                                      type="text"
                                      value={editingODTName}
                                      onChange={(e) => setEditingODTName(e.target.value)}
                                      placeholder="Nome do ODT"
                                      autoFocus
                                      className="flex-1 min-w-0 bg-slate-900 border border-amber-500/70 rounded px-2 py-1 text-xs text-white outline-none focus:ring-1 focus:ring-amber-500 font-medium"
                                    />
                                    <button
                                      type="submit"
                                      disabled={isSavingODT}
                                      className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[11px] transition cursor-pointer flex items-center gap-1 shrink-0"
                                      title="Salvar ODT"
                                    >
                                      <Check className="w-3 h-3" />
                                      <span>Salvar</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setEditingMovementId(null);
                                        setEditingODTName('');
                                      }}
                                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer shrink-0"
                                      title="Cancelar"
                                    >
                                      <X className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </form>
                              ) : (
                                <div className="flex items-center justify-between text-[11px] gap-2">
                                  <span className="text-slate-400 truncate">
                                    ODT: <strong className="text-amber-300 font-medium">{mov.authorizedByCCO || 'Não atribuído'}</strong>
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setEditingMovementId(mov.id);
                                      setEditingODTName(mov.authorizedByCCO || '');
                                    }}
                                    className="flex items-center gap-1 text-[10px] font-semibold text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-2 py-0.5 rounded transition cursor-pointer shrink-0"
                                    title="Editar nome do ODT"
                                  >
                                    <Edit3 className="w-2.5 h-2.5" />
                                    <span>Editar ODT</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {mov.notes && (
                          <p className="text-[11px] text-slate-400 italic px-1">
                            "{mov.notes}"
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* TAB 3: DAILY OPERATIONAL REPORTS (RDO FERROVIÁRIO COM EXPORTAÇÃO CSV/PDF) */}
            {currentTab === 'reports' && <DailyReportsView tracks={tracks} liveOccupancyPct={overallOccupancyPct} />}

            {/* TAB 4: API INTEGRATION & PREVENTIVE MAINTENANCE SYNCHRONIZATION */}
            {currentTab === 'api' && <SchedulesSyncView />}

            {/* TAB 5: REAL-TIME AUDIT LOG */}
            {currentTab === 'audit' && (
              <div className="space-y-4">
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    Trilha de Auditoria Imutável em Tempo Real
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Todos os acessos, manobras, confirmações de alertas e sincronizações API são registrados com IP, dispositivo e perfil de operador.
                  </p>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase tracking-wider font-semibold text-[10px]">
                        <tr>
                          <th className="px-4 py-3">ID / Data</th>
                          <th className="px-4 py-3">Operador / Perfil</th>
                          <th className="px-4 py-3">Ação Registrada</th>
                          <th className="px-4 py-3">Detalhes</th>
                          <th className="px-4 py-3">Dispositivo / IP</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {auditLogs.map((log) => (
                          <tr key={log.id} className="hover:bg-slate-800/40 transition">
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="font-mono text-slate-300 font-bold block">{log.id}</span>
                              <span className="text-[10px] text-slate-500">
                                {new Date(log.timestamp).toLocaleString('pt-BR')}
                              </span>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="font-semibold text-white block">{log.userName}</span>
                              <span className="text-[10px] text-slate-400">{log.userRole}</span>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
                                {log.action}
                              </span>
                            </td>
                            <td className="px-4 py-3 max-w-md text-slate-300 leading-relaxed">
                              {log.details}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-slate-400 text-[11px]">
                              <span className="block text-slate-300">{log.device}</span>
                              <span className="text-[10px] font-mono text-slate-500">{log.clientIp}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 6: NOTIFICATION CENTER & CUSTOMIZABLE RULES (USER REQUIREMENT) */}
            {currentTab === 'notifications' && (
              <NotificationCenterView
                currentUser={currentUser}
                tracks={tracks}
                onOpenVehiclePassport={handleOpenVehiclePassport}
                onRefreshYard={loadYardData}
              />
            )}
          </>
        )}

      </main>

      {/* QUICK NOTIFICATIONS DRAWER */}
      {isNotificationsDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full p-5 shadow-2xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-amber-400" />
                  <h3 className="font-bold text-white text-base">Alertas Recentes da Central</h3>
                </div>
                <button
                  onClick={() => setIsNotificationsDrawerOpen(false)}
                  className="text-slate-400 hover:text-white p-1 text-lg font-bold"
                >
                  &times;
                </button>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{notifications.filter(n => !n.read).length} alertas não lidos</span>
                <button
                  onClick={handleMarkAllRead}
                  className="text-amber-400 hover:underline font-medium"
                >
                  Marcar todos como lidos
                </button>
              </div>

              <div className="space-y-2.5 max-h-[70vh] overflow-y-auto pr-1">
                {notifications.map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-3 rounded-lg border text-xs space-y-1 ${
                      notif.read ? 'bg-slate-950/60 border-slate-800 text-slate-400' : 'bg-slate-950 border-amber-500/40 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{notif.title}</span>
                      <span className="text-[10px] text-slate-500">{new Date(notif.timestamp).toLocaleTimeString('pt-BR')}</span>
                    </div>
                    <p className="text-[11px] leading-relaxed">{notif.message}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800">
              <button
                onClick={() => {
                  setIsNotificationsDrawerOpen(false);
                  setCurrentTab('notifications');
                }}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs shadow transition text-center cursor-pointer"
              >
                Abrir Central de Regras CCO
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: MOVEMENT REGISTRATION */}
      <MovementModal
        isOpen={isMovementModalOpen}
        onClose={() => {
          setIsMovementModalOpen(false);
          setPreselectedTrackId(null);
          setPreselectedSpotId(null);
          setPreselectedMovementType(undefined);
          setPreselectedVehicleId(null);
          setForceEntryOnly(false);
        }}
        tracks={tracks}
        vehicles={vehicles}
        currentUser={currentUser}
        activeManobrador={activeManobrador}
        onActivateManobrador={handleActivateManobrador}
        preselectedTrackId={preselectedTrackId}
        preselectedSpotId={preselectedSpotId}
        initialMovementType={preselectedMovementType}
        initialVehicleId={preselectedVehicleId}
        forceEntryOnly={forceEntryOnly}
        onSubmitMovement={handleRegisterMovement}
      />

      {/* MODAL: VEHICLE PASSPORT */}
      {selectedVehicleForPassport && (
        <VehiclePassportModal
          vehicle={selectedVehicleForPassport}
          isOpen={!!selectedVehicleForPassport}
          currentUser={currentUser}
          activeManobrador={activeManobrador}
          tracks={tracks}
          onClose={() => setSelectedVehicleForPassport(null)}
          onStatusUpdated={handleVehicleStatusUpdated}
          onMoveVehicle={(vId) => {
            setSelectedVehicleForPassport(null);
            setPreselectedVehicleId(vId);
            setPreselectedMovementType('shunting');
            setIsMovementModalOpen(true);
          }}
          onExitVehicle={(vId) => {
            setSelectedVehicleForPassport(null);
            setPreselectedVehicleId(vId);
            setPreselectedMovementType('exit');
            const tfTrack = tracks.find(t => t.code === 'TF' || t.id === 'VIA-TF');
            setPreselectedTrackId(tfTrack?.id || 'VIA-TF');
            setIsMovementModalOpen(true);
          }}
        />
      )}

      {/* MODAL: USER & RBAC AUTH / FIRST ACCESS CADASTRO */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        initialTab={authModalInitialTab}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          setStoredSession(user);
          setIsAuthModalOpen(false);
        }}
      />

      {/* MODAL: GESTÃO & EXCLUSÃO DE PERFIS (EXCLUSIVO SUPERVISOR CCO APÓS LOGIN) */}
      <ProfileManagementModal
        isOpen={isProfileManagementModalOpen}
        onClose={() => setIsProfileManagementModalOpen(false)}
        currentUser={currentUser}
        onUserDeleted={(deletedUserId) => {
          // If supervisor deleted their current profile, log out or switch
          if (currentUser?.id === deletedUserId) {
            handleOpenAuthModal('login');
          }
        }}
      />

      {/* MODAL: CONTROLE EXCLUSIVO DE MANOBRADOR */}
      <ManobradorModal
        isOpen={isManobradorModalOpen}
        onClose={() => setIsManobradorModalOpen(false)}
        currentUser={currentUser}
        activeManobrador={activeManobrador}
        onActivate={handleActivateManobrador}
        onRelease={handleReleaseManobrador}
      />

      {/* POP-UPS DE NOTIFICAÇÃO SUPERIOR ESQUERDA (EXCLUSIVO CCO / MRO) */}
      <StatusNotificationPopups
        popups={statusPopups}
        currentUser={currentUser}
        onDismiss={handleDismissStatusPopup}
        onSelectVehicle={handleSelectVehicleFromPopup}
      />

    </div>
  );
}
