export interface VltLineOption {
  id: string;
  name: string;
  color: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  description: string;
  defaultDestination: string;
  stations: string[];
}

export const VLT_LINES: VltLineOption[] = [
  {
    id: 'linha_1',
    name: 'Linha 1 - Azul',
    color: '#0284c7',
    badgeBg: 'bg-sky-500/20',
    badgeBorder: 'border-sky-500/40',
    badgeText: 'text-sky-300',
    description: 'Santos Dumont ↔ Terminal Gentileza',
    defaultDestination: 'Terminal Gentileza (TIG)',
    stations: [
      'Terminal Gentileza (TIG)',
      'Praia Formosa',
      'Rodoviária Novo Rio',
      'Cordeiro da Graça',
      'Santo Cristo',
      'Cidade do Samba',
      'Utopia AquaRio',
      'Harmonia',
      'Parada dos Navios',
      'Parada dos Museus',
      'São Bento',
      'Candelária',
      'Sete de Setembro',
      'Carioca',
      'Cinelândia',
      'Antônio Carlos',
      'Santos Dumont (SDU)'
    ]
  },
  {
    id: 'linha_2',
    name: 'Linha 2 - Verde',
    color: '#10b981',
    badgeBg: 'bg-emerald-500/20',
    badgeBorder: 'border-emerald-500/40',
    badgeText: 'text-emerald-300',
    description: 'Praça XV ↔ Terminal Gentileza / Praia Formosa',
    defaultDestination: 'Praça XV',
    stations: [
      'Praça XV',
      'Tiradentes',
      'Saara',
      'Praça da República',
      'Central do Brasil',
      'Gamboa',
      'Santo Cristo',
      'Cordeiro da Graça',
      'Rodoviária Novo Rio',
      'Praia Formosa',
      'Terminal Gentileza (TIG)'
    ]
  },
  {
    id: 'linha_3',
    name: 'Linha 3 - Amarela',
    color: '#eab308',
    badgeBg: 'bg-amber-500/20',
    badgeBorder: 'border-amber-500/40',
    badgeText: 'text-amber-300',
    description: 'Santos Dumont ↔ Central do Brasil',
    defaultDestination: 'Central do Brasil',
    stations: [
      'Central do Brasil',
      'Cristiano Ottoni / Pequena África',
      'Camerino / Rosas Negras',
      'Santa Rita / Pretos Novos',
      'Candelária',
      'Sete de Setembro',
      'Carioca',
      'Cinelândia',
      'Antônio Carlos',
      'Santos Dumont (SDU)'
    ]
  },
  {
    id: 'linha_4',
    name: 'Linha 4 - Laranja',
    color: '#f97316',
    badgeBg: 'bg-orange-500/20',
    badgeBorder: 'border-orange-500/40',
    badgeText: 'text-orange-300',
    description: 'Praça XV ↔ Terminal Gentileza',
    defaultDestination: 'Terminal Gentileza (TIG)',
    stations: [
      'Praça XV',
      'Candelária',
      'Parada dos Museus',
      'Parada dos Navios',
      'Utopia AquaRio',
      'Cidade do Samba',
      'Santo Cristo',
      'Rodoviária Novo Rio',
      'Terminal Gentileza (TIG)'
    ]
  }
];

export const VLT_COMMON_DESTINATIONS = [
  'Terminal Gentileza (TIG)',
  'Santos Dumont (SDU)',
  'Praça XV',
  'Central do Brasil',
  'Praia Formosa',
  'Rodoviária Novo Rio',
  'Carioca',
  'Cinelândia',
  'Parada dos Museus',
  'Linha Comercial Tronco'
];
