import { 
  YardTrack, 
  TrainVehicle, 
  MovementRecord, 
  MaintenanceSchedule, 
  NotificationAlert, 
  NotificationRule, 
  AuditLogEntry, 
  DailyReportSummary, 
  YardSpot, 
  YardSpotStatus,
  UserProfile,
  ActiveManobradorState
} from '../types';
import {
  INITIAL_TRACKS,
  INITIAL_VEHICLES,
  INITIAL_MOVEMENTS,
  INITIAL_SCHEDULES,
  INITIAL_NOTIFICATIONS,
  INITIAL_RULES,
  INITIAL_AUDIT_LOGS,
  INITIAL_USERS
} from '../data/initialData';

const CONTINUOUS_MEMORY_KEY = 'motiva_yard_continuous_memory_v2';
const USERS_STORAGE_KEY = 'ferropatio_unified_users_v2';

export interface YardStatusResponse {
  tracks: YardTrack[];
  vehicles: TrainVehicle[];
  summary: {
    totalTracks: number;
    availableTracks: number;
    criticalTracksCount: number;
    interdictedTracksCount: number;
    totalWagonCapacity: number;
    occupiedWagons: number;
    overallOccupancyPct: number;
    activeVehiclesInYard: number;
    inMaintenanceCount: number;
    recentMovementsCount: number;
  };
}

export interface VehiclePassportResponse {
  vehicle: TrainVehicle;
  currentTrack: YardTrack | null;
  movementsCount: number;
  history: MovementRecord[];
  schedules: MaintenanceSchedule[];
  dwellTimeHours: number;
}

export interface DailyReportResponse {
  report: DailyReportSummary;
  movements: MovementRecord[];
  tracksSnapshot: Array<{
    id: string;
    name: string;
    category: string;
    capacityWagons: number;
    occupiedWagons: number;
    occupancyPct: number;
    status: string;
  }>;
}

class ApiService {
  private eventSource: EventSource | null = null;
  private listeners: Map<string, Array<(data: any) => void>> = new Map();

  // Connect to Server-Sent Events stream for real-time concurrent updates
  public connectSSE() {
    if (typeof window === 'undefined') return;
    if (this.eventSource) {
      this.eventSource.close();
    }

    try {
      this.eventSource = new EventSource('/api/v1/events');

      this.eventSource.addEventListener('movement_registered', (event) => {
        const data = JSON.parse(event.data);
        this.emit('movement_registered', data);
      });

      this.eventSource.addEventListener('schedule_updated', (event) => {
        const data = JSON.parse(event.data);
        this.emit('schedule_updated', data);
      });

      this.eventSource.addEventListener('api_sync_completed', (event) => {
        const data = JSON.parse(event.data);
        this.emit('api_sync_completed', data);
      });

      this.eventSource.addEventListener('new_notification', (event) => {
        const data = JSON.parse(event.data);
        this.emit('new_notification', data);
      });

      this.eventSource.addEventListener('notification_confirmed', (event) => {
        const data = JSON.parse(event.data);
        this.emit('notification_confirmed', data);
      });

      this.eventSource.addEventListener('rules_updated', (event) => {
        const data = JSON.parse(event.data);
        this.emit('rules_updated', data);
      });

      this.eventSource.addEventListener('spot_updated', (event) => {
        const data = JSON.parse(event.data);
        this.emit('spot_updated', data);
      });

      this.eventSource.addEventListener('manobrador_changed', (event) => {
        const data = JSON.parse(event.data);
        this.emit('manobrador_changed', data);
      });

      this.eventSource.addEventListener('vehicle_status_updated', (event) => {
        const data = JSON.parse(event.data);
        this.emit('vehicle_status_updated', data);
      });

      this.eventSource.addEventListener('users_updated', (event) => {
        const data = JSON.parse(event.data);
        this.emit('users_updated', data);
      });

      this.eventSource.onerror = () => {
        // SSE disconnected or not supported in serverless/static hosting (e.g. Netlify)
        if (this.eventSource) {
          this.eventSource.close();
          this.eventSource = null;
        }
      };
    } catch (e) {
      console.warn('SSE connection failed, running in resilient client mode', e);
    }
  }

  private getLocalMemory(): {
    tracks: YardTrack[];
    vehicles: TrainVehicle[];
    movements: MovementRecord[];
    notifications: NotificationAlert[];
    auditLogs: AuditLogEntry[];
    activeManobrador: ActiveManobradorState | null;
  } {
    if (typeof window === 'undefined') {
      return {
        tracks: INITIAL_TRACKS,
        vehicles: INITIAL_VEHICLES,
        movements: INITIAL_MOVEMENTS,
        notifications: INITIAL_NOTIFICATIONS,
        auditLogs: INITIAL_AUDIT_LOGS,
        activeManobrador: null,
      };
    }
    try {
      const raw = localStorage.getItem(CONTINUOUS_MEMORY_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const parsedVehicles = (Array.isArray(parsed.vehicles) && parsed.vehicles.length > 0) ? parsed.vehicles : INITIAL_VEHICLES;
        const normalizedVehicles = parsedVehicles.map((v: any) => {
          if (v.operatorCompany && v.operatorCompany.includes('Metrô CCO')) {
            return { ...v, operatorCompany: 'VLT Carioca' };
          }
          return v;
        });
        return {
          tracks: (Array.isArray(parsed.tracks) && parsed.tracks.length > 0) ? parsed.tracks : INITIAL_TRACKS,
          vehicles: normalizedVehicles,
          movements: Array.isArray(parsed.movements) ? parsed.movements : INITIAL_MOVEMENTS,
          notifications: Array.isArray(parsed.notifications) ? parsed.notifications : INITIAL_NOTIFICATIONS,
          auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : INITIAL_AUDIT_LOGS,
          activeManobrador: parsed.activeManobrador || null,
        };
      }
    } catch (e) {}

    return {
      tracks: INITIAL_TRACKS,
      vehicles: INITIAL_VEHICLES,
      movements: INITIAL_MOVEMENTS,
      notifications: INITIAL_NOTIFICATIONS,
      auditLogs: INITIAL_AUDIT_LOGS,
      activeManobrador: null,
    };
  }

  private saveLocalMemory(state: {
    tracks?: YardTrack[];
    vehicles?: TrainVehicle[];
    movements?: MovementRecord[];
    notifications?: NotificationAlert[];
    auditLogs?: AuditLogEntry[];
    activeManobrador?: ActiveManobradorState | null;
  }) {
    if (typeof window === 'undefined') return;
    try {
      const current = this.getLocalMemory();
      const updated = {
        ...current,
        ...state,
        lastSaved: new Date().toISOString(),
      };
      localStorage.setItem(CONTINUOUS_MEMORY_KEY, JSON.stringify(updated));
    } catch (e) {}
  }

  private async safeFetchJson<T>(url: string, options?: RequestInit): Promise<T> {
    const res = await fetch(url, options);
    const contentType = res.headers.get('content-type') || '';
    if (!res.ok || contentType.includes('text/html')) {
      throw new Error(`Endpoint ${url} retornou ${res.status} ou HTML (${contentType})`);
    }
    return res.json();
  }

  public subscribe(event: string, callback: (data: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(callback);
    return () => {
      const arr = this.listeners.get(event) || [];
      const idx = arr.indexOf(callback);
      if (idx !== -1) arr.splice(idx, 1);
    };
  }

  private emit(event: string, data: any) {
    const arr = this.listeners.get(event);
    if (arr) {
      arr.forEach(cb => cb(data));
    }
  }

  // API Methods
  public async getYardStatus(): Promise<YardStatusResponse> {
    try {
      return await this.safeFetchJson<YardStatusResponse>('/api/v1/yard');
    } catch (e) {
      const mem = this.getLocalMemory();
      const totalWagonCapacity = mem.tracks.reduce((acc, t) => acc + ((t.spots && t.spots.length > 0) ? t.spots.length : (t.capacityWagons || 1)), 0);
      const occupiedWagons = mem.tracks.reduce((acc, t) => {
        if (t.spots && t.spots.length > 0) return acc + t.spots.filter(s => s.status === 'occupied' || !!s.vehicleId).length;
        return acc + (t.assignedVehicles?.length || 0);
      }, 0);
      const overallOccupancyPct = totalWagonCapacity > 0 ? Math.round((occupiedWagons / totalWagonCapacity) * 100) : 0;
      const criticalTracks = mem.tracks.filter(t => t.status === 'critical' || t.status === 'high');

      return {
        tracks: mem.tracks,
        vehicles: mem.vehicles,
        summary: {
          totalTracks: mem.tracks.length,
          availableTracks: mem.tracks.filter(t => t.status === 'available').length,
          criticalTracksCount: criticalTracks.length,
          interdictedTracksCount: mem.tracks.filter(t => t.status === 'interdicted').length,
          totalWagonCapacity,
          occupiedWagons,
          overallOccupancyPct,
          activeVehiclesInYard: mem.vehicles.filter(v => v.currentTrackId !== null).length,
          inMaintenanceCount: mem.vehicles.filter(v => v.status === 'in_maintenance').length,
          recentMovementsCount: mem.movements.length,
        }
      };
    }
  }

  public async registerMovement(data: {
    vehicleId: string;
    type: string;
    reason: string;
    sourceTrackId?: string | null;
    targetTrackId?: string | null;
    targetSpotId?: string | null;
    operatorId: string;
    operatorName: string;
    operatorRole: string;
    authorizedByCCO: string;
    safetyChecklist?: {
      handbrakeApplied: boolean;
      trackChocksInstalled: boolean;
      pantographLowered?: boolean;
      signalingFlagsPlaced: boolean;
      visualInspectionDone: boolean;
    };
    designatedLine?: string;
    designatedDestination?: string;
    notes?: string;
    newVehicleData?: any;
  }): Promise<{ success: boolean; movement: MovementRecord; vehicle?: TrainVehicle; tracks?: YardTrack[]; alert?: NotificationAlert }> {
    try {
      const res = await fetch('/api/v1/movements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha no servidor ao registrar movimentação');
      }
      return await res.json();
    } catch (e) {
      // Offline / Netlify static fallback: execute movement on local client storage
      const mem = this.getLocalMemory();
      let vehicle = mem.vehicles.find(v => v.id === data.vehicleId);
      const sourceTrack = mem.tracks.find(t => t.id === data.sourceTrackId);
      const targetTrack = mem.tracks.find(t => t.id === data.targetTrackId);

      if (!vehicle && data.newVehicleData) {
        vehicle = {
          id: data.vehicleId,
          name: data.newVehicleData.name || data.vehicleId,
          type: data.newVehicleData.type || 'train_passenger',
          operatorCompany: 'VLT Carioca',
          model: 'Alstom Citadis 402',
          lengthMeters: 44,
          weightTons: 50,
          currentTrackId: data.targetTrackId || null,
          currentSpotId: data.targetSpotId || null,
          status: 'operacional',
          cargoType: 'Passageiros (VLT 7 Módulos)',
          destination: data.designatedDestination || 'Terminal Central',
          estimatedDwellTimeHours: 3.5,
          departureEta: new Date(Date.now() + 3600000).toISOString(),
          entryDate: new Date().toISOString(),
          lastMovedAt: new Date().toISOString(),
          entryReason: data.reason as any,
          registeredBy: data.operatorName,
          maintenanceStatus: 'up_to_date',
          designatedLine: data.designatedLine || 'L1',
          designatedDestination: data.designatedDestination || 'Terminal Central',
        };
        mem.vehicles.push(vehicle);
      }

      const newMovement: MovementRecord = {
        id: `MOV-LOCAL-${Date.now()}`,
        vehicleId: data.vehicleId,
        vehicleName: vehicle ? vehicle.name : data.vehicleId,
        vehicleType: vehicle ? vehicle.type : 'train_passenger',
        timestamp: new Date().toISOString(),
        type: data.type as any,
        reason: data.reason as any,
        sourceTrackId: data.sourceTrackId || null,
        sourceTrackName: sourceTrack?.name || (data.type === 'entry' ? 'Via Comercial' : 'Via Comercial'),
        targetTrackId: data.targetTrackId || null,
        targetTrackName: targetTrack?.name,
        operatorId: data.operatorId,
        operatorName: data.operatorName,
        operatorRole: data.operatorRole as any,
        authorizedByCCO: data.authorizedByCCO,
        safetyChecklist: data.safetyChecklist || {
          handbrakeApplied: true,
          trackChocksInstalled: true,
          pantographLowered: false,
          signalingFlagsPlaced: true,
          visualInspectionDone: true,
        },
      };

      if (sourceTrack) {
        sourceTrack.assignedVehicles = sourceTrack.assignedVehicles.filter(id => id !== data.vehicleId);
        sourceTrack.spots?.forEach(s => {
          if (s.vehicleId === data.vehicleId) {
            s.vehicleId = null;
            s.status = 'free';
          }
        });
      }

      if (targetTrack && data.type !== 'exit') {
        if (!targetTrack.assignedVehicles.includes(data.vehicleId)) {
          targetTrack.assignedVehicles.push(data.vehicleId);
        }
        if (targetTrack.spots && targetTrack.spots.length > 0) {
          const targetSpot = data.targetSpotId
            ? targetTrack.spots.find(s => s.id === data.targetSpotId)
            : targetTrack.spots.find(s => s.status === 'free');
          if (targetSpot) {
            targetSpot.vehicleId = data.vehicleId;
            targetSpot.status = 'occupied';
          }
        }
      }

      if (vehicle) {
        vehicle.currentTrackId = data.type === 'exit' ? null : (data.targetTrackId || null);
        vehicle.currentSpotId = data.type === 'exit' ? null : (data.targetSpotId || null);
        if (data.designatedLine) vehicle.designatedLine = data.designatedLine;
        if (data.designatedDestination) vehicle.destination = data.designatedDestination;
      }

      const updatedMovements = [newMovement, ...mem.movements];
      this.saveLocalMemory({
        tracks: mem.tracks,
        vehicles: mem.vehicles,
        movements: updatedMovements,
      });

      this.emit('movement_registered', {
        movement: newMovement,
        vehicle,
        tracks: mem.tracks,
      });

      return {
        success: true,
        movement: newMovement,
        vehicle,
        tracks: mem.tracks,
      };
    }
  }

  public async updateVehicleDispatchAssignment(
    vehicleId: string,
    data: { designatedLine: string; designatedDestination: string; notes?: string; user?: any }
  ): Promise<{ success: boolean; vehicle: TrainVehicle; message: string }> {
    const res = await fetch(`/api/v1/vehicles/${vehicleId}/dispatch-assignment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro na requisição' }));
      throw new Error(err.error || 'Falha ao designar linha e destino para despacho');
    }
    return res.json();
  }

  public async toggleVehicleOperationalPhone(
    vehicleId: string,
    data: { hasOperationalPhone?: boolean; operationalPhoneNotes?: string; user?: any }
  ): Promise<{ success: boolean; vehicle: TrainVehicle; hasOperationalPhone: boolean; message: string }> {
    let result: { success: boolean; vehicle: TrainVehicle; hasOperationalPhone: boolean; message: string };
    try {
      const res = await fetch(`/api/v1/vehicles/${vehicleId}/operational-phone`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        throw new Error(`Servidor respondeu com status ${res.status}`);
      }
      result = await res.json();
    } catch (err: any) {
      // Offline fallback: update local memory directly
      const mem = this.getLocalMemory();
      const currentV = mem.vehicles.find(v => v.id.toLowerCase() === vehicleId.toLowerCase());
      const nextPhoneState = typeof data.hasOperationalPhone === 'boolean'
        ? data.hasOperationalPhone
        : (currentV ? !currentV.hasOperationalPhone : true);
      const updatedVehicle: TrainVehicle = currentV
        ? {
            ...currentV,
            hasOperationalPhone: nextPhoneState,
            operationalPhoneNotes: data.operationalPhoneNotes !== undefined ? data.operationalPhoneNotes : currentV.operationalPhoneNotes,
          }
        : {
            id: vehicleId,
            name: vehicleId,
            type: 'train_passenger',
            status: 'active',
            maintenanceStatus: 'up_to_date',
            hasOperationalPhone: nextPhoneState,
            operationalPhoneNotes: data.operationalPhoneNotes,
          } as TrainVehicle;

      result = {
        success: true,
        vehicle: updatedVehicle,
        hasOperationalPhone: nextPhoneState,
        message: 'Status atualizado em modo offline / contínuo',
      };
    }

    // Persist immediately to local continuous memory so it is NEVER lost on reload or sync
    const mem = this.getLocalMemory();
    const updatedVehicles = mem.vehicles.map(v => {
      if (v.id.toLowerCase() === vehicleId.toLowerCase()) {
        return {
          ...v,
          hasOperationalPhone: result.hasOperationalPhone,
          operationalPhoneNotes: data.operationalPhoneNotes !== undefined ? data.operationalPhoneNotes : v.operationalPhoneNotes,
        };
      }
      return v;
    });

    // If vehicle wasn't found in mem, add it
    if (!updatedVehicles.some(v => v.id.toLowerCase() === vehicleId.toLowerCase()) && result.vehicle) {
      updatedVehicles.push(result.vehicle);
    }

    this.saveLocalMemory({ vehicles: updatedVehicles });

    // Emit events so all components (and tabs) stay in sync
    this.emit('vehicle_updated', { vehicle: result.vehicle });
    this.emit('vehicle_status_updated', { vehicle: result.vehicle });

    return result;
  }

  public async getMovements(vehicleId?: string, limit?: number): Promise<{ total: number; movements: MovementRecord[] }> {
    const params = new URLSearchParams();
    if (vehicleId) params.set('vehicleId', vehicleId);
    if (limit) params.set('limit', limit.toString());
    const res = await fetch(`/api/v1/movements?${params.toString()}`);
    if (!res.ok) throw new Error('Falha ao buscar movimentações');
    return res.json();
  }

  public async updateMovement(id: string, updates: { authorizedByCCO?: string }): Promise<{ success: boolean; movement: MovementRecord }> {
    const mem = this.getLocalMemory();
    const index = mem.movements.findIndex(m => m.id === id);
    let updatedMovement: MovementRecord | null = null;
    if (index !== -1) {
      mem.movements[index] = {
        ...mem.movements[index],
        ...updates,
      };
      updatedMovement = mem.movements[index];
      this.saveLocalMemory({
        ...mem,
        movements: mem.movements,
      });
    }

    try {
      const res = await fetch(`/api/v1/movements/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.movement) {
          updatedMovement = data.movement;
        }
      }
    } catch (err) {
      console.warn('[apiService] Falha ao enviar atualização de movimentação para o servidor, mantido localmente:', err);
    }

    if (updatedMovement) {
      this.emit('movement_updated', { movement: updatedMovement });
    }

    return { success: true, movement: updatedMovement! };
  }

  public async getVehiclePassport(vehicleId: string): Promise<VehiclePassportResponse> {
    const res = await fetch(`/api/v1/vehicles/${vehicleId}/passport`);
    if (!res.ok) throw new Error(`Falha ao obter histórico do veículo ${vehicleId}`);
    return res.json();
  }

  public async getSchedules(): Promise<{ total: number; schedules: MaintenanceSchedule[] }> {
    const res = await fetch('/api/v1/schedules');
    if (!res.ok) throw new Error('Falha ao obter cronogramas de manutenção');
    return res.json();
  }

  public async createSchedule(data: Partial<MaintenanceSchedule>): Promise<{ success: boolean; schedule: MaintenanceSchedule }> {
    const res = await fetch('/api/v1/schedules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Falha ao criar ordem de preventiva');
    return res.json();
  }

  public async triggerScheduleSync(targetSystem = 'SAP PM Gateway v2'): Promise<any> {
    const res = await fetch('/api/v1/schedules/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetSystem }),
    });
    if (!res.ok) throw new Error('Falha ao sincronizar via API');
    return res.json();
  }

  public async getDailyReport(date?: string): Promise<DailyReportResponse> {
    const d = date || new Date().toISOString().split('T')[0];
    try {
      const res = await fetch(`/api/v1/reports/daily?date=${d}`);
      if (res.ok) {
        const json = await res.json();
        const mem = this.getLocalMemory();
        if (mem.movements && mem.movements.length > 0 && json.movements) {
          json.movements = json.movements.map((serverM: MovementRecord) => {
            const localM = mem.movements.find(m => m.id === serverM.id);
            if (localM && localM.authorizedByCCO) {
              return { ...serverM, authorizedByCCO: localM.authorizedByCCO };
            }
            return serverM;
          });
        }
        return json;
      }
    } catch (err) {
      console.warn('Falha na API de relatório diário, gerando a partir de memória local:', err);
    }

    const mem = this.getLocalMemory();
    const dayMovements = mem.movements.filter(m => m.timestamp.startsWith(d));
    const finalMovements = dayMovements.length > 0 ? dayMovements : mem.movements.slice(0, 10);
    return {
      report: {
        date: d,
        totalMovements: finalMovements.length,
        entries: finalMovements.filter(m => m.type === 'entry').length,
        exits: finalMovements.filter(m => m.type === 'exit').length,
        internalShunts: finalMovements.filter(m => m.type === 'shunting').length,
        maintenanceMovements: finalMovements.filter(m => m.type === 'maintenance_in' || m.type === 'maintenance_out').length,
        averageOccupancyRate: 65,
        peakOccupancyRate: 78,
        averageDwellTimeHours: 12.5,
        preventiveMaintenancesDone: 3,
        criticalAlertsResolved: 2,
        busiestTrack: 'VIA-01',
        activeVehiclesInYard: mem.vehicles.filter(v => v.currentTrackId !== null).length,
        punctualityRatePercent: 98.2,
      },
      movements: finalMovements,
      tracksSnapshot: mem.tracks.map(t => ({
        id: t.id,
        name: t.name,
        category: t.category,
        capacityWagons: t.capacityWagons,
        occupiedWagons: t.assignedVehicles.length,
        occupancyPct: t.capacityWagons > 0 ? Math.round((t.assignedVehicles.length / t.capacityWagons) * 100) : 0,
        status: t.status,
      })),
    };
  }

  public async getAuditLogs(limit = 50, action?: string): Promise<{ total: number; logs: AuditLogEntry[] }> {
    const params = new URLSearchParams({ limit: limit.toString() });
    if (action) params.set('action', action);
    const res = await fetch(`/api/v1/audit?${params.toString()}`);
    if (!res.ok) throw new Error('Falha ao consultar logs de auditoria');
    return res.json();
  }

  public async getNotifications(): Promise<{ unreadCount: number; notifications: NotificationAlert[] }> {
    const res = await fetch('/api/v1/notifications');
    if (!res.ok) throw new Error('Falha ao obter notificações');
    return res.json();
  }

  public async markNotificationRead(id: string): Promise<any> {
    const res = await fetch(`/api/v1/notifications/${id}/read`, { method: 'POST' });
    return res.json();
  }

  public async markAllNotificationsRead(): Promise<any> {
    const res = await fetch('/api/v1/notifications/mark-all-read', { method: 'POST' });
    return res.json();
  }

  // Confirm / Acknowledge notification
  public async confirmNotification(id: string, operatorName: string, notes?: string): Promise<{ success: boolean; notif: NotificationAlert }> {
    const res = await fetch(`/api/v1/notifications/${id}/confirm`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ operatorName, notes }),
    });
    if (!res.ok) throw new Error('Falha ao confirmar atendimento da notificação');
    return res.json();
  }

  // Customizable Notification Rules
  public async getRules(): Promise<{ total: number; rules: NotificationRule[] }> {
    const res = await fetch('/api/v1/rules');
    if (!res.ok) throw new Error('Falha ao carregar regras de notificação');
    return res.json();
  }

  public async createRule(data: Partial<NotificationRule>): Promise<{ success: boolean; rule: NotificationRule }> {
    const res = await fetch('/api/v1/rules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Falha ao criar regra de notificação');
    return res.json();
  }

  public async updateRule(id: string, data: Partial<NotificationRule>): Promise<{ success: boolean; rule: NotificationRule }> {
    const res = await fetch(`/api/v1/rules/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Falha ao atualizar regra');
    return res.json();
  }

  public async deleteRule(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/v1/rules/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Falha ao remover regra');
    return res.json();
  }

  public async triggerTestRule(id: string): Promise<any> {
    const res = await fetch(`/api/v1/rules/${id}/trigger-test`, { method: 'POST' });
    if (!res.ok) throw new Error('Falha ao disparar teste de regra');
    return res.json();
  }

  public async updateSpotStatus(
    spotId: string,
    status: YardSpotStatus,
    restrictionReason?: string,
    vehicleId?: string | null
  ): Promise<any> {
    try {
      const res = await fetch(`/api/v1/spots/${spotId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, restrictionReason, vehicleId }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha ao atualizar status da vaga');
      }
      return await res.json();
    } catch (e) {
      const mem = this.getLocalMemory();
      let foundSpot: YardSpot | null = null;
      for (const track of mem.tracks) {
        const spot = track.spots?.find(s => s.id === spotId);
        if (spot) {
          spot.status = status;
          spot.restrictionReason = restrictionReason || undefined;
          if (vehicleId !== undefined) {
            spot.vehicleId = vehicleId;
          }
          foundSpot = spot;
          break;
        }
      }
      this.saveLocalMemory({ tracks: mem.tracks, vehicles: mem.vehicles });
      this.emit('spot_updated', { spot: foundSpot, tracks: mem.tracks, vehicles: mem.vehicles });
      return { success: true, spot: foundSpot, tracks: mem.tracks, vehicles: mem.vehicles };
    }
  }

  public async getManobrador(): Promise<{ activeManobrador: ActiveManobradorState | null }> {
    try {
      return await this.safeFetchJson('/api/v1/manobrador');
    } catch (e) {
      const mem = this.getLocalMemory();
      return { activeManobrador: mem.activeManobrador };
    }
  }

  public async activateManobrador(user: UserProfile): Promise<{ success: boolean; activeManobrador: ActiveManobradorState }> {
    try {
      const res = await fetch('/api/v1/manobrador/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha ao ativar função de Manobrador');
      }
      return await res.json();
    } catch (e) {
      const activeState: ActiveManobradorState = {
        userId: user.id,
        userName: user.name,
        badgeNumber: user.badgeNumber,
        role: user.role,
        roleLabel: user.roleLabel || 'Operador',
        activatedAt: new Date().toISOString(),
      };
      this.saveLocalMemory({ activeManobrador: activeState });
      this.emit('manobrador_changed', { activeManobrador: activeState });
      return { success: true, activeManobrador: activeState };
    }
  }

  public async releaseManobrador(
    userOrId: UserProfile | string, 
    userRoleOrForce?: string | boolean, 
    force = false
  ): Promise<{ success: boolean; activeManobrador: null }> {
    let userId: string;
    let userRole: string;
    let isForce = false;

    if (typeof userOrId === 'object') {
      userId = userOrId.id;
      userRole = userOrId.role;
      isForce = typeof userRoleOrForce === 'boolean' ? userRoleOrForce : false;
    } else {
      userId = userOrId;
      userRole = (userRoleOrForce as string) || '';
      isForce = force;
    }

    try {
      const res = await fetch('/api/v1/manobrador/release', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, userRole, force: isForce }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha ao liberar função de Manobrador');
      }
      return await res.json();
    } catch (e) {
      this.saveLocalMemory({ activeManobrador: null });
      this.emit('manobrador_changed', { activeManobrador: null });
      return { success: true, activeManobrador: null };
    }
  }

  private getLocalUsers(): UserProfile[] {
    if (typeof window === 'undefined') return INITIAL_USERS;
    try {
      const raw = localStorage.getItem(USERS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return INITIAL_USERS;
  }

  private saveLocalUsers(users: UserProfile[]) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (e) {}
  }

  public async updateVehicleStatus(
    vehicleId: string, 
    targetStatus: 'operacional' | 'em_manutencao' | 'preparado_comercial', 
    user: UserProfile, 
    reason?: string
  ): Promise<{ success: boolean; vehicle: TrainVehicle; statusLabel: string }> {
    try {
      const res = await fetch(`/api/v1/vehicles/${vehicleId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetStatus, user, reason }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha na alteração de status');
      }
      return await res.json();
    } catch (e) {
      const mem = this.getLocalMemory();
      const vehicle = mem.vehicles.find(v => v.id === vehicleId);
      if (vehicle) {
        vehicle.status = targetStatus;
        vehicle.maintenanceStatus = targetStatus === 'em_manutencao' ? 'in_progress' : 'up_to_date';
        if (reason) vehicle.notes = reason;
      }
      this.saveLocalMemory({ vehicles: mem.vehicles });
      this.emit('vehicle_status_updated', { vehicle });
      const label = targetStatus === 'em_manutencao' ? 'Em Manutenção' : targetStatus === 'preparado_comercial' ? 'Preparado Comercial' : 'Operacional';
      return { success: true, vehicle: vehicle!, statusLabel: label };
    }
  }

  public async getStorageStatus(): Promise<{
    persisted: boolean;
    movementsCount: number;
    vehiclesCount: number;
    tracksCount: number;
    lastSaved: string;
  }> {
    try {
      return await this.safeFetchJson('/api/v1/storage/status');
    } catch (e) {
      const mem = this.getLocalMemory();
      return {
        persisted: true,
        movementsCount: mem.movements.length,
        vehiclesCount: mem.vehicles.length,
        tracksCount: mem.tracks.length,
        lastSaved: new Date().toISOString(),
      };
    }
  }

  public async syncClientState(payload: {
    tracks?: YardTrack[];
    vehicles?: TrainVehicle[];
    movements?: MovementRecord[];
    auditLogs?: AuditLogEntry[];
    schedules?: MaintenanceSchedule[];
    users?: UserProfile[];
    clientTimestamp?: number;
  }): Promise<{
    success: boolean;
    restored: boolean;
    movementsCount: number;
    vehiclesCount: number;
    tracksCount: number;
    usersCount?: number;
    lastSaved: string;
  }> {
    try {
      // Prune payload size to prevent 413 Payload Too Large errors
      const prunedPayload = {
        ...payload,
        movements: payload.movements ? payload.movements.slice(0, 100) : undefined,
        auditLogs: payload.auditLogs ? payload.auditLogs.slice(0, 50) : undefined,
      };

      const res = await fetch('/api/v1/storage/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prunedPayload),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha no sync do servidor');
      }
      return await res.json();
    } catch (e) {
      this.saveLocalMemory({
        tracks: payload.tracks,
        vehicles: payload.vehicles,
        movements: payload.movements,
        auditLogs: payload.auditLogs,
      });
      const mem = this.getLocalMemory();
      return {
        success: true,
        restored: true,
        movementsCount: mem.movements.length,
        vehiclesCount: mem.vehicles.length,
        tracksCount: mem.tracks.length,
        lastSaved: new Date().toISOString(),
      };
    }
  }

  // Unified User Database & Authentication (Windows & Mobile Sincronizados)
  public async getUsers(): Promise<{ users: UserProfile[] }> {
    try {
      return await this.safeFetchJson('/api/v1/users');
    } catch (e) {
      return { users: this.getLocalUsers() };
    }
  }

  public async registerUser(user: Partial<UserProfile>, clientDevice?: string): Promise<{
    success: boolean;
    user: UserProfile;
    users: UserProfile[];
  }> {
    try {
      const res = await fetch('/api/v1/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user, clientDevice }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha ao cadastrar operador no servidor');
      }
      return await res.json();
    } catch (e) {
      const users = this.getLocalUsers();
      const newUser: UserProfile = {
        id: `USR-${Date.now()}`,
        name: user.name || 'Operador CCO',
        badgeNumber: user.badgeNumber || '38-00000',
        role: user.role || 'controlador_cco',
        roleLabel: user.roleLabel || 'Controlador CCO',
        department: user.department || 'Operações de Pátio',
        avatar: user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
        password: user.password || '123456',
        createdAt: new Date().toISOString(),
        createdDevice: clientDevice || 'Cliente Web',
      };
      users.push(newUser);
      this.saveLocalUsers(users);
      this.emit('users_updated', { users });
      return { success: true, user: newUser, users };
    }
  }

  public async loginUser(badgeNumber: string, password?: string, clientDevice?: string): Promise<{
    success: boolean;
    user: UserProfile;
    users?: UserProfile[];
  }> {
    try {
      const res = await fetch('/api/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ badgeNumber, password, clientDevice }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || contentType.includes('text/html')) {
        throw new Error('Falha na autenticação do servidor');
      }
      return await res.json();
    } catch (e) {
      const users = this.getLocalUsers();
      const cleanBadge = badgeNumber.replace(/\D/g, '');
      const user = users.find(u => {
        const uDigits = u.badgeNumber.replace(/\D/g, '');
        return uDigits === cleanBadge || u.badgeNumber.toLowerCase() === badgeNumber.toLowerCase() || u.name.toLowerCase().includes(badgeNumber.toLowerCase());
      }) || users[0];

      return { success: true, user, users };
    }
  }

  public async deleteUser(userId: string, supervisorUser: UserProfile, reason?: string): Promise<{
    success: boolean;
    message: string;
    users: UserProfile[];
  }> {
    const res = await fetch(`/api/v1/users/${userId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ supervisorUser, reason }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Falha ao excluir perfil' }));
      throw new Error(err.error || 'Falha ao excluir operador do banco unificado');
    }
    return res.json();
  }

  public async updateUser(userId: string, supervisorUser: UserProfile, updateData: Partial<UserProfile>): Promise<{
    success: boolean;
    user: UserProfile;
    users: UserProfile[];
  }> {
    const res = await fetch(`/api/v1/users/${userId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ supervisorUser, updateData }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Falha ao atualizar perfil' }));
      throw new Error(err.error || 'Falha ao atualizar perfil do operador');
    }
    return res.json();
  }
}

export const apiService = new ApiService();
