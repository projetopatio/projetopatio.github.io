import { TrainOperationalStatus } from '../types';
import { getNormalizedTrainStatus } from './trainStatus';

export interface TrainIconOptions {
  compositionNumber: number | string;
  status: TrainOperationalStatus | string;
}

/**
 * Generates an SVG string of the VLT front cab matching the exact user uploaded reference images:
 * - Red body & bold red composition number for "em_manutencao" (maintenance)
 * - Green body & bold green composition number for "preparado_comercial" (commercial prep)
 * - Blue body & bold blue composition number for "operacional" (operational)
 */
export function generateTrainSvg(compNum: number | string, status: TrainOperationalStatus | string = 'operacional'): string {
  const normStatus = getNormalizedTrainStatus({ status: String(status) });
  
  const isMaintenance = normStatus === 'em_manutencao';
  const isCommercialPrep = normStatus === 'preparado_comercial';
  
  // High contrast vibrant colors matching the exact uploaded reference composition images
  let primaryColor = '#0066ff'; // Default Electric Blue
  let primaryDark = '#004ec2';
  let primaryLight = '#38bdf8';
  let numberColor = '#0066ff';
  let statusText = 'OPERACIONAL';
  
  if (isMaintenance) {
    primaryColor = '#dc2626'; // Vibrant Safety Red
    primaryDark = '#991b1b';
    primaryLight = '#f87171';
    numberColor = '#dc2626';
    statusText = 'EM MANUTENÇÃO';
  } else if (isCommercialPrep) {
    primaryColor = '#16a34a'; // Vibrant Emerald Green
    primaryDark = '#14532d';
    primaryLight = '#4ade80';
    numberColor = '#16a34a';
    statusText = 'PREPARADO COMERCIAL';
  }

  const numStr = String(compNum || '101').replace(/\D/g, '') || '101';

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 380 180" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">
  <defs>
    <!-- Cab Body Gradient -->
    <linearGradient id="bodyGrad_${numStr}_${isMaintenance ? 'red' : isCommercialPrep ? 'green' : 'blue'}" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${primaryLight}" />
      <stop offset="60%" stop-color="${primaryColor}" />
      <stop offset="100%" stop-color="${primaryDark}" />
    </linearGradient>

    <!-- Chrome Trim Bar Gradient -->
    <linearGradient id="chromeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" />
      <stop offset="35%" stop-color="#f1f5f9" />
      <stop offset="60%" stop-color="#cbd5e1" />
      <stop offset="100%" stop-color="#94a3b8" />
    </linearGradient>

    <!-- Glass Gradient with Subtle Ocean/Horizon Reflection as in Reference Photos -->
    <linearGradient id="glassGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#0b1118" />
      <stop offset="45%" stop-color="#141c26" />
      <stop offset="70%" stop-color="#1b2838" />
      <stop offset="100%" stop-color="#0a0f16" />
    </linearGradient>
  </defs>

  <!-- 1. Upper Roof / Top Fairing -->
  <path
    d="M 115 10
       L 380 10
       L 380 34
       L 115 34
       Z"
    fill="url(#bodyGrad_${numStr}_${isMaintenance ? 'red' : isCommercialPrep ? 'green' : 'blue'})"
  />

  <!-- 2. Aerodynamic Front Nose Fairing (Left Slanted Cab) -->
  <path
    d="M 115 10
       C 85 11 60 22 42 42
       C 24 64 12 94 6 122
       C 3 138 2 152 0 168
       L 45 168
       C 48 152 56 138 68 128
       L 115 128
       L 115 10
       Z"
    fill="url(#bodyGrad_${numStr}_${isMaintenance ? 'red' : isCommercialPrep ? 'green' : 'blue'})"
  />

  <!-- Front Pilot / Bumper Base (Dark Apron at Bottom Left) -->
  <path
    d="M 0 168
       L 62 168
       L 66 158
       L 20 158
       L 10 148
       L 0 168
       Z"
    fill="#0f172a"
  />

  <!-- 3. Silver Chrome Horizontal Trim Stripe above windows -->
  <rect x="90" y="34" width="290" height="7" rx="1.5" fill="url(#chromeGrad)" />

  <!-- 4. Front Aerodynamic Panoramic Windshield (Dark Tinted Glass) -->
  <path
    d="M 112 42
       L 72 42
       C 56 55 42 74 32 98
       C 24 116 20 134 18 142
       L 66 142
       C 70 134 76 128 84 124
       L 112 124
       Z"
    fill="url(#glassGrad)"
    stroke="#000000"
    stroke-width="1.5"
  />
  <!-- Windshield Curved Highlight Reflection -->
  <path
    d="M 68 46
       C 54 60 42 78 34 102
       L 38 102
       C 46 80 58 64 72 50
       Z"
    fill="#ffffff"
    opacity="0.25"
  />

  <!-- 5. Central Driver/Passenger Door Structure -->
  <!-- Door Outer Column in Body Color -->
  <rect x="114" y="34" width="10" height="134" fill="url(#bodyGrad_${numStr}_${isMaintenance ? 'red' : isCommercialPrep ? 'green' : 'blue'})" />
  
  <!-- Door Glass Window (Dark Glass) -->
  <rect x="124" y="42" width="60" height="88" fill="url(#glassGrad)" stroke="#090d13" stroke-width="1.5" />
  
  <!-- Door Lower Body Panel (Status Color) -->
  <rect x="124" y="130" width="60" height="38" fill="url(#bodyGrad_${numStr}_${isMaintenance ? 'red' : isCommercialPrep ? 'green' : 'blue'})" />
  
  <!-- Door Vertical Seam -->
  <line x1="124" y1="34" x2="124" y2="168" stroke="#090e15" stroke-width="2" />
  <line x1="184" y1="34" x2="184" y2="168" stroke="#090e15" stroke-width="2" />

  <!-- 6. Passenger Saloon Panoramic Windows & Wall -->
  <!-- Window Glass -->
  <rect x="185" y="42" width="195" height="78" fill="url(#glassGrad)" stroke="#090d13" stroke-width="1.5" />
  
  <!-- Black horizontal intermediate accent line under window -->
  <rect x="185" y="120" width="195" height="14" fill="#090d13" />

  <!-- Lower Body Skirt in Status Color -->
  <rect x="185" y="134" width="195" height="34" fill="url(#bodyGrad_${numStr}_${isMaintenance ? 'red' : isCommercialPrep ? 'green' : 'blue'})" />

  <!-- Small lock / access hatch icon on lower panel -->
  <rect x="236" y="123" width="14" height="8" rx="2" fill="none" stroke="#94a3b8" stroke-width="1.2" />
  <circle cx="240" cy="127" r="1" fill="#cbd5e1" />

  <!-- 7. GIANT BOLD COMPOSITION NUMBER OVER DOOR & WINDOW (Exact Match to User Images) -->
  <text
    x="210"
    y="126"
    fill="${numberColor}"
    font-family="'Arial Black', Impact, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
    font-size="94"
    font-weight="900"
    letter-spacing="-3"
    text-anchor="middle"
    style="user-select: none;"
  >${numStr}</text>

  <!-- 8. Thin Lower Ground Rail for Context -->
  <line x1="0" y1="172" x2="380" y2="172" stroke="#1e293b" stroke-width="3" />
</svg>`;
}

/**
 * Returns a base64 or UTF-8 data URI for use in <img src="..." /> or SVG <image href="..." />
 */
export function getTrainDataUri(compNum: number | string, status: TrainOperationalStatus | string = 'operacional'): string {
  const svg = generateTrainSvg(compNum, status);
  // Encode cleanly for data URI
  const encoded = encodeURIComponent(svg)
    .replace(/'/g, '%27')
    .replace(/"/g, '%22');
  return `data:image/svg+xml;charset=utf-8,${encoded}`;
}

/**
 * Helper to get the train icon URI for a vehicle object
 */
export function getVehicleIconUri(vehicle?: { compositionNumber?: number; id?: string; status?: TrainOperationalStatus | string; maintenanceStatus?: string } | null): string {
  if (!vehicle) return getTrainDataUri(101, 'operacional');
  const compNum = vehicle.compositionNumber || parseInt((vehicle.id || '101').replace(/\D/g, ''), 10) || 101;
  const normStatus = getNormalizedTrainStatus(vehicle);
  return getTrainDataUri(compNum, normStatus);
}
