import { UserProfile, UserRole, ActiveManobradorState } from '../types';
import { INITIAL_USERS } from '../data/initialData';

export const PROFILE_CONFIG: Record<
  'tecnico_mro' | 'controlador_cco' | 'supervisor_cco',
  {
    label: string;
    description: string;
    department: string;
    badgePrefix: string;
    badgeExample: string;
    permissions: {
      setOperacional: boolean;
      setManutencao: boolean;
      setPreparadoComercial: boolean;
      performManeuvers: boolean;
      isManobrador: boolean;
    };
    rulesList: string[];
  }
> = {
  tecnico_mro: {
    label: 'Técnico MRO',
    description: 'Manutenção e liberação técnica de composições ferroviárias',
    department: 'Oficina de Manutenção & Material Rodante (MRO)',
    badgePrefix: '38-',
    badgeExample: '38-10452',
    permissions: {
      setOperacional: true,
      setManutencao: false,
      setPreparadoComercial: false,
      performManeuvers: true,
      isManobrador: true,
    },
    rulesList: [
      '1. Alterar status para OPERACIONAL (Cor Azul)',
      '2. Realizar manobras no pátio (como Manobrador ativo)',
      '3. Função MANOBRADOR (pode assumir controle exclusivo de manobras)',
    ],
  },
  controlador_cco: {
    label: 'Controlador CCO',
    description: 'Central de Controle Operacional de tráfego e despacho',
    department: 'Centro de Controle Operacional (CCO)',
    badgePrefix: '38-',
    badgeExample: '38-20814',
    permissions: {
      setOperacional: false,
      setManutencao: true,
      setPreparadoComercial: true,
      performManeuvers: true,
      isManobrador: true,
    },
    rulesList: [
      '1. Alterar status para EM MANUTENÇÃO (Cor Vermelha)',
      '2. Alterar status para PREPARADO PARA O COMERCIAL (Cor Verde)',
      '3. Realizar manobras no pátio (como Manobrador ativo)',
      '4. Função MANOBRADOR (pode assumir controle exclusivo de manobras)',
    ],
  },
  supervisor_cco: {
    label: 'Supervisor de CCO',
    description: 'Supervisão executiva de pátio, tráfego e autorizações operacionais',
    department: 'Supervisão Geral de Tráfego & Pátio CCO',
    badgePrefix: '38-',
    badgeExample: '38-30001',
    permissions: {
      setOperacional: true,
      setManutencao: true,
      setPreparadoComercial: true,
      performManeuvers: true,
      isManobrador: true,
    },
    rulesList: [
      '1. Alterar status para OPERACIONAL (Cor Azul)',
      '2. Alterar status para EM MANUTENÇÃO (Cor Vermelha)',
      '3. Alterar status para PREPARADO PARA O COMERCIAL (Cor Verde)',
      '4. Realizar manobras no pátio',
      '5. Função MANOBRADOR (com poder de desbloqueio / override de supervisão)',
    ],
  },
};

export const normalizeRole = (role: UserRole): 'tecnico_mro' | 'controlador_cco' | 'supervisor_cco' => {
  if (role === 'tecnico_mro' || role === 'maintenance_tech') return 'tecnico_mro';
  if (role === 'controlador_cco' || role === 'cco_dispatcher') return 'controlador_cco';
  if (role === 'supervisor_cco' || role === 'admin' || role === 'yard_operator') return 'supervisor_cco';
  return 'controlador_cco';
};

export const canSetOperacional = (role: UserRole): boolean => {
  const norm = normalizeRole(role);
  return PROFILE_CONFIG[norm].permissions.setOperacional;
};

export const canSetManutencao = (role: UserRole): boolean => {
  const norm = normalizeRole(role);
  return PROFILE_CONFIG[norm].permissions.setManutencao;
};

export const canSetPreparadoComercial = (role: UserRole): boolean => {
  const norm = normalizeRole(role);
  return PROFILE_CONFIG[norm].permissions.setPreparadoComercial;
};

// Regra de Negócio: Se a composição estiver com status em manutenção, SOMENTE o Técnico MRO pode alterar o status
export const canAlterVehicleStatus = (
  role: UserRole,
  currentStatus: string,
  targetStatus: 'operacional' | 'em_manutencao' | 'preparado_comercial'
): { allowed: boolean; reason?: string } => {
  const norm = normalizeRole(role);
  const isInMaintenance = currentStatus === 'em_manutencao' || currentStatus === 'in_maintenance' || currentStatus === 'in_progress';
  
  if (isInMaintenance) {
    if (norm !== 'tecnico_mro') {
      return {
        allowed: false,
        reason: 'A composição está com status EM MANUTENÇÃO. Somente o Técnico MRO possui autorização para alterar o status deste trem.',
      };
    }
  }

  if (targetStatus === 'operacional') {
    if (!PROFILE_CONFIG[norm].permissions.setOperacional) {
      return {
        allowed: false,
        reason: 'Apenas o Técnico MRO ou Supervisor de CCO podem definir status como OPERACIONAL.',
      };
    }
  } else if (targetStatus === 'em_manutencao') {
    if (!PROFILE_CONFIG[norm].permissions.setManutencao) {
      return {
        allowed: false,
        reason: 'Apenas o Controlador CCO ou Supervisor de CCO podem definir status como EM MANUTENÇÃO.',
      };
    }
  } else if (targetStatus === 'preparado_comercial') {
    if (!PROFILE_CONFIG[norm].permissions.setPreparadoComercial) {
      return {
        allowed: false,
        reason: 'Apenas o Controlador CCO ou Supervisor de CCO podem definir PREPARADO PARA O COMERCIAL.',
      };
    }
  }

  return { allowed: true };
};

export const canAssumeManobrador = (role: UserRole): boolean => {
  const norm = normalizeRole(role);
  return PROFILE_CONFIG[norm].permissions.isManobrador;
};

export const isSupervisor = (role: UserRole): boolean => {
  return normalizeRole(role) === 'supervisor_cco';
};

export const checkManeuverPermission = (
  currentUser: UserProfile,
  activeManobrador: ActiveManobradorState | null
): { allowed: boolean; reason?: string; requiresManobradorActivation?: boolean } => {
  // O pátio só é bloqueado caso OUTRO operador esteja com a função exclusiva de Manobrador ativa
  if (activeManobrador && activeManobrador.userId !== currentUser.id) {
    return {
      allowed: false,
      reason: `Manobras bloqueadas! O pátio está sob comando exclusivo do Manobrador ativo: ${activeManobrador.userName} (Matrícula ${activeManobrador.badgeNumber}). Nenhum outro operador pode realizar manobras enquanto a função estiver ocupada.`,
    };
  }

  return { allowed: true };
};

// Format and validate badge number "38-00000" or raw railway operator badge
export const formatBadgeNumber = (val: string): string => {
  if (!val) return '38-';
  const digits = val.replace(/\D/g, '');
  if (!digits) return '38-';
  
  let cleanDigits = digits;
  if (!cleanDigits.startsWith('38')) {
    cleanDigits = '38' + cleanDigits;
  }
  const suffix = cleanDigits.slice(2, 9);
  return `38-${suffix}`;
};

export const validateBadgeNumber = (badge: string): boolean => {
  if (!badge) return false;
  const trimmed = badge.trim();
  const digits = trimmed.replace(/\D/g, '');
  // Accepts standard 38-XXXXX or 38-XXX.. or any valid badge with at least 3 digits
  return digits.length >= 3 && (/^38-\d{3,8}$/.test(trimmed) || /^\d{3,8}$/.test(trimmed));
};

// Flexible matching for login and search (matches "12345", "38-12345", "3812345", operator name or ID)
export const matchUserBadge = (
  term: string, 
  userBadge: string, 
  userName?: string, 
  userId?: string
): boolean => {
  if (!term) return false;
  const cleanTerm = term.trim().toLowerCase();
  
  // 1. Direct ID match
  if (userId && userId.toLowerCase() === cleanTerm) return true;
  
  // 2. Exact badge string match (case-insensitive)
  if (userBadge) {
    const cleanBadge = userBadge.trim().toLowerCase();
    if (cleanTerm === cleanBadge) return true;

    // Digits-only comparison (handles "12345" == "38-12345", "3812345" == "38-12345", etc.)
    const termDigits = cleanTerm.replace(/\D/g, '');
    const badgeDigits = cleanBadge.replace(/\D/g, '');

    if (termDigits.length > 0 && badgeDigits.length > 0) {
      if (termDigits === badgeDigits) return true;
      if (`38${termDigits}` === badgeDigits) return true;
      if (termDigits === `38${badgeDigits}`) return true;

      // Extract the numeric suffix after '38' prefix (or the entire digits if no 38 prefix)
      const termSuffix = termDigits.startsWith('38') && termDigits.length > 2
        ? termDigits.slice(2)
        : termDigits;
      const badgeSuffix = badgeDigits.startsWith('38') && badgeDigits.length > 2
        ? badgeDigits.slice(2)
        : badgeDigits;

      if (termSuffix && badgeSuffix) {
        if (termSuffix === badgeSuffix) return true;
        // Numerical matching ignoring leading zeros (e.g., "36" matches "38-00036" or "00036")
        const termNum = parseInt(termSuffix, 10);
        const badgeNum = parseInt(badgeSuffix, 10);
        if (!isNaN(termNum) && !isNaN(badgeNum) && termNum === badgeNum) return true;
      }
    }
  }

  // 3. Name match (if operator enters their name or partial name)
  if (userName) {
    const cleanName = userName.trim().toLowerCase();
    if (cleanName === cleanTerm) return true;
    if (cleanTerm.length >= 3 && cleanName.includes(cleanTerm)) return true;
    
    // Also match individual name tokens (e.g. "Carlos" or "Silva")
    const tokens = cleanName.split(/\s+/);
    if (tokens.some(t => t === cleanTerm || (cleanTerm.length >= 3 && t.startsWith(cleanTerm)))) {
      return true;
    }
  }

  return false;
};

// Device identification for unified database origin
export const getClientDeviceName = (): string => {
  if (typeof window === 'undefined') return 'Sistema';
  const ua = navigator.userAgent || '';
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);
  const isWindows = /Windows/i.test(ua);
  const isMac = /Macintosh/i.test(ua);
  const isLinux = /Linux/i.test(ua) && !isMobile;
  
  if (isMobile) {
    if (/iPhone/i.test(ua)) return 'Mobile (iPhone)';
    if (/iPad/i.test(ua)) return 'Mobile (iPad)';
    if (/Android/i.test(ua)) return 'Mobile (Android)';
    return 'Dispositivo Móvel';
  }
  if (isWindows) return 'Windows (PC)';
  if (isMac) return 'macOS (Desktop)';
  if (isLinux) return 'Linux (Workstation)';
  return 'Web / Desktop';
};

export const getDeviceCategory = (): 'windows' | 'mobile' | 'other' => {
  if (typeof window === 'undefined') return 'other';
  const ua = navigator.userAgent || '';
  if (/Android|iPhone|iPad|iPod|Mobile/i.test(ua)) return 'mobile';
  if (/Windows/i.test(ua)) return 'windows';
  return 'other';
};

// Storage keys
const USERS_STORAGE_KEY = 'ferropatio_registered_users_v2';
const SESSION_STORAGE_KEY = 'ferropatio_session_user_v2';
const MANOBRADOR_STORAGE_KEY = 'ferropatio_active_manobrador_v2';

export const getStoredUsers = (): UserProfile[] => {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    // ignore
  }
  // Initialize with default INITIAL_USERS
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(INITIAL_USERS));
  return INITIAL_USERS;
};

export const setStoredUsers = (users: UserProfile[]) => {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (e) {
    // ignore
  }
};

export const saveUser = (user: UserProfile): UserProfile[] => {
  const users = getStoredUsers();
  const existingIndex = users.findIndex(u => u.badgeNumber.toLowerCase() === user.badgeNumber.toLowerCase() || u.id === user.id);
  let updated: UserProfile[];
  if (existingIndex >= 0) {
    updated = [...users];
    updated[existingIndex] = { ...updated[existingIndex], ...user };
  } else {
    updated = [user, ...users];
  }
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updated));
  return updated;
};

export const getStoredSession = (): UserProfile => {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY) || localStorage.getItem('ferropatio_session_user');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object' && parsed.id && parsed.name) {
        if (!parsed.avatar) {
          parsed.avatar = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80';
        }
        return parsed;
      }
    }
  } catch (e) {
    // ignore
  }

  // Fallback to default CCO controller or first user
  const users = getStoredUsers();
  const defaultUser = users.find(u => u.role === 'controlador_cco' || u.role === 'cco_dispatcher') || users[0] || INITIAL_USERS[2];
  
  if (!defaultUser.avatar) {
    defaultUser.avatar = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80';
  }

  try {
    const serialized = JSON.stringify(defaultUser);
    localStorage.setItem(SESSION_STORAGE_KEY, serialized);
    localStorage.setItem('ferropatio_session_user', serialized);
  } catch (e) {
    // ignore
  }

  return defaultUser;
};

export const setStoredSession = (user: UserProfile | null) => {
  if (user) {
    const serialized = JSON.stringify(user);
    localStorage.setItem(SESSION_STORAGE_KEY, serialized);
    localStorage.setItem('ferropatio_session_user', serialized);
  } else {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    localStorage.removeItem('ferropatio_session_user');
  }
};

export const getStoredManobrador = (): ActiveManobradorState | null => {
  try {
    const raw = localStorage.getItem(MANOBRADOR_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    // ignore
  }
  return null;
};

export const setStoredManobrador = (state: ActiveManobradorState | null) => {
  if (state) {
    localStorage.setItem(MANOBRADOR_STORAGE_KEY, JSON.stringify(state));
  } else {
    localStorage.removeItem(MANOBRADOR_STORAGE_KEY);
  }
};
