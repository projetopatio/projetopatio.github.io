import { TrainVehicle } from '../types';

export type NormalizedTrainStatus = 'em_manutencao' | 'preparado_comercial' | 'operacional';

export interface TrainStatusTheme {
  id: NormalizedTrainStatus;
  label: string;
  shortLabel: string;
  colorName: 'red' | 'green' | 'blue';
  strokeHex: string;
  fillHex: string;
  glowColor: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  cardBorder: string;
  cardBg: string;
  dotColor: string;
  buttonBg: string;
}

export const TRAIN_STATUS_THEMES: Record<NormalizedTrainStatus, TrainStatusTheme> = {
  em_manutencao: {
    id: 'em_manutencao',
    label: 'EM MANUTENÇÃO',
    shortLabel: 'MANUTENÇÃO',
    colorName: 'red',
    strokeHex: '#ef4444',
    fillHex: '#991b1b',
    glowColor: 'rgba(239, 68, 68, 0.45)',
    badgeBg: 'bg-rose-500/20',
    badgeText: 'text-rose-300',
    badgeBorder: 'border-rose-500/60',
    cardBorder: 'border-rose-500/80',
    cardBg: 'bg-rose-950/30',
    dotColor: 'bg-rose-500',
    buttonBg: 'bg-rose-600 hover:bg-rose-500 text-white border-rose-400 shadow-rose-950/40',
  },
  preparado_comercial: {
    id: 'preparado_comercial',
    label: 'PREPARADO PARA O COMERCIAL',
    shortLabel: 'PREP. COMERCIAL',
    colorName: 'green',
    strokeHex: '#10b981',
    fillHex: '#065f46',
    glowColor: 'rgba(16, 185, 129, 0.45)',
    badgeBg: 'bg-emerald-500/20',
    badgeText: 'text-emerald-300',
    badgeBorder: 'border-emerald-500/60',
    cardBorder: 'border-emerald-500/80',
    cardBg: 'bg-emerald-950/30',
    dotColor: 'bg-emerald-500',
    buttonBg: 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400 shadow-emerald-950/40',
  },
  operacional: {
    id: 'operacional',
    label: 'OPERACIONAL',
    shortLabel: 'OPERACIONAL',
    colorName: 'blue',
    strokeHex: '#38bdf8',
    fillHex: '#0284c7',
    glowColor: 'rgba(56, 189, 248, 0.45)',
    badgeBg: 'bg-sky-500/20',
    badgeText: 'text-sky-300',
    badgeBorder: 'border-sky-500/60',
    cardBorder: 'border-sky-500/80',
    cardBg: 'bg-sky-950/30',
    dotColor: 'bg-sky-400',
    buttonBg: 'bg-sky-600 hover:bg-sky-500 text-white border-sky-400 shadow-sky-950/40',
  },
};

export const getNormalizedTrainStatus = (
  vehicle?: Partial<TrainVehicle> | { status?: string; maintenanceStatus?: string } | null
): NormalizedTrainStatus => {
  if (!vehicle) return 'operacional';
  
  const status = (vehicle.status || '').toLowerCase().trim();
  const maintenance = (vehicle.maintenanceStatus || '').toLowerCase().trim();

  // 1. EM MANUTENÇÃO (Vermelho) - Maintenance
  if (
    status.includes('manu') ||
    status === 'em_manutencao' ||
    status === 'in_maintenance' ||
    status === 'interdicted' ||
    status === 'interditado' ||
    maintenance.includes('progress') ||
    maintenance.includes('manu') ||
    maintenance === 'in_progress'
  ) {
    return 'em_manutencao';
  }

  // 2. PREPARADO PARA O COMERCIAL (Verde) - Commercial Prep / Ready for dispatch
  if (
    status.includes('prep') ||
    status.includes('comerc') ||
    status.includes('dispatch') ||
    status === 'preparado_comercial' ||
    status === 'ready_for_dispatch' ||
    status === 'ready_commercial' ||
    status === 'comercial'
  ) {
    return 'preparado_comercial';
  }

  // 3. OPERACIONAL (Azul) - Operational / Active / Stabled
  return 'operacional';
};

export const getTrainTheme = (
  vehicle?: Partial<TrainVehicle> | { status?: string; maintenanceStatus?: string } | null
): TrainStatusTheme => {
  const norm = getNormalizedTrainStatus(vehicle);
  return TRAIN_STATUS_THEMES[norm];
};

/**
 * Regra Operacional: Manobras com os motivos:
 * - Higienização
 * - Revisão de Ar
 * - Manutenção Preventiva
 * - Manutenção Corretiva
 * - Inspeção de Truque
 * Devem alterar diretamente o status da composição para "EM MANUTENÇÃO".
 */
export const isMaintenanceReason = (reason?: string | null): boolean => {
  if (!reason) return false;
  const norm = reason
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();

  return (
    norm.includes('higienizacao') ||
    norm.includes('revisao de ar') ||
    norm.includes('manutencao preventiva') ||
    norm.includes('manutencao corretiva') ||
    norm.includes('inspecao de truque') ||
    norm.includes('truque')
  );
};
