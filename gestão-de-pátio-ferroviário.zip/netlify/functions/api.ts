import serverless from 'serverless-http';
import { createExpressApp } from '../../serverApp';

const app = createExpressApp();

export const handler = serverless(app);
